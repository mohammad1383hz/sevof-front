# Translation files are supplied by translate.wordpress.org or may be placed in this directory.
