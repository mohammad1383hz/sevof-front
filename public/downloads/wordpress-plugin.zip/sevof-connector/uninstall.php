<?php
/**
 * Removes the plugin's options, caches and scheduled events. Published posts and media are kept.
 *
 * @package SevofConnector
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$sevof_options = array(
	'sevof_connector_client_id',
	'sevof_connector_client_secret',
	'sevof_connector_api_key',
	'sevof_connector_status',
	'sevof_connector_last_message',
	'sevof_connector_last_error',
	'sevof_connector_accent_color',
	'sevof_connector_style_overrides',
	'sevof_connector_product_style_mode',
	'sevof_connector_custom_classes',
);

foreach ( $sevof_options as $sevof_option ) {
	delete_option( $sevof_option );
}

$sevof_transients = array(
	'sevof_connector_cache_dashboard',
	'sevof_connector_cache_keywords',
	'sevof_connector_cache_entities',
	'sevof_connector_cache_articles',
	'sevof_connector_cache_product_articles',
	'sevof_connector_cache_subscription',
	'sevof_connector_logo_color',
	'sevof_connector_detected_style',
);

foreach ( $sevof_transients as $sevof_transient ) {
	delete_transient( $sevof_transient );
}

wp_clear_scheduled_hook( 'sevof_connector_health_ping' );
wp_clear_scheduled_hook( 'sevof_connector_cleanup_replay_tokens' );

global $wpdb;

// Replay-protection records and cached product-link cards (transients and their timeouts).
$sevof_like_patterns = array(
	$wpdb->esc_like( 'sevof_connector_replay_' ) . '%',
	$wpdb->esc_like( '_transient_sevof_lc_' ) . '%',
	$wpdb->esc_like( '_transient_timeout_sevof_lc_' ) . '%',
);

foreach ( $sevof_like_patterns as $sevof_like ) {
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one-time prefix cleanup on uninstall; core has no API for deleting options by pattern.
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $sevof_like ) );
}
