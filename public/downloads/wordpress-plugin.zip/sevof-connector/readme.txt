=== Sevof Connector ===
Contributors: mohammadhosseinzadeh
Tags: seo, ai writer, content, woocommerce, publishing
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connect your WordPress site to Sevof to publish SEO articles and product articles and to apply approved SEO updates to WooCommerce products.

== Description ==

[Sevof](https://sevof.com) is an SEO agent: it analyzes your site, finds keyword and content opportunities, writes articles and product articles, and keeps them fresh with Google Search Console data.

Sevof Connector is the bridge between your WordPress site and your Sevof account. Once you connect it, Sevof can publish to your site and you can follow your Sevof account from the WordPress dashboard.

= What it does =

* Publishes Sevof articles and product articles as regular WordPress posts, with featured image, in-article images, categories, tags, FAQ and product cards.
* Writes the SEO title, meta description and focus keyword to Yoast SEO, Rank Math or SEOPress, and prints them itself when no SEO plugin is active.
* Adds FAQ and product structured data (JSON-LD).
* Applies SEO updates you approved in Sevof to existing WooCommerce products (description, short description, SEO title and description, tags, image alt text, FAQ). Requires WooCommerce.
* Lets Sevof refresh your own older posts with Search Console data, after you approve it in Sevof. A post edited in WordPress in the meantime is never overwritten.
* Styles Sevof content with colors taken from your logo. You can change every color under Sevof > Appearance, or add your theme's own classes under Sevof > Custom classes & CSS.
* Shows your plan, credit, articles, keywords and entities on the Sevof page in WordPress.

= Security =

* Every request between Sevof and your site is signed (API key, timestamped HMAC-SHA256 signature, one-time replay protection) and sent over HTTPS.
* Sevof can only read, update or trash posts it created itself. Your other posts can only be changed through the "refresh past articles" endpoint, and never when they were built with a page builder, are password protected, or were edited since Sevof read them.
* Images are size-limited, type-checked and stored in your Media Library.
* Credentials are never shown again after saving and are never written to logs.

Sevof Connector works in any language. Articles follow your site's text direction, so right-to-left sites (Arabic) are supported.

== Installation ==

1. Install and activate the plugin from Plugins > Add New, or upload the `sevof-connector` folder to `/wp-content/plugins/`.
2. In your Sevof account, add this site and open its WordPress connection to get a Client ID, Client Secret and API Key.
3. In WordPress, open **Sevof**, paste the three values and click **Save and connect**.
4. Back in Sevof, test the connection, then start publishing.

== Frequently Asked Questions ==

= Do I need a Sevof account? =

Yes. The plugin only connects WordPress to Sevof; articles are written in your Sevof account at [sevof.com](https://sevof.com).

= Where does the plugin connect to? =

Only to `https://api.sevof.com`.

= Can Sevof change any post on my site? =

No. It can only change posts it created. Your own posts can only be updated when you approve a refresh in Sevof, and WooCommerce products only through the product SEO update you approved. Empty fields never erase existing data.

= The connection fails. What can I do? =

The Sevof page shows the reason and a technical report you can send to support. The most common causes are a firewall or security plugin blocking outgoing requests to `api.sevof.com`, the `WP_HTTP_BLOCK_EXTERNAL` constant, or a missing PHP cURL extension.

= What happens when I delete the plugin? =

Its settings, caches and scheduled tasks are removed. Published posts and their images stay on your site.

== External services ==

This plugin connects to Sevof, an external service at `https://api.sevof.com`, to publish content on your site on behalf of the site administrator. Nothing is sent before an administrator enters credentials and clicks "Save and connect".

* **When connecting:** the site URL, WordPress version and plugin version.
* **Every 12 hours while connected:** a health check with the WordPress and plugin version.
* **When you open the Sevof page in WordPress:** signed requests to read your plan, articles, keywords and entities.
* **From Sevof to your site:** articles, images, SEO fields and product updates you created or approved in Sevof, and requests for your own posts when you use "refresh past articles".
* **Product links in articles:** when an article contains a standalone link to a product on another website, the plugin fetches that one public page (a normal GET request) to show its title, image and price as a card. Results are cached for 12 hours and at most 6 pages are fetched per article. Turn this off with `add_filter( 'sevof_connector_auto_link_cards', '__return_false' );`.

No visitor data, comments or user accounts are sent to Sevof.

Sevof [Terms of Service](https://sevof.com/terms) and [Privacy Policy](https://sevof.com/privacy).

== Developers ==

Filters: `sevof_connector_accent_color`, `sevof_connector_branded_css`, `sevof_connector_auto_link_cards`, `sevof_connector_existing_post_types`, `sevof_connector_product_style_mode`, `sevof_connector_styled_product_themes`, `sevof_connector_product_theme_signal`, `sevof_connector_product_faq_schema`, `sevof_connector_logo_path`, `sevof_connector_style_palette`.

For a Sevof staging server, define `SEVOF_CONNECTOR_API_URL` (HTTPS only) in `wp-config.php`.

== Changelog ==

= 1.0.0 =
* First release of Sevof Connector.
