/**
 * Sevof Connector - Settings page (colors & style).
 *
 * Keeps the live preview, the readability chips and the derived palette in sync with
 * what the owner edits. The derived tones are computed exactly like the PHP side
 * (Sevof_Connector_Rest_Controller::article_style_palette) so what you see here is what
 * the site prints. Nothing is saved until the form is submitted.
 */
(function () {
	'use strict';

	var cfg = window.SevofStyleSettings || {};
	var i18n = cfg.i18n || {};
	var form = document.getElementById('yxs-form');
	var preview = document.getElementById('yxs-preview');
	if (!form || !preview) {
		return;
	}

	// ------------------------------------------------------------------
	// Color math (mirror of the PHP helpers)
	// ------------------------------------------------------------------

	function clamp(n, lo, hi) {
		return Math.max(lo, Math.min(hi, n));
	}

	function normHex(v) {
		if (typeof v !== 'string') {
			return null;
		}
		var h = v.trim().replace(/^#/, '').toLowerCase();
		if (/^[0-9a-f]{3}$/.test(h)) {
			h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
		}
		return /^[0-9a-f]{6}$/.test(h) ? '#' + h : null;
	}

	function toRgb(hex) {
		return [parseInt(hex.substr(1, 2), 16), parseInt(hex.substr(3, 2), 16), parseInt(hex.substr(5, 2), 16)];
	}

	function pad(n) {
		var s = n.toString(16);
		return s.length < 2 ? '0' + s : s;
	}

	function mix(hex, target, weight) {
		var a = toRgb(hex);
		var b = toRgb(target);
		var w = clamp(weight, 0, 1);
		var out = '#';
		for (var i = 0; i < 3; i++) {
			// toPrecision(15) mirrors PHP's round(), which treats 22.4999999999999964 as 22.5.
			out += pad(Math.round(Number((a[i] + (b[i] - a[i]) * w).toPrecision(15))));
		}
		return out;
	}

	function luminance(hex) {
		var c = toRgb(hex).map(function (n) {
			var v = n / 255;
			return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
		});
		return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
	}

	function contrast(a, b) {
		var la = luminance(a);
		var lb = luminance(b);
		return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
	}

	function readableOnWhite(hex) {
		for (var i = 0; i < 14; i++) {
			if (contrast(hex, '#ffffff') >= 4.5) {
				break;
			}
			hex = mix(hex, '#000000', 0.12);
		}
		return hex;
	}

	function rgbaString(hex, pct) {
		var c = toRgb(hex);
		var a = parseFloat((clamp(pct, 0, 100) / 100).toFixed(3));
		return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')';
	}

	/** Derived palette for a brand color: token => { hex, pct? }. */
	function derive(p) {
		var white = '#ffffff';
		var black = '#000000';
		var shadowBase = mix(p, black, 0.3);
		return {
			primary_text: { hex: readableOnWhite(p) },
			primary_deep: { hex: mix(p, black, 0.22) },
			cta_text: { hex: contrast(p, white) >= contrast(p, '#111111') ? '#ffffff' : '#111111' },
			wash_strong: { hex: p, pct: 8 },
			wash_soft: { hex: p, pct: 1.5 },
			shadow: { hex: shadowBase, pct: 22 },
			shadow_soft: { hex: shadowBase, pct: 6 },
			heading_text: { hex: mix(p, black, 0.55) },
			h3_text: { hex: mix(p, black, 0.34) },
			paragraph_text: { hex: mix(p, black, 0.83) },
			muted: { hex: mix(p, '#6b7280', 0.7) },
			link_underline: { hex: p, pct: 35 },
			list_bg: { hex: mix(p, white, 0.97) },
			list_border: { hex: mix(p, white, 0.87) },
			card_border: { hex: mix(p, white, 0.84) },
			media_bg_a: { hex: mix(p, white, 0.93) },
			media_bg_b: { hex: mix(p, white, 0.985) },
			faq_border: { hex: mix(p, white, 0.86) },
			faq_bg_top: { hex: mix(p, white, 0.985) },
			faq_bg_bottom: { hex: mix(p, white, 0.96) },
			faq_title_border: { hex: mix(p, white, 0.86) },
			faq_title_text: { hex: mix(p, black, 0.4) },
			faq_item_border: { hex: mix(p, white, 0.84) },
			icon_bg: { hex: mix(p, white, 0.91) },
			faq_answer_text: { hex: mix(p, black, 0.67) },
			faq_answer_border: { hex: mix(p, white, 0.94) }
		};
	}

	// ------------------------------------------------------------------
	// Elements
	// ------------------------------------------------------------------

	var primaryColor = document.getElementById('yxs-primary-color');
	var primaryHexInput = document.getElementById('yxs-primary-hex');
	var primaryValue = document.getElementById('yxs-primary-value');
	var primaryNote = document.getElementById('yxs-primary-note');
	var useLogoBtn = document.getElementById('yxs-use-logo');
	var ribbon = document.getElementById('yxs-ribbon');
	var stateEl = document.getElementById('yxs-state');
	var bar = form.querySelector('.yxs-bar');
	var resetAll = document.getElementById('yxs-reset-all');
	var modeRadios = form.querySelectorAll('input[name="yx_primary_mode"]');
	var primarySwatch = primaryColor ? primaryColor.parentNode : null;

	var autoPrimary = ribbon ? normHex(ribbon.getAttribute('data-auto-primary') || '') : null;
	var primary = normHex(primaryValue.value) || '#2f7d78';

	var tiles = [];
	Array.prototype.forEach.call(form.querySelectorAll('.yxs-tile'), function (el) {
		var t = {
			el: el,
			key: el.getAttribute('data-key'),
			type: el.getAttribute('data-type'),
			check: el.getAttribute('data-check') || '',
			color: el.querySelector('.yxs-color'),
			hex: el.querySelector('.yxs-hex'),
			alpha: el.querySelector('.yxs-alpha'),
			out: el.querySelector('.yxs-alpha-out'),
			custom: el.querySelector('.yxs-custom'),
			badge: el.querySelector('.yxs-badge'),
			reset: el.querySelector('.yxs-reset'),
			chip: el.querySelector('.yxs-contrast'),
			swatch: el.querySelector('.yxs-swatch'),
			autoHex: normHex(el.getAttribute('data-auto-hex') || '') || '#000000',
			autoPct: el.getAttribute('data-auto-pct') === '' ? null : parseFloat(el.getAttribute('data-auto-pct'))
		};
		t.isCustom = t.custom.value === '1';
		tiles.push(t);
	});
	var byKey = {};
	tiles.forEach(function (t) {
		byKey[t.key] = t;
	});

	// ------------------------------------------------------------------
	// Values
	// ------------------------------------------------------------------

	function tileValue(t) {
		var hex = normHex(t.color.value) || '#000000';
		if (t.type === 'alpha') {
			return rgbaString(hex, parseFloat(t.alpha.value));
		}
		return hex;
	}

	function valueOf(key) {
		if (key === 'primary') {
			return primary;
		}
		return byKey[key] ? tileValue(byKey[key]) : '#ffffff';
	}

	function fmtPct(n) {
		return (Math.round(n * 10) / 10).toString();
	}

	function sameAsAuto(t) {
		var hex = normHex(t.color.value);
		if (hex !== t.autoHex) {
			return false;
		}
		if (t.type === 'alpha') {
			return Math.abs(parseFloat(t.alpha.value) - t.autoPct) < 0.001;
		}
		return true;
	}

	function setTile(t, hex, pct) {
		t.color.value = hex;
		t.hex.value = hex;
		t.hex.classList.remove('is-invalid');
		if (t.type === 'alpha' && pct !== null && pct !== undefined) {
			t.alpha.value = pct;
		}
	}

	function paintTile(t) {
		var v = tileValue(t);
		if (t.swatch) {
			t.swatch.style.setProperty('--c', v);
		}
		if (t.out) {
			t.out.textContent = fmtPct(parseFloat(t.alpha.value)) + '%';
		}
		preview.style.setProperty('--yt-' + t.key.replace(/_/g, '-'), v);
	}

	function setCustom(t, on) {
		t.isCustom = on;
		t.custom.value = on ? '1' : '0';
		t.el.classList.toggle('is-custom', on);
		t.badge.classList.toggle('is-custom', on);
		t.badge.classList.toggle('is-auto', !on);
		t.badge.textContent = on ? (i18n.custom || 'custom') : (i18n.auto || 'auto');
		t.reset.hidden = !on;
	}

	// ------------------------------------------------------------------
	// Readability chips
	// ------------------------------------------------------------------

	function updateChips() {
		tiles.forEach(function (t) {
			if (!t.chip || !t.check) {
				return;
			}
			var fg = normHex(t.color.value);
			if (!fg) {
				return;
			}
			var ratio = t.check === 'cta' ? contrast(fg, primary) : contrast(fg, '#ffffff');
			var cls = 'is-weak';
			var label = i18n.weak || 'weak';
			if (ratio >= 7) {
				cls = 'is-great';
				label = i18n.great || 'great';
			} else if (ratio >= 4.5) {
				cls = 'is-good';
				label = i18n.good || 'good';
			}
			t.chip.hidden = false;
			t.chip.className = 'yxs-contrast ' + cls;
			t.chip.textContent = label + ' · ' + ratio.toFixed(1) + ':1';
		});
	}

	// ------------------------------------------------------------------
	// Ribbon + preview + dirty state
	// ------------------------------------------------------------------

	function paintRibbon() {
		if (!ribbon) {
			return;
		}
		Array.prototype.forEach.call(ribbon.querySelectorAll('.yxs-rib'), function (r) {
			var chip = r.querySelector('.yxs-rib-chip');
			if (chip) {
				chip.style.background = valueOf(r.getAttribute('data-key'));
			}
		});
	}

	var initial = serialize();

	function serialize() {
		var parts = [];
		Array.prototype.forEach.call(form.elements, function (el) {
			if (!el.name || el.name === 'yx_do' || el.name === 'action' || el.name.indexOf('nonce') !== -1 || el.name === '_wp_http_referer') {
				return;
			}
			if ((el.type === 'radio' || el.type === 'checkbox') && !el.checked) {
				return;
			}
			parts.push(el.name + '=' + el.value);
		});
		return parts.join('&');
	}

	var dirty = false;
	function refreshState() {
		dirty = serialize() !== initial;
		if (bar) {
			bar.classList.toggle('is-dirty', dirty);
		}
		if (stateEl) {
			stateEl.textContent = dirty ? (i18n.dirty || '') : (i18n.clean || '');
		}
	}

	function refreshAll() {
		tiles.forEach(paintTile);
		preview.style.setProperty('--yt-primary', primary);
		paintRibbon();
		updateChips();
		refreshState();
	}

	// ------------------------------------------------------------------
	// Brand color
	// ------------------------------------------------------------------

	function mode() {
		for (var i = 0; i < modeRadios.length; i++) {
			if (modeRadios[i].checked) {
				return modeRadios[i].value;
			}
		}
		return 'auto';
	}

	function setMode(value) {
		for (var i = 0; i < modeRadios.length; i++) {
			modeRadios[i].checked = modeRadios[i].value === value;
		}
	}

	function showNote(text) {
		if (!primaryNote) {
			return;
		}
		primaryNote.hidden = !text;
		primaryNote.textContent = text || '';
	}

	function applyDerived() {
		var d = derive(primary);
		tiles.forEach(function (t) {
			var a = d[t.key];
			if (!a) {
				return;
			}
			t.autoHex = a.hex;
			t.autoPct = a.pct === undefined ? null : a.pct;
			if (!t.isCustom) {
				setTile(t, a.hex, a.pct);
			}
		});
	}

	function setPrimary(hex) {
		primary = hex;
		primaryValue.value = hex;
		if (primaryColor) {
			primaryColor.value = hex;
		}
		if (primaryHexInput) {
			primaryHexInput.value = hex;
			primaryHexInput.classList.remove('is-invalid');
		}
		if (primarySwatch) {
			primarySwatch.style.setProperty('--c', hex);
		}
		applyDerived();
		refreshAll();
	}

	function manualPrimary(hex) {
		setMode('manual');
		showNote('');
		setPrimary(hex);
	}

	if (primaryColor) {
		primaryColor.addEventListener('input', function () {
			var hex = normHex(primaryColor.value);
			if (hex) {
				manualPrimary(hex);
			}
		});
	}

	if (primaryHexInput) {
		primaryHexInput.addEventListener('input', function () {
			var hex = normHex(primaryHexInput.value);
			if (!hex) {
				primaryHexInput.classList.add('is-invalid');
				return;
			}
			primaryHexInput.classList.remove('is-invalid');
			manualPrimary(hex);
		});
		primaryHexInput.addEventListener('blur', function () {
			var hex = normHex(primaryHexInput.value);
			primaryHexInput.value = hex || primary;
			primaryHexInput.classList.remove('is-invalid');
		});
	}

	if (useLogoBtn) {
		useLogoBtn.addEventListener('click', function () {
			var hex = normHex(useLogoBtn.getAttribute('data-hex') || '');
			if (hex) {
				manualPrimary(hex);
			}
		});
	}

	Array.prototype.forEach.call(modeRadios, function (radio) {
		radio.addEventListener('change', function () {
			if (!radio.checked) {
				return;
			}
			if (radio.value === 'auto') {
				if (autoPrimary) {
					showNote('');
					setPrimary(autoPrimary);
				} else {
					showNote(i18n.autoLater || '');
					refreshState();
				}
			} else {
				showNote('');
				refreshState();
			}
		});
	});

	// ------------------------------------------------------------------
	// Tiles
	// ------------------------------------------------------------------

	function touch(t) {
		setCustom(t, !sameAsAuto(t));
		paintTile(t);
		updateChips();
		paintRibbon();
		refreshState();
	}

	tiles.forEach(function (t) {
		t.color.addEventListener('input', function () {
			t.hex.value = t.color.value;
			t.hex.classList.remove('is-invalid');
			touch(t);
		});

		t.hex.addEventListener('input', function () {
			var hex = normHex(t.hex.value);
			if (!hex) {
				t.hex.classList.add('is-invalid');
				return;
			}
			t.hex.classList.remove('is-invalid');
			t.color.value = hex;
			touch(t);
		});
		t.hex.addEventListener('blur', function () {
			t.hex.value = normHex(t.color.value) || t.hex.value;
			t.hex.classList.remove('is-invalid');
		});

		if (t.alpha) {
			t.alpha.addEventListener('input', function () {
				touch(t);
			});
		}

		t.reset.addEventListener('click', function () {
			setTile(t, t.autoHex, t.autoPct);
			setCustom(t, false);
			paintTile(t);
			updateChips();
			paintRibbon();
			refreshState();
		});
	});

	// ------------------------------------------------------------------
	// Form
	// ------------------------------------------------------------------

	var submitting = false;
	form.addEventListener('submit', function (e) {
		var submitter = e.submitter || document.activeElement;
		if (submitter && submitter === resetAll && !window.confirm(i18n.confirm || 'Reset?')) {
			e.preventDefault();
			return;
		}
		submitting = true;
	});

	window.addEventListener('beforeunload', function (e) {
		if (dirty && !submitting) {
			e.preventDefault();
			e.returnValue = '';
		}
	});

	// First paint: tile values come from the server; only the preview variables are synced here.
	refreshAll();
	initial = serialize();
	refreshState();
})();
