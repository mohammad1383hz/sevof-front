/* Sevof Connector: dashboard page behaviour (tabs, disconnect confirmation, copyable report). */
( function () {
	'use strict';

	var wrap = document.querySelector( '.sevof-wrap' );
	if ( ! wrap ) {
		return;
	}

	var tabs = wrap.querySelectorAll( '[data-yx-tab]' );
	if ( tabs.length ) {
		// Without JavaScript both panels stay visible; hiding starts only here.
		wrap.classList.add( 'yx-js' );

		var activate = function ( name ) {
			Array.prototype.forEach.call( tabs, function ( tab ) {
				var on = tab.getAttribute( 'data-yx-tab' ) === name;
				tab.setAttribute( 'aria-selected', on ? 'true' : 'false' );
				tab.tabIndex = on ? 0 : -1;
				var panel = document.getElementById( tab.getAttribute( 'aria-controls' ) );
				if ( panel ) {
					panel.hidden = ! on;
				}
			} );
		};

		Array.prototype.forEach.call( tabs, function ( tab, index ) {
			tab.addEventListener( 'click', function () {
				activate( tab.getAttribute( 'data-yx-tab' ) );
			} );
			tab.addEventListener( 'keydown', function ( event ) {
				if ( 'ArrowRight' !== event.key && 'ArrowLeft' !== event.key ) {
					return;
				}
				var step = ( 'ArrowRight' === event.key ) === ( 'rtl' !== document.dir ) ? 1 : -1;
				var next = tabs[ ( index + step + tabs.length ) % tabs.length ];
				activate( next.getAttribute( 'data-yx-tab' ) );
				next.focus();
				event.preventDefault();
			} );
		} );

		activate( tabs[ 0 ].getAttribute( 'data-yx-tab' ) );
	}

	var disconnectForm = wrap.querySelector( '[data-sevof-disconnect]' );
	if ( disconnectForm ) {
		disconnectForm.addEventListener( 'submit', function ( event ) {
			var settings = window.sevofConnectorAdmin || {};
			if ( ! window.confirm( settings.confirmDisconnect || 'Disconnect?' ) ) {
				event.preventDefault();
			}
		} );
	}

	var report = wrap.querySelector( 'textarea.yx-report' );
	if ( report ) {
		report.addEventListener( 'focus', function () {
			report.select();
		} );
	}
}() );
