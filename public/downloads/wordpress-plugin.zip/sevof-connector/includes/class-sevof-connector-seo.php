<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Makes the SEO data that Sevof sends (meta title, meta description, focus
 * keyword, Open Graph fields, FAQ schema) actually reach the front end.
 *
 * Previously this data was written only to internal `_sevof_*` postmeta
 * keys that nothing ever read, so it had no effect on the published page's
 * <title>, meta description, Open Graph tags, or structured data -
 * regardless of how good the SEO review from the Sevof server looked.
 *
 * This class does two things:
 *  1. Mirrors the values into the postmeta keys used by the major SEO
 *     plugins (Yoast SEO, Rank Math, SEOPress), so if the site already runs
 *     one of those, it picks the values up automatically.
 *  2. If no recognized SEO plugin is active, prints the title/meta
 *     description/Open Graph tags itself.
 *  3. Always prints FAQ schema (JSON-LD) for managed posts that have it,
 *     since none of the SEO plugins above generate that automatically from
 *     custom fields.
 *  4. Always prints Product/ItemList schema (JSON-LD) for managed product
 *     articles, for the same reason.
 */
class Sevof_Connector_Seo {

	const MANAGED_META_KEY = '_sevof_managed';

	public static function init() {
		add_action( 'wp_head', array( self::class, 'print_fallback_meta_tags' ), 1 );
		add_action( 'wp_head', array( self::class, 'print_faq_schema' ), 5 );
		add_action( 'wp_head', array( self::class, 'print_product_schema' ), 5 );
	}

	/**
	 * Mirrors Sevof SEO fields into the postmeta keys read by common SEO
	 * plugins. Safe to call even if a given plugin is not installed - the
	 * meta rows just sit unused.
	 *
	 * @param int             $post_id Post ID.
	 * @param array<string,string> $values  Map with any of: meta_title,
	 *                                       meta_description, focus_keyword,
	 *                                       og_title, og_description.
	 */
	public static function sync_third_party_meta( int $post_id, array $values ) {
		$meta_title       = $values['meta_title'] ?? null;
		$meta_description = $values['meta_description'] ?? null;
		$focus_keyword    = $values['focus_keyword'] ?? null;
		$og_title         = $values['og_title'] ?? null;
		$og_description   = $values['og_description'] ?? null;

		// Yoast SEO.
		if ( null !== $meta_title ) {
			update_post_meta( $post_id, '_yoast_wpseo_title', $meta_title );
		}
		if ( null !== $meta_description ) {
			update_post_meta( $post_id, '_yoast_wpseo_metadesc', $meta_description );
		}
		if ( null !== $focus_keyword ) {
			update_post_meta( $post_id, '_yoast_wpseo_focuskw', $focus_keyword );
		}
		if ( null !== $og_title ) {
			update_post_meta( $post_id, '_yoast_wpseo_opengraph-title', $og_title );
		}
		if ( null !== $og_description ) {
			update_post_meta( $post_id, '_yoast_wpseo_opengraph-description', $og_description );
		}

		// Rank Math.
		if ( null !== $meta_title ) {
			update_post_meta( $post_id, 'rank_math_title', $meta_title );
		}
		if ( null !== $meta_description ) {
			update_post_meta( $post_id, 'rank_math_description', $meta_description );
		}
		if ( null !== $focus_keyword ) {
			update_post_meta( $post_id, 'rank_math_focus_keyword', $focus_keyword );
		}
		if ( null !== $og_title ) {
			update_post_meta( $post_id, 'rank_math_facebook_title', $og_title );
		}
		if ( null !== $og_description ) {
			update_post_meta( $post_id, 'rank_math_facebook_description', $og_description );
		}

		// SEOPress.
		if ( null !== $meta_title ) {
			update_post_meta( $post_id, '_seopress_titles_title', $meta_title );
		}
		if ( null !== $meta_description ) {
			update_post_meta( $post_id, '_seopress_titles_desc', $meta_description );
		}
		if ( null !== $focus_keyword ) {
			update_post_meta( $post_id, '_seopress_analysis_target_kw', $focus_keyword );
		}
		if ( null !== $og_title ) {
			update_post_meta( $post_id, '_seopress_social_fb_title', $og_title );
		}
		if ( null !== $og_description ) {
			update_post_meta( $post_id, '_seopress_social_fb_desc', $og_description );
		}

		// All in One SEO stores post data in a dedicated DB table rather than
		// postmeta, so it cannot be filled reliably here. Flag this so it is
		// visible from the admin list/dashboard instead of failing silently.
		if ( self::is_aioseo_active() ) {
			update_post_meta( $post_id, '_sevof_seo_plugin_unsupported', 'aioseo' );
		} else {
			delete_post_meta( $post_id, '_sevof_seo_plugin_unsupported' );
		}
	}

	/**
	 * Prints <title>, meta description, and Open Graph tags for a managed
	 * post, but only when no recognized SEO plugin is already handling it -
	 * otherwise this would duplicate or conflict with that plugin's output.
	 */
	public static function print_fallback_meta_tags() {
		if ( self::any_known_seo_plugin_active() ) {
			return;
		}

		if ( ! is_singular( array( 'post', 'product' ) ) ) {
			return;
		}

		$post_id    = get_queried_object_id();
		$is_product = 'product' === get_post_type( $post_id );

		// Products are existing WooCommerce products, not posts created by this plugin, so they
		// are recognized by the marker written when Sevof applied SEO data to them.
		if ( $is_product ? ! self::is_product_seo_post( $post_id ) : ! self::is_managed_post( $post_id ) ) {
			return;
		}

		$meta_title       = (string) get_post_meta( $post_id, '_sevof_meta_title', true );
		$meta_description = (string) get_post_meta( $post_id, '_sevof_meta_description', true );
		$og_title         = (string) get_post_meta( $post_id, '_sevof_og_title', true );
		$og_description   = (string) get_post_meta( $post_id, '_sevof_og_description', true );

		if ( '' !== $meta_description ) {
			echo '<meta name="description" content="' . esc_attr( $meta_description ) . '" />' . "\n";
		}

		if ( '' !== $og_title ) {
			echo '<meta property="og:title" content="' . esc_attr( $og_title ) . '" />' . "\n";
		} elseif ( '' !== $meta_title ) {
			echo '<meta property="og:title" content="' . esc_attr( $meta_title ) . '" />' . "\n";
		}

		if ( '' !== $og_description ) {
			echo '<meta property="og:description" content="' . esc_attr( $og_description ) . '" />' . "\n";
		} elseif ( '' !== $meta_description ) {
			echo '<meta property="og:description" content="' . esc_attr( $meta_description ) . '" />' . "\n";
		}

		echo '<meta property="og:type" content="' . ( $is_product ? 'product' : 'article' ) . '" />' . "\n";
		echo '<meta property="og:url" content="' . esc_url( get_permalink( $post_id ) ) . '" />' . "\n";

		if ( has_post_thumbnail( $post_id ) ) {
			echo '<meta property="og:image" content="' . esc_url( get_the_post_thumbnail_url( $post_id, 'full' ) ) . '" />' . "\n";
		}

		// Also override the document title itself when no SEO plugin owns it.
		if ( '' !== $meta_title ) {
			add_filter(
				'pre_get_document_title',
				static function () use ( $meta_title ) {
					return $meta_title;
				}
			);
		}
	}

	/**
	 * Prints FAQPage JSON-LD for a managed post, independent of whichever
	 * SEO plugin is active, since none of them generate this automatically
	 * from Sevof's custom FAQ data.
	 */
	public static function print_faq_schema() {
		if ( ! is_singular( array( 'post', 'product' ) ) ) {
			return;
		}

		$post_id = get_queried_object_id();
		if ( 'product' === get_post_type( $post_id ) ) {
			if ( ! self::is_product_seo_post( $post_id ) ) {
				return;
			}

			// Describe only an FAQ that is really on the page: if the store owner deleted the
			// Sevof FAQ block from the description, the structured data must go with it.
			if ( false === strpos( (string) get_post_field( 'post_content', $post_id ), '<!--sevof-faq-->' ) ) {
				return;
			}
		} elseif ( ! self::is_managed_post( $post_id ) ) {
			return;
		}

		$raw = get_post_meta( $post_id, '_sevof_faq_schema', true );
		if ( ! is_string( $raw ) || '' === $raw ) {
			return;
		}

		$decoded = json_decode( $raw, true );
		if ( JSON_ERROR_NONE !== json_last_error() || empty( $decoded ) ) {
			return;
		}

		// Accept either a ready-made schema.org graph or a plain
		// question/answer list and normalize to a valid FAQPage object.
		if ( isset( $decoded['@type'] ) && 'FAQPage' === $decoded['@type'] ) {
			$schema = $decoded;
		} else {
			$entities = array();
			foreach ( (array) $decoded as $item ) {
				if ( ! is_array( $item ) || empty( $item['question'] ) || empty( $item['answer'] ) ) {
					continue;
				}

				$entities[] = array(
					'@type'          => 'Question',
					'name'           => wp_strip_all_tags( (string) $item['question'] ),
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => wp_kses_post( (string) $item['answer'] ),
					),
				);
			}

			if ( empty( $entities ) ) {
				return;
			}

			$schema = array(
				'@context'   => 'https://schema.org',
				'@type'      => 'FAQPage',
				'mainEntity' => $entities,
			);
		}

		echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
	}

	/**
	 * Prints Product/ItemList JSON-LD for managed product articles. The data is
	 * generated by Sevof and stored in postmeta; none of the supported SEO
	 * plugins emit it from custom fields, so it is printed here regardless of
	 * which SEO plugin is active.
	 */
	public static function print_product_schema() {
		if ( ! is_singular( 'post' ) ) {
			return;
		}

		$post_id = get_queried_object_id();
		if ( ! self::is_managed_post( $post_id ) ) {
			return;
		}

		$raw = get_post_meta( $post_id, '_sevof_product_schema', true );
		if ( ! is_string( $raw ) || '' === $raw ) {
			return;
		}

		$decoded = json_decode( $raw, true );
		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) || empty( $decoded ) ) {
			return;
		}

		// Either one schema.org object / @graph, or a plain list of objects (one script each).
		$schemas = ( isset( $decoded['@type'] ) || isset( $decoded['@graph'] ) ) ? array( $decoded ) : array_values( $decoded );

		foreach ( $schemas as $schema ) {
			if ( ! is_array( $schema ) || ( ! isset( $schema['@type'] ) && ! isset( $schema['@graph'] ) ) ) {
				continue;
			}

			if ( ! isset( $schema['@context'] ) ) {
				$schema = array( '@context' => 'https://schema.org' ) + $schema;
			}

			// JSON_HEX_TAG keeps any "</script>" inside a string value from ending the tag early.
			echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG ) . '</script>' . "\n";
		}
	}

	private static function is_product_seo_post( int $post_id ): bool {
		return $post_id > 0 && '1' === get_post_meta( $post_id, '_sevof_product_seo', true );
	}

	private static function is_managed_post( int $post_id ): bool {
		return $post_id > 0 && '1' === get_post_meta( $post_id, self::MANAGED_META_KEY, true );
	}

	private static function any_known_seo_plugin_active(): bool {
		return defined( 'WPSEO_VERSION' )
			|| defined( 'RANK_MATH_VERSION' )
			|| defined( 'SEOPRESS_VERSION' )
			|| self::is_aioseo_active();
	}

	private static function is_aioseo_active(): bool {
		return defined( 'AIOSEO_VERSION' ) || class_exists( 'AIOSEO\\Plugin\\AIOSEO' );
	}
}
