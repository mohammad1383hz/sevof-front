<?php

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Integrate posts managed by Sevof into the Posts → All Posts screen:
 *   - "Sevof" column with status (Created / Updated)
 *   - small badge next to the post title
 *   - dropdown filter above the list to show only Agent-managed posts
 *
 * Relies only on post meta set by the REST controller:
 *   _sevof_managed      => '1' or empty
 *   _sevof_last_action  => created | updated | deleted
 *   _sevof_connectored_at    => last sync timestamp (mysql datetime)
 */
class Sevof_Connector_Posts_List
{
    const META_MANAGED = '_sevof_managed';
    const META_LAST_ACTION = '_sevof_last_action';
    const META_SYNCED_AT = '_sevof_connectored_at';

    public static function init()
    {
        // New column in the posts list
        add_filter('manage_post_posts_columns', [self::class, 'add_column']);
        add_action('manage_post_posts_custom_column', [self::class, 'render_column'], 10, 2);

        // Badge next to the post title (in the Title column, after the title)
        add_action('manage_posts_custom_column', [self::class, 'noop'], 10, 2); // reserved for future use

        // Filter above the page (dropdown)
        add_action('restrict_manage_posts', [self::class, 'render_filter']);
        add_action('pre_get_posts', [self::class, 'apply_filter']);

        // "Sevof" link alongside All / Published / Draft
        add_filter('views_edit-post', [self::class, 'add_status_view']);

        // Small styles for badges. Must be enqueued on admin_enqueue_scripts:
        // enqueuing from admin_head is too late and the CSS ends up in the footer,
        // after the list table has already been laid out.
        add_action('admin_enqueue_scripts', [self::class, 'print_styles']);
    }

    public static function noop()
    {
        // Reserved for future development; currently does nothing.
    }

    /**
     * Add "Sevof" column after the date column.
     */
    public static function add_column(array $columns): array
    {
        $new = [];

        foreach ($columns as $key => $label) {
            $new[$key] = $label;

            if ($key === 'date') {
                $new['sevof_connector'] = __('Sevof', 'sevof-connector');
            }
        }

        // If the date column doesn't exist for any reason, add it at the end
        if (! isset($new['sevof_connector'])) {
            $new['sevof_connector'] = __('Sevof', 'sevof-connector');
        }

        return $new;
    }

    /**
     * Column contents: colored badge based on the last action, or a dash if not managed.
     */
    public static function render_column(string $column, int $post_id)
    {
        if ($column !== 'sevof_connector') {
            return;
        }

        $isManaged = get_post_meta($post_id, self::META_MANAGED, true);

        if (! $isManaged) {
            echo '<span class="sevof-badge sevof-badge--none">&mdash;</span>';

            return;
        }

        $action = get_post_meta($post_id, self::META_LAST_ACTION, true) ?: 'created';
        $syncedAt = get_post_meta($post_id, self::META_SYNCED_AT, true);

        list($label, $modifier) = self::action_label($action);

        printf(
            '<span class="sevof-badge sevof-badge--%1$s" title="%2$s">🤖 %3$s</span>',
            esc_attr($modifier),
            /* translators: %s: date and time the post was last synchronized with the Sevof service. */
            $syncedAt ? esc_attr( sprintf( __( 'Last synchronized: %s', 'sevof-connector' ), $syncedAt ) ) : '',
            esc_html($label)
        );
    }

    /**
     * Map internal action value to a label and a CSS class.
     */
    private static function action_label(string $action): array
    {
        if ('updated' === $action) {
            return [__('Updated', 'sevof-connector'), 'updated'];
        }

        if ('deleted' === $action) {
            return [__('Deleted', 'sevof-connector'), 'deleted'];
        }

        return [__('Created', 'sevof-connector'), 'created'];
    }

    /**
     * Dropdown filter above the posts list (only on edit.php for post type = post).
     */
    public static function render_filter()
    {
        global $typenow;

        if ($typenow !== 'post') {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only display filter, no state change; matches WP core's own list-table view filters which do not use a nonce either.
        $selected = isset( $_GET['sevof_connector_filter'] ) ? sanitize_key( wp_unslash( $_GET['sevof_connector_filter'] ) ) : '';

        ?>
        <select name="sevof_connector_filter">
            <option value=""><?php esc_html_e( 'All posts', 'sevof-connector' ); ?></option>
            <option value="managed" <?php selected($selected, 'managed'); ?>>
                <?php esc_html_e( 'Sevof-managed posts only', 'sevof-connector' ); ?>
            </option>
            <option value="not_managed" <?php selected($selected, 'not_managed'); ?>>
                <?php esc_html_e( 'Manually managed posts only', 'sevof-connector' ); ?>
            </option>
        </select>
        <?php
    }

    /**
     * Apply the selected filter to the main posts list query.
     */
    public static function apply_filter(\WP_Query $query)
    {
        global $pagenow;

        if (! is_admin() || $pagenow !== 'edit.php' || ! $query->is_main_query()) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only query filter, no state change; matches WP core's own list-table view filters which do not use a nonce either.
        $filter = isset( $_GET['sevof_connector_filter'] ) ? sanitize_key( wp_unslash( $_GET['sevof_connector_filter'] ) ) : '';

        if ($filter === 'managed') {
            $query->set('meta_query', [
                [
                    'key' => self::META_MANAGED,
                    'value' => '1',
                    'compare' => '=',
                ],
            ]);
        } elseif ($filter === 'not_managed') {
            $query->set('meta_query', [
                'relation' => 'OR',
                [
                    'key' => self::META_MANAGED,
                    'compare' => 'NOT EXISTS',
                ],
                [
                    'key' => self::META_MANAGED,
                    'value' => '1',
                    'compare' => '!=',
                ],
            ]);
        }
    }

    /**
     * Add a "Sevof" link to the All | Published | Draft row above the posts list.
     * The number in parentheses is the count of posts with _sevof_managed = 1.
     */
    public static function add_status_view(array $views): array
    {
        $count = self::count_managed_posts();

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only display filter, no state change; matches WP core's own list-table view filters which do not use a nonce either.
        $currentFilter = isset( $_GET['sevof_connector_filter'] ) ? sanitize_key( wp_unslash( $_GET['sevof_connector_filter'] ) ) : '';
        $class = $currentFilter === 'managed' ? ' class="current"' : '';

        $url = add_query_arg(
            ['post_type' => 'post', 'sevof_connector_filter' => 'managed'],
            admin_url('edit.php')
        );

        $views['sevof_connector'] = sprintf(
            '<a href="%1$s"%2$s>%3$s <span class="count">(%4$d)</span></a>',
            esc_url($url),
            $class,
            esc_html__('Sevof', 'sevof-connector'),
            $count
        );

        return $views;
    }

    /**
     * Count of posts managed by the Sevof Agent (regardless of publish/draft status).
     */
    private static function count_managed_posts(): int
    {
        // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key, WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- there is no core API to count posts by a meta flag other than a postmeta lookup; only Sevof-managed posts carry this meta key, so the matching set stays small.
        $query = new \WP_Query([
            'post_type' => 'post',
            'post_status' => 'any',
            'meta_key' => self::META_MANAGED,
            'meta_value' => '1',
            'fields' => 'ids',
            'posts_per_page' => -1,
            'no_found_rows' => false,
        ]);

        return (int) $query->found_posts;
    }

    /**
     * Minimal styles for the posts list; only loaded on Posts -> All Posts.
     *
     * The width rule is essential: WP list tables use `table-layout: fixed`, and a
     * column without an explicit width splits the leftover space EQUALLY with the
     * Title column. Without it the custom "Sevof" column squeezes the post
     * title into a narrow, broken-looking column.
     */
    public static function print_styles($hook_suffix = '')
    {
        if ('edit.php' !== $hook_suffix) {
            return;
        }

        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (! $screen || 'edit-post' !== $screen->id) {
            return;
        }

        wp_register_style('sevof-connector-posts-list', false, [], SEVOF_CONNECTOR_VERSION);
        wp_enqueue_style('sevof-connector-posts-list');
        wp_add_inline_style(
            'sevof-connector-posts-list',
            '.wp-list-table.posts th.column-sevof_connector, .wp-list-table.posts td.column-sevof_connector { width: 90px; white-space: nowrap; }
            @media (min-width: 783px) {
                /* WP forces table-layout:fixed, so every column without an explicit width splits what is left after the
                   percentage/pixel columns (author, categories, tags, date, comments, other plugins\' columns and ours).
                   On a crowded list the Title column was left with ~20px and wrapped letter by letter. Auto layout lets
                   the Title column keep a sane minimum width instead. */
                .wp-list-table.posts { table-layout: auto; }
                .wp-list-table.posts th.column-title, .wp-list-table.posts td.column-title { min-width: 240px; }
                .wp-list-table.posts td.column-title .row-title { word-break: normal; overflow-wrap: break-word; }
            }
            .wp-list-table.posts td.column-sevof_connector { overflow: visible; }
            .sevof-badge { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: 600; line-height: 1.6; white-space: nowrap; }
            .sevof-badge--created { background: #e6f4ea; color: #1e7e34; }
            .sevof-badge--updated { background: #fff3cd; color: #8a6d1a; }
            .sevof-badge--deleted { background: #fbe4e4; color: #a12727; }
            .sevof-badge--none { color: #999; }'
        );
    }
}
