<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Authenticated REST endpoints that let the Sevof service apply an SEO result to an
 * existing WooCommerce product.
 *
 *   GET /wp-json/sevof-connector/v1/products/{id}   Read-only check that the product exists.
 *   PUT /wp-json/sevof-connector/v1/products/{id}   Apply the approved SEO fields.
 *
 * Accepted PUT fields (all optional): short_description, description, meta_title,
 * meta_description, focus_keyword, attributes, tags, faq, image_alts.
 * The response always lists the fields that were really stored in `updated_fields`.
 *
 * Rules that keep this safe for the store owner:
 *  - Only fields that are present AND non-empty in the request are changed. A missing or empty
 *    field never erases existing data.
 *  - Only real `product` posts are touched (never variations, orders, pages or posts).
 *  - Product attributes are only ever ADDED. An attribute whose name already exists (custom or
 *    taxonomy based) is skipped, so the store's own specs are never overwritten.
 *  - Tags are only ever ADDED; existing product tags are kept.
 *  - Image alt text is only written for images of this product whose alt is currently empty.
 *  - The focus keyword is only written when no active SEO plugin already holds one for the
 *    product (otherwise it is reported in `preserved_fields`).
 *  - The FAQ block lives between two HTML comment markers at the end of the description. A new
 *    FAQ replaces the old block; when only the description is sent, the existing block is kept.
 *  - Presentation follows the product page (see detect_style()):
 *      "themed"  - the product already has its own styled structure (page builder, classes,
 *                  inline styles, tables, accordions...). The store's markup is NEVER replaced
 *                  or restyled: new text is added in marker blocks after it, using the store's
 *                  own tag attributes / FAQ pattern, and no Sevof CSS is printed.
 *      "branded" - the product has no styling of its own. Content is stored as clean HTML and,
 *                  like an article, is shown with the palette taken from the site logo
 *                  (Sevof_Connector_Rest_Controller::branded_css()), FAQ as an accordion.
 *    A styled short description is left untouched.
 *  - Authentication, HMAC signature and replay protection are the same as for articles
 *    (Sevof_Connector_Rest_Controller::verify_signature).
 */
class Sevof_Connector_Product_Controller {
	const SOURCE_TYPE = 'product_seo';

	const MAX_SHORT_DESCRIPTION_BYTES = 20000;
	const MAX_DESCRIPTION_BYTES       = 200000;
	const MAX_ATTRIBUTES              = 30;
	const MAX_ATTRIBUTE_NAME_LENGTH   = 200;
	const MAX_ATTRIBUTE_VALUE_LENGTH  = 1000;

	const MAX_TAGS                    = 20;
	const MAX_TAG_LENGTH              = 40;
	const MAX_FAQ_ITEMS               = 8;
	const MAX_FAQ_QUESTION_LENGTH     = 300;
	const MAX_FAQ_ANSWER_LENGTH       = 1500;
	const MAX_IMAGE_ALTS              = 50;
	const MAX_IMAGE_ALT_LENGTH        = 300;
	const MAX_FOCUS_KEYWORD_LENGTH    = 200;

	/** Must stay identical to the markers used by the Sevof service (ProductContentSanitizer). */
	const FAQ_START   = '<!--sevof-faq-->';
	const FAQ_END     = '<!--/sevof-faq-->';

	/** Used only in "themed" mode: the SEO text is kept inside these markers, after the store's own content. */
	const DESC_START = '<!--sevof-desc-->';
	const DESC_END   = '<!--/sevof-desc-->';

	/** "themed" | "branded": how the last content write was presented (drives the front-end CSS). */
	const STYLE_MODE_META_KEY   = '_sevof_product_style_mode';
	const STYLE_REASON_META_KEY = '_sevof_product_style_reason';

	/**
	 * Themes that ship their own typography / tab design for the product description. On these
	 * the theme already styles plain headings, paragraphs and lists, so Sevof must not paint a
	 * second look over it. Extend with the `sevof_connector_styled_product_themes` filter.
	 */
	const STYLED_THEMES = array(
		'woodmart', 'flatsome', 'porto', 'xstore', 'the7', 'avada', 'enfold', 'bridge', 'salient',
		'betheme', 'jupiter', 'jupiterx', 'shoptimizer', 'rehub-theme', 'martfury', 'electro',
		'shopkeeper', 'kallyas', 'uncode', 'divi',
	);

	/** Per-request cache of theme_level_signal(). */
	private static $theme_signal = null;

	/** Meta that stores the FAQ list printed as FAQPage JSON-LD on the product page. */
	const FAQ_SCHEMA_META_KEY = '_sevof_faq_schema';

	/** Marks products whose SEO data was written by Sevof (used by the fallback meta printer). */
	const SEO_MARK_META_KEY = '_sevof_product_seo';

	/**
	 * Registers the REST route hook.
	 */
	public static function init() {
		static $initialized = false;
		if ( $initialized ) {
			return;
		}
		$initialized = true;

		add_action( 'rest_api_init', array( self::class, 'register_routes' ) );
		add_action( 'wp_head', array( self::class, 'print_product_styles' ), 20 );
		add_filter( 'the_content', array( self::class, 'wrap_product_description' ), 99 );
	}

	/**
	 * Registers the product routes and their argument schemas.
	 */
	public static function register_routes() {
		register_rest_route(
			Sevof_Connector_Rest_Controller::NAMESPACE,
			'/products/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( self::class, 'show_product' ),
					'permission_callback' => array( Sevof_Connector_Rest_Controller::class, 'verify_signature' ),
					'args'                => self::id_arguments(),
				),
				array(
					'methods'             => 'PUT',
					'callback'            => array( self::class, 'update_product' ),
					'permission_callback' => array( Sevof_Connector_Rest_Controller::class, 'verify_signature' ),
					'args'                => array_merge( self::id_arguments(), self::update_arguments() ),
				),
			)
		);
	}

	/**
	 * Tells the service whether this site can receive product SEO updates at all.
	 */
	public static function is_available(): bool {
		return function_exists( 'wc_get_product' ) && class_exists( 'WC_Product_Attribute' );
	}

	/* ------------------------------------------------------------------ */
	/*  Handlers                                                            */
	/* ------------------------------------------------------------------ */

	/**
	 * Confirms that a product exists and can be edited by the service.
	 */
	public static function show_product( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::is_available() ) {
			return self::woocommerce_inactive_response();
		}

		$product = self::get_editable_product( absint( $request->get_param( 'id' ) ) );
		if ( ! $product ) {
			return self::not_found_response();
		}

		return new WP_REST_Response( self::product_summary( $product ), 200 );
	}

	/**
	 * Applies the approved SEO fields to one product.
	 */
	public static function update_product( WP_REST_Request $request ): WP_REST_Response {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 );
		}

		if ( ! self::is_available() ) {
			return self::woocommerce_inactive_response();
		}

		$product_id = absint( $request->get_param( 'id' ) );
		$product    = self::get_editable_product( $product_id );
		if ( ! $product ) {
			sevof_connector_log( 'product_not_found', array( 'product_id' => $product_id ) );

			return self::not_found_response();
		}

		$short_description = self::clean_html_param( $request, 'short_description' );
		$description       = self::clean_html_param( $request, 'description' );
		$meta_title        = self::clean_text_param( $request, 'meta_title' );
		$meta_description  = self::clean_text_param( $request, 'meta_description' );
		$focus_keyword     = self::clean_text_param( $request, 'focus_keyword' );
		$attributes        = self::clean_attributes_param( $request );
		$tags              = self::clean_tags_param( $request );
		$faq               = self::clean_faq_param( $request );
		$image_alts        = self::clean_image_alts_param( $request );

		// A description that is nothing but an FAQ block carries no body text; treat it as absent.
		if ( null !== $description ) {
			$description = self::strip_sevof_blocks( $description );
			if ( '' === trim( wp_strip_all_tags( $description ) ) ) {
				$description = null;
			}
		}

		if (
			null === $short_description && null === $description && null === $meta_title
			&& null === $meta_description && null === $focus_keyword
			&& empty( $attributes ) && empty( $tags ) && empty( $faq ) && empty( $image_alts )
		) {
			return new WP_REST_Response(
				array(
					'code'    => 'sevof_product_nothing_to_update',
					'message' => __( 'The request contained no usable product fields.', 'sevof-connector' ),
				),
				422
			);
		}

		$updated   = array();
		$added     = 0;
		$skipped   = array();
		$alts      = array();
		$preserved = array();
		$style     = null;
		$faq_rows  = null; // FAQ list for FAQPage schema (empty array = remove the schema).

		try {
			// Read the page's current state BEFORE anything is written, so the decision about
			// "does this product already have its own styling?" is never influenced by this request.
			$original_description = (string) $product->get_description();
			$original_short       = (string) $product->get_short_description();

			if ( null !== $short_description || null !== $description || ! empty( $faq ) ) {
				$style = self::detect_style( $product, self::strip_sevof_blocks( $original_description ), $original_short );
			}

			if ( null !== $short_description ) {
				if ( '' !== self::styled_markup_signal( $original_short ) ) {
					// The store styled its own short description: leave it exactly as it is.
					$preserved[] = 'short_description';
				} else {
					$product->set_short_description( $short_description );
					$updated[] = 'short_description';
				}
			}

			if ( null !== $description || ! empty( $faq ) ) {
				$store = self::strip_sevof_blocks( $original_description );

				if ( 'themed' === $style['mode'] ) {
					// The store's own markup stays byte-for-byte; Sevof text is appended in markers.
					$desc_block = null !== $description
						? self::themed_description_html( $description, $store )
						: self::extract_marked_block( $original_description, self::DESC_START, self::DESC_END );
					$faq_block  = ! empty( $faq )
						? self::faq_html_themed( $faq, $store )
						: self::extract_faq_block( $original_description );

					$content = trim(
						$store
						. ( '' !== $desc_block ? "\n" . self::DESC_START . $desc_block . self::DESC_END : '' )
						. ( '' !== $faq_block ? "\n" . self::FAQ_START . $faq_block . self::FAQ_END : '' )
					);
				} else {
					$base  = null !== $description ? $description : $store;
					$block = ! empty( $faq ) ? self::faq_html_branded( $faq ) : self::extract_faq_block( $original_description );

					$content = trim( $base . ( '' !== $block ? "\n" . self::FAQ_START . $block . self::FAQ_END : '' ) );
				}

				$product->set_description( $content );

				if ( ! empty( $faq ) ) {
					$faq_rows = self::faq_schema_allowed( $product, $style, $store ) ? $faq : array();
				}

				if ( null !== $description ) {
					$updated[] = 'description';
				}
				if ( ! empty( $faq ) ) {
					$updated[] = 'faq';
				}
			}

			if ( ! empty( $attributes ) ) {
				$merge   = self::merge_attributes( $product, $attributes );
				$added   = count( $merge['added'] );
				$skipped = $merge['skipped'];

				if ( $added > 0 ) {
					$product->set_attributes( $merge['attributes'] );
					$updated[] = 'attributes';
				}
			}

			if ( ! empty( $tags ) ) {
				$tag_ids = self::merge_tags( $product, $tags );

				if ( null !== $tag_ids ) {
					$product->set_tag_ids( $tag_ids );
					$updated[] = 'tags';
				}
			}

			if ( ! empty( $image_alts ) ) {
				$alts = self::pending_image_alts( $product, $image_alts );
			}

			// SEO meta is written before save() so SEO plugins that rebuild their index on
			// save_post (Yoast, Rank Math) already see the new values.
			if ( null !== $meta_title || null !== $meta_description ) {
				self::save_seo_meta( $product_id, $meta_title, $meta_description );

				if ( null !== $meta_title ) {
					$updated[] = 'meta_title';
				}
				if ( null !== $meta_description ) {
					$updated[] = 'meta_description';
				}
			}

			if ( null !== $focus_keyword ) {
				if ( '' !== self::existing_focus_keyword( $product_id ) ) {
					// An SEO plugin already holds the store's own focus keyword: never overwrite it.
					$preserved[] = 'focus_keyword';
				} else {
					self::save_focus_keyword( $product_id, $focus_keyword );
					$updated[] = 'focus_keyword';
				}
			}

			$product->save();

			// Image alt text lives on the attachments, so it is written after the product is saved.
			foreach ( $alts as $attachment_id => $alt ) {
				update_post_meta( $attachment_id, '_wp_attachment_image_alt', $alt );
			}

			if ( ! empty( $alts ) ) {
				$updated[] = 'image_alts';
			}
		} catch ( Throwable $e ) {
			return self::internal_error_response( $e, $product_id );
		}

		if ( is_array( $faq_rows ) && in_array( 'faq', $updated, true ) ) {
			if ( ! empty( $faq_rows ) ) {
				update_post_meta( $product_id, self::FAQ_SCHEMA_META_KEY, wp_slash( (string) wp_json_encode( $faq_rows, JSON_UNESCAPED_UNICODE ) ) );
			} else {
				delete_post_meta( $product_id, self::FAQ_SCHEMA_META_KEY );
			}
		}

		if ( null !== $style && ( in_array( 'description', $updated, true ) || in_array( 'faq', $updated, true ) ) ) {
			update_post_meta( $product_id, self::STYLE_MODE_META_KEY, $style['mode'] );
			update_post_meta( $product_id, self::STYLE_REASON_META_KEY, $style['reason'] );
		}

		if ( ! empty( $updated ) ) {
			update_post_meta( $product_id, self::SEO_MARK_META_KEY, '1' );
			update_post_meta( $product_id, '_sevof_last_action', 'product_seo_updated' );
			update_post_meta( $product_id, '_sevof_connectored_at', current_time( 'mysql' ) );
		}

		clean_post_cache( $product_id );

		sevof_connector_log(
			'product_updated',
			array(
				'product_id' => $product_id,
				'fields'     => $updated,
			)
		);

		$response                       = self::product_summary( $product );
		$response['message']            = __( 'The product was updated.', 'sevof-connector' );
		$response['updated_fields']     = $updated;
		$response['added_attributes']   = $added;
		$response['skipped_attributes'] = $skipped;
		$response['image_alts_written'] = count( $alts );
		$response['preserved_fields']   = $preserved;
		if ( null !== $style ) {
			$response['style_mode']   = $style['mode'];
			$response['style_reason'] = $style['reason'];
		}
		if ( is_array( $faq_rows ) ) {
			$response['faq_schema'] = ! empty( $faq_rows );
		}

		return new WP_REST_Response( $response, 200 );
	}

	/* ------------------------------------------------------------------ */
	/*  Product helpers                                                     */
	/* ------------------------------------------------------------------ */

	/**
	 * Returns the product only when it is a real, non-trashed `product` post.
	 *
	 * Variations (`product_variation`) and every other post type are rejected on purpose.
	 *
	 * @return WC_Product|null
	 */
	private static function get_editable_product( int $product_id ) {
		if ( $product_id <= 0 || 'product' !== get_post_type( $product_id ) ) {
			return null;
		}

		if ( in_array( get_post_status( $product_id ), array( 'trash', 'auto-draft' ), true ) ) {
			return null;
		}

		$product = wc_get_product( $product_id );

		return $product instanceof WC_Product ? $product : null;
	}

	private static function product_summary( WC_Product $product ): array {
		return array(
			'wp_product_id' => $product->get_id(),
			'name'          => $product->get_name(),
			'status'        => $product->get_status(),
			'permalink'     => get_permalink( $product->get_id() ),
		);
	}

	/**
	 * Adds only attributes whose name does not exist yet.
	 *
	 * @param WC_Product                        $product    Product being edited.
	 * @param array<int,array<string,string>>   $attributes Sanitized list of name/value pairs.
	 * @return array{attributes: array<int,WC_Product_Attribute>, added: string[], skipped: string[]}
	 */
	private static function merge_attributes( WC_Product $product, array $attributes ): array {
		$existing = array_values( $product->get_attributes() );
		$known    = array();

		foreach ( $existing as $attribute ) {
			if ( $attribute instanceof WC_Product_Attribute ) {
				$known[ self::normalize_label( wc_attribute_label( $attribute->get_name() ) ) ] = true;
			}
		}

		$position = count( $existing );
		$added    = array();
		$skipped  = array();

		foreach ( $attributes as $item ) {
			$key = self::normalize_label( $item['name'] );

			if ( isset( $known[ $key ] ) ) {
				$skipped[] = $item['name'];
				continue;
			}

			$attribute = new WC_Product_Attribute();
			$attribute->set_id( 0 );
			$attribute->set_name( $item['name'] );
			$attribute->set_options( array( $item['value'] ) );
			$attribute->set_position( $position++ );
			$attribute->set_visible( true );
			$attribute->set_variation( false );

			$existing[]    = $attribute;
			$known[ $key ] = true;
			$added[]       = $item['name'];
		}

		return array(
			'attributes' => $existing,
			'added'      => $added,
			'skipped'    => $skipped,
		);
	}

	/**
	 * Appends tags to the product (existing tags are always kept).
	 *
	 * @param string[] $tags Sanitized tag names.
	 * @return int[]|null The full list of tag IDs to save, or null when nothing new was added.
	 */
	private static function merge_tags( WC_Product $product, array $tags ) {
		$ids    = array_map( 'intval', $product->get_tag_ids() );
		$before = count( $ids );

		foreach ( $tags as $name ) {
			$term = get_term_by( 'name', $name, 'product_tag' );

			if ( $term instanceof WP_Term ) {
				$term_id = (int) $term->term_id;
			} else {
				$inserted = wp_insert_term( $name, 'product_tag' );

				if ( is_wp_error( $inserted ) ) {
					// Same slug already used by another tag: reuse it.
					$existing_id = $inserted->get_error_data( 'term_exists' );
					$term_id     = is_numeric( $existing_id ) ? (int) $existing_id : 0;
				} else {
					$term_id = (int) $inserted['term_id'];
				}
			}

			if ( $term_id > 0 ) {
				$ids[] = $term_id;
			}
		}

		$ids = array_values( array_unique( $ids ) );

		return count( $ids ) > $before ? $ids : null;
	}

	/**
	 * Keeps only alt texts for images that belong to this product and have no alt yet.
	 *
	 * @param array<int,array{id:int,alt:string}> $items Sanitized id/alt pairs.
	 * @return array<int,string> attachment ID => alt
	 */
	private static function pending_image_alts( WC_Product $product, array $items ): array {
		$own = array_filter(
			array_map(
				'intval',
				array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() )
			)
		);

		$pending = array();

		foreach ( $items as $item ) {
			$id = $item['id'];

			if ( ! in_array( $id, $own, true ) || 'attachment' !== get_post_type( $id ) ) {
				continue;
			}

			if ( '' !== trim( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) ) ) {
				continue;
			}

			$pending[ $id ] = $item['alt'];
		}

		return $pending;
	}

	private static function normalize_label( string $label ): string {
		$label = trim( (string) preg_replace( '/\s+/u', ' ', $label ) );

		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $label, 'UTF-8' ) : strtolower( $label );
	}

	/**
	 * Stores the SEO title/description for the product and mirrors them into the post meta keys
	 * read by Yoast SEO, Rank Math and SEOPress. Open Graph fields follow the same values,
	 * exactly like they do for articles.
	 */
	private static function save_seo_meta( int $product_id, ?string $meta_title, ?string $meta_description ) {
		$values = array();

		if ( null !== $meta_title ) {
			update_post_meta( $product_id, '_sevof_meta_title', $meta_title );
			update_post_meta( $product_id, '_sevof_og_title', $meta_title );
			$values['meta_title'] = $meta_title;
			$values['og_title']   = $meta_title;
		}

		if ( null !== $meta_description ) {
			update_post_meta( $product_id, '_sevof_meta_description', $meta_description );
			update_post_meta( $product_id, '_sevof_og_description', $meta_description );
			$values['meta_description'] = $meta_description;
			$values['og_description']   = $meta_description;
		}

		// The marker must exist before the front end can print the fallback tags.
		update_post_meta( $product_id, self::SEO_MARK_META_KEY, '1' );

		Sevof_Connector_Seo::sync_third_party_meta( $product_id, $values );
	}

	/**
	 * The focus keyword already stored by an ACTIVE SEO plugin (Rank Math, Yoast, SEOPress), or ''.
	 * Sevof's own meta is deliberately ignored, so a keyword Sevof wrote earlier can be refreshed.
	 */
	private static function existing_focus_keyword( int $product_id ): string {
		$keys = array();

		if ( defined( 'RANK_MATH_VERSION' ) ) {
			$keys[] = 'rank_math_focus_keyword';
		}
		if ( defined( 'WPSEO_VERSION' ) ) {
			$keys[] = '_yoast_wpseo_focuskw';
		}
		if ( defined( 'SEOPRESS_VERSION' ) ) {
			$keys[] = '_seopress_analysis_target_kw';
		}

		foreach ( $keys as $key ) {
			$value = trim( (string) get_post_meta( $product_id, $key, true ) );
			if ( '' !== $value ) {
				return $value;
			}
		}

		return '';
	}

	/**
	 * Stores the focus keyword in Sevof's own meta and in every active SEO plugin.
	 */
	private static function save_focus_keyword( int $product_id, string $keyword ) {
		update_post_meta( $product_id, '_sevof_focus_keyword', $keyword );

		if ( defined( 'RANK_MATH_VERSION' ) ) {
			update_post_meta( $product_id, 'rank_math_focus_keyword', $keyword );
		}

		if ( defined( 'WPSEO_VERSION' ) ) {
			update_post_meta( $product_id, '_yoast_wpseo_focuskw', $keyword );
		}

		if ( defined( 'SEOPRESS_VERSION' ) ) {
			update_post_meta( $product_id, '_seopress_analysis_target_kw', $keyword );
		}
	}

	/* ------------------------------------------------------------------ */
	/*  FAQ block                                                           */
	/* ------------------------------------------------------------------ */

	private static function marked_pattern( string $start, string $end ): string {
		return '/' . preg_quote( $start, '/' ) . '(.*?)' . preg_quote( $end, '/' ) . '/su';
	}

	private static function extract_marked_block( string $html, string $start, string $end ): string {
		return preg_match( self::marked_pattern( $start, $end ), $html, $matches ) ? trim( $matches[1] ) : '';
	}

	/**
	 * Removes both Sevof marker blocks (SEO text and FAQ), leaving the store's own content.
	 */
	private static function strip_sevof_blocks( string $html ): string {
		$html = (string) preg_replace( self::marked_pattern( self::DESC_START, self::DESC_END ), '', $html );

		return self::strip_faq_block( $html );
	}

	private static function faq_pattern(): string {
		return '/' . preg_quote( self::FAQ_START, '/' ) . '(.*?)' . preg_quote( self::FAQ_END, '/' ) . '/su';
	}

	private static function strip_faq_block( string $html ): string {
		return trim( (string) preg_replace( self::faq_pattern(), '', $html ) );
	}

	private static function extract_faq_block( string $html ): string {
		return preg_match( self::faq_pattern(), $html, $matches ) ? trim( $matches[1] ) : '';
	}

	/**
	 * Accordion FAQ for products with no styling of their own. Same markup as the article FAQ
	 * (`<details>`/`<summary>` survive KSES and need no JavaScript); it is colored on the front
	 * end by the brand CSS, so nothing visual is stored in the product itself.
	 *
	 * @param array<int,array{question:string,answer:string}> $faq Sanitized FAQ rows.
	 */
	private static function faq_html_branded( array $faq ): string {
		$items = '';

		foreach ( $faq as $row ) {
			$items .= '<details class="sevof-faq-item"><summary class="sevof-faq-question">'
				. esc_html( $row['question'] )
				. '</summary><div class="sevof-faq-answer"><p>' . esc_html( $row['answer'] ) . '</p></div></details>';
		}

		if ( '' === $items ) {
			return '';
		}

		$heading = __( 'Frequently asked questions', 'sevof-connector' );

		return '<section class="sevof-faq" aria-label="' . esc_attr( $heading ) . '"><h2 class="sevof-faq-title">'
			. esc_html( $heading ) . '</h2>' . $items . '</section>';
	}

	/**
	 * FAQ for products that already have their own styled content. It copies the store's own
	 * pattern instead of introducing a new look:
	 *  - the store uses <details>/<summary>: same tags with the same classes/attributes;
	 *  - otherwise: heading + question headings + paragraphs wearing the attributes (classes,
	 *    inline style) of the store's own h2 / h3 / p, so the theme or page builder styles them.
	 *
	 * @param array<int,array{question:string,answer:string}> $faq   Sanitized FAQ rows.
	 * @param string                                          $store The store's own description markup.
	 */
	private static function faq_html_themed( array $faq, string $store ): string {
		if ( empty( $faq ) ) {
			return '';
		}

		$attrs = self::store_tag_attrs( $store );
		$h2    = isset( $attrs['h2'] ) ? $attrs['h2'] : '';
		$h3    = isset( $attrs['h3'] ) ? $attrs['h3'] : '';
		$p     = isset( $attrs['p'] ) ? $attrs['p'] : '';
		// Never print a second "FAQ" heading below one the store already has.
		$title = self::has_own_faq( $store ) ? __( 'More questions', 'sevof-connector' ) : __( 'Frequently asked questions', 'sevof-connector' );
		$items = '';

		if ( preg_match( '/<details(\s[^>]*)?>\s*<summary(\s[^>]*)?>/i', $store, $m ) ) {
			$details = self::clean_attrs( isset( $m[1] ) ? $m[1] : '', array( 'id', 'open' ) );
			$summary = self::clean_attrs( isset( $m[2] ) ? $m[2] : '', array( 'id' ) );

			foreach ( $faq as $row ) {
				$items .= '<details' . $details . '><summary' . $summary . '>' . esc_html( $row['question'] )
					. '</summary><p' . $p . '>' . esc_html( $row['answer'] ) . '</p></details>';
			}
		} else {
			foreach ( $faq as $row ) {
				$items .= '<h3' . $h3 . '>' . esc_html( $row['question'] ) . '</h3><p' . $p . '>' . esc_html( $row['answer'] ) . '</p>';
			}
		}

		return wp_kses_post( '<h2' . $h2 . '>' . esc_html( $title ) . '</h2>' . $items );
	}

	/**
	 * The SEO description for a product that has its own styled content: plain semantic HTML
	 * whose tags wear the attributes of the store's own headings / paragraphs / lists.
	 */
	private static function themed_description_html( string $description, string $store ): string {
		return wp_kses_post( self::apply_tag_attrs( $description, self::store_tag_attrs( $store ) ) );
	}

	/* ------------------------------------------------------------------ */
	/*  Style detection                                                     */
	/* ------------------------------------------------------------------ */

	/**
	 * Decides how new content must be presented on this product page.
	 *
	 *  "themed"  - the product already has a styled structure of its own; Sevof must not
	 *              replace it and must not print its own CSS.
	 *  "branded" - nothing styled: Sevof content is styled like an article, from the logo color.
	 *
	 * Override: the `sevof_connector_product_style_mode` option or filter ("auto" | "themed" | "branded").
	 *
	 * @param string $store Description with Sevof's own blocks removed.
	 * @param string $short Current short description.
	 * @return array{mode:string,reason:string}
	 */
	private static function detect_style( WC_Product $product, string $store, string $short ): array {
		$forced = self::forced_mode( $product );
		if ( '' !== $forced ) {
			return array(
				'mode'   => $forced,
				'reason' => 'forced',
			);
		}

		$builder = self::page_builder_in_use( $product->get_id() );
		if ( '' !== $builder ) {
			return array(
				'mode'   => 'themed',
				'reason' => 'page_builder:' . $builder,
			);
		}

		$signal = self::styled_markup_signal( $store );
		if ( '' !== $signal ) {
			return array(
				'mode'   => 'themed',
				'reason' => 'description_markup:' . $signal,
			);
		}

		// The product itself is plain, but the site's theme / product template may style it.
		$theme = self::theme_level_signal();
		if ( '' !== $theme ) {
			return array(
				'mode'   => 'themed',
				'reason' => 'site_template:' . $theme,
			);
		}

		return array(
			'mode'   => 'branded',
			'reason' => 'no_existing_style',
		);
	}

	/**
	 * The manual override: "themed" / "branded", or '' for automatic detection.
	 * Option `sevof_connector_product_style_mode`, filter `sevof_connector_product_style_mode`.
	 *
	 * @param WC_Product|null $product Product being written, null when rendering.
	 */
	private static function forced_mode( $product = null ): string {
		$value = apply_filters( 'sevof_connector_product_style_mode', (string) get_option( 'sevof_connector_product_style_mode', 'auto' ), $product );

		return in_array( $value, array( 'themed', 'branded' ), true ) ? $value : '';
	}

	/**
	 * Site-wide check: does the active theme or the product template give the description
	 * its own design? Returns a short identifier, or '' when nothing like that is found.
	 *
	 * Signals: a known "styled" theme (parent or child), an Elementor Pro Single Product
	 * template, or a block theme whose single-product template was designed (theme or user).
	 * Filter `sevof_connector_product_theme_signal` can add or clear the result.
	 */
	private static function theme_level_signal(): string {
		if ( null !== self::$theme_signal ) {
			return self::$theme_signal;
		}

		$signal = '';

		try {
			$themes = (array) apply_filters( 'sevof_connector_styled_product_themes', self::STYLED_THEMES );
			$themes = array_map( 'strtolower', array_map( 'strval', $themes ) );
			$slugs  = array();

			if ( function_exists( 'get_template' ) ) {
				$slugs[] = strtolower( (string) get_template() );
			}
			if ( function_exists( 'get_stylesheet' ) ) {
				$slugs[] = strtolower( (string) get_stylesheet() );
			}

			foreach ( $slugs as $slug ) {
				if ( '' !== $slug && in_array( $slug, $themes, true ) ) {
					$signal = 'theme:' . $slug;
					break;
				}
			}

			if ( '' === $signal ) {
				$signal = self::elementor_product_template_signal();
			}

			if ( '' === $signal ) {
				$signal = self::block_product_template_signal();
			}
		} catch ( Throwable $e ) {
			$signal = '';
		}

		self::$theme_signal = (string) apply_filters( 'sevof_connector_product_theme_signal', $signal );

		return self::$theme_signal;
	}

	/**
	 * Elementor Pro "Single Product" template that applies to products (best effort: it reads
	 * Elementor Pro's stored display conditions).
	 */
	private static function elementor_product_template_signal(): string {
		$conditions = get_option( 'elementor_pro_theme_builder_conditions', array() );
		if ( ! is_array( $conditions ) ) {
			return '';
		}

		foreach ( array( 'single', 'product' ) as $location ) {
			if ( empty( $conditions[ $location ] ) || ! is_array( $conditions[ $location ] ) ) {
				continue;
			}

			foreach ( $conditions[ $location ] as $template_id => $rules ) {
				if ( 'publish' !== get_post_status( (int) $template_id ) ) {
					continue;
				}

				foreach ( (array) $rules as $rule ) {
					if ( is_string( $rule ) && ( 0 === strpos( $rule, 'include/singular/product' ) || 'include/singular' === $rule ) ) {
						return 'elementor_single_template';
					}
				}
			}
		}

		return '';
	}

	/**
	 * Block (FSE) themes: the WooCommerce default single-product template comes from the plugin;
	 * one supplied by the theme or edited in the Site Editor is a designed layout.
	 */
	private static function block_product_template_signal(): string {
		if ( ! function_exists( 'wp_is_block_theme' ) || ! wp_is_block_theme() || ! function_exists( 'get_block_templates' ) ) {
			return '';
		}

		$templates = get_block_templates( array( 'slug__in' => array( 'single-product' ) ), 'wp_template' );
		if ( ! is_array( $templates ) ) {
			return '';
		}

		foreach ( $templates as $template ) {
			$source = is_object( $template ) && isset( $template->source ) ? (string) $template->source : '';
			if ( 'custom' === $source || 'theme' === $source ) {
				return 'block_template:' . $source;
			}
		}

		return '';
	}

	/**
	 * Name of the page builder that renders this product, or ''.
	 */
	private static function page_builder_in_use( int $product_id ): string {
		if ( 'builder' === get_post_meta( $product_id, '_elementor_edit_mode', true ) && '' !== (string) get_post_meta( $product_id, '_elementor_data', true ) ) {
			return 'elementor';
		}

		if ( 'on' === get_post_meta( $product_id, '_et_pb_use_builder', true ) ) {
			return 'divi';
		}

		if ( '' !== (string) get_post_meta( $product_id, '_fl_builder_enabled', true ) && '0' !== (string) get_post_meta( $product_id, '_fl_builder_enabled', true ) ) {
			return 'beaver';
		}

		if ( 'true' === get_post_meta( $product_id, '_wpb_vc_js_status', true ) ) {
			return 'wpbakery';
		}

		if ( '' !== (string) get_post_meta( $product_id, 'ct_builder_json', true ) ) {
			return 'oxygen';
		}

		return '';
	}

	/**
	 * Returns why this markup counts as "the store's own styled structure", or '' when it is
	 * plain content (bare headings, paragraphs, lists, links, images).
	 *
	 * Deliberately NOT a signal: alignment/direction inline styles (the classic editor adds them
	 * on RTL sites) and WordPress core classes (wp-*, align*, size-*, has-*, is-*).
	 */
	private static function styled_markup_signal( string $html ): string {
		if ( '' === trim( $html ) ) {
			return '';
		}

		if ( preg_match( '/\[(?:vc_|et_pb_|fusion_|fl_builder|elementor|av_|su_|ult_|tabs\b|accordion\b|toggle\b)/i', $html ) ) {
			return 'shortcode';
		}

		if ( preg_match_all( '/\sstyle\s*=\s*(?:"([^"]*)"|\'([^\']*)\')/i', $html, $m ) ) {
			foreach ( array_merge( $m[1], $m[2] ) as $css ) {
				foreach ( explode( ';', (string) $css ) as $declaration ) {
					$property = strtolower( trim( (string) strstr( $declaration, ':', true ) ) );
					if ( '' !== $property && ! in_array( $property, array( 'text-align', 'direction', 'unicode-bidi' ), true ) ) {
						return 'inline_style';
					}
				}
			}
		}

		if ( preg_match( '/<(?:table|details|dl|section|aside|iframe)\b/i', $html ) ) {
			return 'structured_element';
		}

		if ( preg_match_all( '/\sclass\s*=\s*(?:"([^"]*)"|\'([^\']*)\')/i', $html, $m ) ) {
			foreach ( array_merge( $m[1], $m[2] ) as $value ) {
				foreach ( preg_split( '/\s+/', trim( (string) $value ) ) as $token ) {
					if ( '' === $token ) {
						continue;
					}

					if ( preg_match( '/^(?:wp-|align(?:none|left|right|center|wide|full)$|size-|attachment-|has-|is-|screen-reader|sevof-)/i', $token ) ) {
						continue;
					}

					return 'custom_class';
				}
			}
		}

		return '';
	}

	/**
	 * True when the store's own content already has an FAQ section heading.
	 */
	private static function has_own_faq( string $store ): bool {
		if ( ! preg_match_all( '~<h[1-6][^>]*>(.*?)</h[1-6]>~isu', $store, $matches ) ) {
			return false;
		}

		foreach ( $matches[1] as $heading ) {
			if ( Sevof_Connector_Rest_Controller::is_faq_heading( (string) $heading ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether the new FAQ may also be printed as FAQPage JSON-LD. Structured data must describe
	 * content that is really visible, and a page must not carry two FAQPage entities, so it is
	 * skipped when the FAQ is not rendered from the product description (the product is built
	 * with a page builder) or when the store already shows an FAQ of its own.
	 * Filter: `sevof_connector_product_faq_schema`.
	 *
	 * @param array{mode:string,reason:string}|null $style Style decision of this request.
	 */
	private static function faq_schema_allowed( WC_Product $product, $style, string $store ): bool {
		$allowed = true;

		if ( is_array( $style ) && 0 === strpos( $style['reason'], 'page_builder:' ) ) {
			$allowed = false;
		}

		if ( $allowed && self::has_own_faq( $store ) ) {
			$allowed = false;
		}

		return (bool) apply_filters( 'sevof_connector_product_faq_schema', $allowed, $product );
	}

	/**
	 * First-seen attributes (classes, inline style, data-*) of the store's own h2/h3/h4/p/ul/ol,
	 * without ids, so new content can wear exactly the same look.
	 *
	 * @return array<string,string> tag => ' attr="..." attr="..."'
	 */
	private static function store_tag_attrs( string $html ): array {
		$out = array();

		foreach ( array( 'h2', 'h3', 'h4', 'p', 'ul', 'ol' ) as $tag ) {
			if ( preg_match( '/<' . $tag . '(\s[^>]*)?>/i', $html, $m ) ) {
				$attrs = self::clean_attrs( isset( $m[1] ) ? $m[1] : '', array( 'id' ) );
				if ( '' !== $attrs ) {
					$out[ $tag ] = $attrs;
				}
			}
		}

		return $out;
	}

	/**
	 * Adds the given attributes to every bare `<tag>` of the HTML.
	 *
	 * @param array<string,string> $attrs tag => ' attr="..."'
	 */
	private static function apply_tag_attrs( string $html, array $attrs ): string {
		foreach ( $attrs as $tag => $attr_string ) {
			$html = (string) preg_replace_callback(
				'/<' . $tag . '>/i',
				static function () use ( $tag, $attr_string ) {
					return '<' . $tag . $attr_string . '>';
				},
				$html
			);
		}

		return $html;
	}

	/**
	 * Re-serializes an attribute string, dropping the listed attribute names.
	 *
	 * @param string[] $drop Lower-case attribute names to remove.
	 */
	private static function clean_attrs( string $attrs, array $drop ): string {
		$out = array();

		if ( preg_match_all( '/([a-zA-Z_:][-\w:.]*)(?:\s*=\s*("[^"]*"|\'[^\']*\'|[^\s"\'>]+))?/', $attrs, $matches, PREG_SET_ORDER ) ) {
			foreach ( $matches as $match ) {
				if ( in_array( strtolower( $match[1] ), $drop, true ) ) {
					continue;
				}

				if ( isset( $match[2] ) && '' !== $match[2] ) {
					$value = $match[2];
					if ( '"' !== $value[0] && "'" !== $value[0] ) {
						$value = '"' . esc_attr( $value ) . '"';
					}
					$out[] = $match[1] . '=' . $value;
				} else {
					$out[] = $match[1];
				}
			}
		}

		return empty( $out ) ? '' : ' ' . implode( ' ', $out );
	}

	/* ------------------------------------------------------------------ */
	/*  Front end                                                           */
	/* ------------------------------------------------------------------ */

	/**
	 * True only for products whose Sevof content was written in "branded" mode.
	 */
	private static function is_branded_product( int $product_id ): bool {
		if (
			$product_id <= 0
			|| '1' !== get_post_meta( $product_id, self::SEO_MARK_META_KEY, true )
			|| 'branded' !== get_post_meta( $product_id, self::STYLE_MODE_META_KEY, true )
		) {
			return false;
		}

		// Re-checked at display time: a theme or product template installed after the content was
		// written must still win over Sevof's colors, unless the owner forced "branded".
		$forced = self::forced_mode();
		if ( 'themed' === $forced ) {
			return false;
		}

		return 'branded' === $forced || '' === self::theme_level_signal();
	}

	/**
	 * Prints the logo-colored stylesheet on "branded" product pages only. Products that kept
	 * their own styling ("themed") and products Sevof never touched get nothing.
	 */
	public static function print_product_styles() {
		if ( ! is_singular( 'product' ) || ! self::is_branded_product( (int) get_queried_object_id() ) ) {
			return;
		}

		if ( ! class_exists( 'Sevof_Connector_Rest_Controller' ) || ! method_exists( 'Sevof_Connector_Rest_Controller', 'branded_css' ) ) {
			return;
		}

		$css = Sevof_Connector_Rest_Controller::branded_css();
		// The article product-card component is not used inside a product description.
		$css = (string) preg_replace( '~/\* -+ Product cards -+ \*/.*?(?=/\* -+ Tables -+ \*/)~s', '', $css );
		if ( '' === trim( $css ) ) {
			return;
		}

		echo '<style id="sevof-connector-product-styles">' . "\n" . $css . "\n</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS built from validated hex/rgba tokens only; tags stripped.
	}

	/**
	 * Scopes the description of a "branded" product in `.sevof-article-body` (the same wrapper
	 * the article styles hang on). The stored HTML itself stays clean.
	 *
	 * @param string $content Post content after the other the_content filters.
	 * @return string
	 */
	public static function wrap_product_description( $content ) {
		if ( ! is_string( $content ) || '' === trim( $content ) ) {
			return $content;
		}

		if ( is_feed() || doing_filter( 'get_the_excerpt' ) || ! is_singular( 'product' ) || ! is_main_query() ) {
			return $content;
		}

		$product_id = (int) get_the_ID();
		if ( $product_id <= 0 || $product_id !== (int) get_queried_object_id() || ! self::is_branded_product( $product_id ) ) {
			return $content;
		}

		if ( false !== strpos( $content, 'sevof-article-body' ) ) {
			return $content;
		}

		return '<div class="sevof-article-body">' . $content . '</div>';
	}

	/* ------------------------------------------------------------------ */
	/*  Request parameter cleaning                                          */
	/* ------------------------------------------------------------------ */

	/**
	 * Returns sanitized post-style HTML, or null when the field is absent, empty or
	 * contained nothing but disallowed markup (so it can never blank a field).
	 */
	private static function clean_html_param( WP_REST_Request $request, string $key ): ?string {
		if ( ! $request->has_param( $key ) ) {
			return null;
		}

		$value = $request->get_param( $key );
		if ( ! is_string( $value ) || '' === trim( $value ) ) {
			return null;
		}

		$value = trim( wp_kses_post( $value ) );

		return '' === trim( wp_strip_all_tags( $value ) ) && false === stripos( $value, '<img' ) ? null : $value;
	}

	private static function clean_text_param( WP_REST_Request $request, string $key ): ?string {
		if ( ! $request->has_param( $key ) ) {
			return null;
		}

		$value = $request->get_param( $key );
		if ( ! is_string( $value ) ) {
			return null;
		}

		$value = sanitize_text_field( $value );

		return '' === $value ? null : $value;
	}

	/**
	 * @return array<int,array{name: string, value: string}>
	 */
	private static function clean_attributes_param( WP_REST_Request $request ): array {
		if ( ! $request->has_param( 'attributes' ) ) {
			return array();
		}

		$raw = $request->get_param( 'attributes' );
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$clean = array();

		foreach ( $raw as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$name = sanitize_text_field( (string) ( $item['name'] ?? '' ) );
			// "|" is WooCommerce's separator between the values of one attribute.
			$value = trim( str_replace( '|', '/', sanitize_text_field( (string) ( $item['value'] ?? '' ) ) ) );

			if ( '' === $name || '' === $value ) {
				continue;
			}

			$clean[] = array(
				'name'  => $name,
				'value' => $value,
			);
		}

		return $clean;
	}

	/**
	 * @return string[] Unique, sanitized tag names.
	 */
	private static function clean_tags_param( WP_REST_Request $request ): array {
		if ( ! $request->has_param( 'tags' ) ) {
			return array();
		}

		$raw = $request->get_param( 'tags' );
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$clean = array();

		foreach ( $raw as $tag ) {
			if ( ! is_string( $tag ) ) {
				continue;
			}

			$name = trim( sanitize_text_field( $tag ), " \t\n\r\0\x0B#،,;؛" );
			$key  = self::normalize_label( $name );
			$len  = function_exists( 'mb_strlen' ) ? mb_strlen( $name, 'UTF-8' ) : strlen( $name );

			if ( '' === $name || $len < 2 || $len > self::MAX_TAG_LENGTH || isset( $clean[ $key ] ) ) {
				continue;
			}

			$clean[ $key ] = $name;
		}

		return array_values( $clean );
	}

	/**
	 * @return array<int,array{question: string, answer: string}>
	 */
	private static function clean_faq_param( WP_REST_Request $request ): array {
		if ( ! $request->has_param( 'faq' ) ) {
			return array();
		}

		$raw = $request->get_param( 'faq' );
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$clean = array();
		$seen  = array();

		foreach ( $raw as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$question = sanitize_text_field( (string) ( $item['question'] ?? '' ) );
			$answer   = sanitize_text_field( (string) ( $item['answer'] ?? '' ) );
			$key      = self::normalize_label( $question );

			if ( '' === $question || '' === $answer || isset( $seen[ $key ] ) ) {
				continue;
			}

			if ( ! preg_match( '/[?\x{061F}]$/u', $question ) ) {
				// Arabic text takes the Arabic question mark.
				$question .= preg_match( '/\p{Arabic}/u', $question ) ? "\u{061F}" : '?';
			}

			$seen[ $key ] = true;
			$clean[]      = array(
				'question' => $question,
				'answer'   => $answer,
			);

			if ( count( $clean ) >= self::MAX_FAQ_ITEMS ) {
				break;
			}
		}

		return $clean;
	}

	/**
	 * @return array<int,array{id: int, alt: string}>
	 */
	private static function clean_image_alts_param( WP_REST_Request $request ): array {
		if ( ! $request->has_param( 'image_alts' ) ) {
			return array();
		}

		$raw = $request->get_param( 'image_alts' );
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$clean = array();

		foreach ( $raw as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$id  = absint( $item['id'] ?? 0 );
			$alt = sanitize_text_field( (string) ( $item['alt'] ?? '' ) );

			if ( $id > 0 && '' !== $alt ) {
				$clean[ $id ] = array(
					'id'  => $id,
					'alt' => $alt,
				);
			}
		}

		return array_values( $clean );
	}

	/* ------------------------------------------------------------------ */
	/*  Argument schemas / validators                                       */
	/* ------------------------------------------------------------------ */

	private static function id_arguments(): array {
		return array(
			'id' => array(
				'description'       => __( 'The WooCommerce product ID.', 'sevof-connector' ),
				'type'              => 'integer',
				'required'          => true,
				'sanitize_callback' => 'absint',
				'validate_callback' => array( Sevof_Connector_Rest_Controller::class, 'validate_positive_integer' ),
			),
		);
	}

	private static function update_arguments(): array {
		return array(
			'payload_version'   => array(
				'required'          => false,
				'validate_callback' => array( self::class, 'validate_scalar' ),
			),
			'source_type'       => array(
				'type'              => 'string',
				'required'          => false,
				'nullable'          => true,
				'sanitize_callback' => 'sanitize_key',
				'validate_callback' => array( self::class, 'validate_source_type' ),
			),
			'product_id'        => array(
				'required'          => false,
				'validate_callback' => array( self::class, 'validate_body_product_id' ),
			),
			'short_description' => array(
				'type'              => 'string',
				'required'          => false,
				'nullable'          => true,
				'validate_callback' => array( self::class, 'validate_short_description' ),
			),
			'description'       => array(
				'type'              => 'string',
				'required'          => false,
				'nullable'          => true,
				'validate_callback' => array( self::class, 'validate_description' ),
			),
			'meta_title'        => array(
				'type'              => 'string',
				'required'          => false,
				'nullable'          => true,
				'validate_callback' => array( Sevof_Connector_Rest_Controller::class, 'validate_meta_text' ),
			),
			'meta_description'  => array(
				'type'              => 'string',
				'required'          => false,
				'nullable'          => true,
				'validate_callback' => array( Sevof_Connector_Rest_Controller::class, 'validate_meta_text' ),
			),
			'focus_keyword'     => array(
				'type'              => 'string',
				'required'          => false,
				'nullable'          => true,
				'validate_callback' => array( self::class, 'validate_focus_keyword' ),
			),
			'attributes'        => array(
				'type'              => 'array',
				'required'          => false,
				'nullable'          => true,
				'validate_callback' => array( self::class, 'validate_attributes' ),
			),
			'tags'              => array(
				'type'              => 'array',
				'required'          => false,
				'nullable'          => true,
				'validate_callback' => array( self::class, 'validate_tags' ),
			),
			'faq'               => array(
				'type'              => 'array',
				'required'          => false,
				'nullable'          => true,
				'validate_callback' => array( self::class, 'validate_faq' ),
			),
			'image_alts'        => array(
				'type'              => 'array',
				'required'          => false,
				'nullable'          => true,
				'validate_callback' => array( self::class, 'validate_image_alts' ),
			),
		);
	}

	public static function validate_scalar( $value ): bool {
		return null === $value || is_scalar( $value );
	}

	public static function validate_source_type( $value ): bool {
		return null === $value || self::SOURCE_TYPE === $value;
	}

	/**
	 * product_id in the body is redundant with the URL; when present it must match, so a request
	 * signed for one product can never be redirected at another.
	 */
	public static function validate_body_product_id( $value, $request = null ): bool {
		if ( null === $value ) {
			return true;
		}

		if ( ! Sevof_Connector_Rest_Controller::validate_positive_integer( $value ) ) {
			return false;
		}

		return ! ( $request instanceof WP_REST_Request ) || (int) $value === absint( $request->get_param( 'id' ) );
	}

	public static function validate_short_description( $value ): bool {
		return null === $value || ( is_string( $value ) && strlen( $value ) <= self::MAX_SHORT_DESCRIPTION_BYTES );
	}

	public static function validate_description( $value ): bool {
		return null === $value || ( is_string( $value ) && strlen( $value ) <= self::MAX_DESCRIPTION_BYTES );
	}

	public static function validate_focus_keyword( $value ): bool {
		return null === $value || ( is_string( $value ) && strlen( $value ) <= self::MAX_FOCUS_KEYWORD_LENGTH * 4 );
	}

	public static function validate_attributes( $value ): bool {
		if ( null === $value ) {
			return true;
		}

		if ( ! is_array( $value ) || count( $value ) > self::MAX_ATTRIBUTES ) {
			return false;
		}

		foreach ( $value as $item ) {
			if ( ! is_array( $item ) || ! isset( $item['name'], $item['value'] ) || ! is_string( $item['name'] ) || ! is_string( $item['value'] ) ) {
				return false;
			}

			if ( strlen( $item['name'] ) > self::MAX_ATTRIBUTE_NAME_LENGTH || strlen( $item['value'] ) > self::MAX_ATTRIBUTE_VALUE_LENGTH ) {
				return false;
			}
		}

		return true;
	}

	public static function validate_tags( $value ): bool {
		if ( null === $value ) {
			return true;
		}

		if ( ! is_array( $value ) || count( $value ) > self::MAX_TAGS ) {
			return false;
		}

		foreach ( $value as $tag ) {
			// Byte length (non-Latin text is multi-byte); the exact character limit is enforced when cleaning.
			if ( ! is_string( $tag ) || strlen( $tag ) > self::MAX_TAG_LENGTH * 4 ) {
				return false;
			}
		}

		return true;
	}

	public static function validate_faq( $value ): bool {
		if ( null === $value ) {
			return true;
		}

		if ( ! is_array( $value ) || count( $value ) > self::MAX_FAQ_ITEMS * 2 ) {
			return false;
		}

		foreach ( $value as $item ) {
			if ( ! is_array( $item ) || ! isset( $item['question'], $item['answer'] ) || ! is_string( $item['question'] ) || ! is_string( $item['answer'] ) ) {
				return false;
			}

			if ( strlen( $item['question'] ) > self::MAX_FAQ_QUESTION_LENGTH * 4 || strlen( $item['answer'] ) > self::MAX_FAQ_ANSWER_LENGTH * 4 ) {
				return false;
			}
		}

		return true;
	}

	public static function validate_image_alts( $value ): bool {
		if ( null === $value ) {
			return true;
		}

		if ( ! is_array( $value ) || count( $value ) > self::MAX_IMAGE_ALTS ) {
			return false;
		}

		foreach ( $value as $item ) {
			if ( ! is_array( $item ) || ! isset( $item['id'], $item['alt'] ) || ! is_string( $item['alt'] ) ) {
				return false;
			}

			if ( ! Sevof_Connector_Rest_Controller::validate_positive_integer( $item['id'] ) || strlen( $item['alt'] ) > self::MAX_IMAGE_ALT_LENGTH * 4 ) {
				return false;
			}
		}

		return true;
	}

	/* ------------------------------------------------------------------ */
	/*  Error responses                                                     */
	/* ------------------------------------------------------------------ */

	private static function not_found_response(): WP_REST_Response {
		return new WP_REST_Response(
			array(
				'code'    => 'sevof_product_not_found',
				'message' => __( 'The requested WooCommerce product was not found.', 'sevof-connector' ),
			),
			404
		);
	}

	private static function woocommerce_inactive_response(): WP_REST_Response {
		return new WP_REST_Response(
			array(
				'code'    => 'sevof_woocommerce_inactive',
				'message' => __( 'WooCommerce is not active on this site.', 'sevof-connector' ),
			),
			409
		);
	}

	private static function internal_error_response( Throwable $error, int $product_id ): WP_REST_Response {
		sevof_connector_log(
			'product_update_exception',
			array(
				'product_id' => $product_id,
				'reason'     => $error->getMessage(),
			)
		);

		return new WP_REST_Response(
			array(
				'code'          => 'sevof_product_update_exception',
				'message'       => __( 'An internal error occurred while updating the product.', 'sevof-connector' ),
				'detail'        => sanitize_text_field( $error->getMessage() ),
				'wp_product_id' => $product_id,
			),
			500
		);
	}
}