<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Lets the Sevof service read and update the site's older posts, the ones that
 * were NOT created by this connector ("past articles").
 *
 * Safety rules:
 *  - Only published, non-password-protected posts of type "post" that are not
 *    connector-managed. Managed posts keep using the /articles endpoints.
 *  - Posts built with a page builder (Elementor, Divi, WPBakery, ...) are listed
 *    but reported as not editable: their visible content is not post_content, so
 *    changing it would either do nothing or break the layout.
 *  - Every update must send the post's last-modified time it was based on; if
 *    the post changed in WordPress since then the update is refused (409), so a
 *    manual edit is never overwritten.
 *  - wp_update_post() keeps the normal WordPress revision, so the site owner can
 *    also restore the previous version from the WordPress editor.
 */
class Sevof_Connector_Existing_Posts {

	const MAX_PER_PAGE      = 50;
	const MAX_CONTENT_BYTES = 1500000;
	const MAX_META_LENGTH   = 400;
	const REFRESH_META_KEY  = '_sevof_last_refresh';

	public static function init() {
		static $initialized = false;
		if ( $initialized ) {
			return;
		}
		$initialized = true;

		add_action( 'rest_api_init', array( self::class, 'register_routes' ) );
	}

	public static function register_routes() {
		register_rest_route(
			Sevof_Connector_Rest_Controller::NAMESPACE,
			'/existing-posts',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'list_posts' ),
				'permission_callback' => array( Sevof_Connector_Rest_Controller::class, 'verify_signature' ),
				'args'                => array(
					'page'     => array(
						'type'              => 'integer',
						'default'           => 1,
						'sanitize_callback' => 'absint',
					),
					'per_page' => array(
						'type'              => 'integer',
						'default'           => 20,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		register_rest_route(
			Sevof_Connector_Rest_Controller::NAMESPACE,
			'/existing-posts/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( self::class, 'show_post' ),
					'permission_callback' => array( Sevof_Connector_Rest_Controller::class, 'verify_signature' ),
					'args'                => self::id_argument(),
				),
				array(
					'methods'             => 'PUT',
					'callback'            => array( self::class, 'update_post' ),
					'permission_callback' => array( Sevof_Connector_Rest_Controller::class, 'verify_signature' ),
					'args'                => array_merge(
						self::id_argument(),
						array(
							'content'           => array(
								'type'     => 'string',
								'required' => true,
							),
							'expected_modified' => array(
								'type'              => 'string',
								'required'          => true,
								'sanitize_callback' => 'sanitize_text_field',
							),
							'meta_title'        => array(
								'type'              => 'string',
								'sanitize_callback' => 'sanitize_text_field',
							),
							'meta_description'  => array(
								'type'              => 'string',
								'sanitize_callback' => 'sanitize_textarea_field',
							),
						)
					),
				),
			)
		);
	}

	/**
	 * Paginated list of the site's own published posts (newest first).
	 */
	public static function list_posts( WP_REST_Request $request ): WP_REST_Response {
		$per_page = min( self::MAX_PER_PAGE, max( 1, (int) $request->get_param( 'per_page' ) ) );
		$page     = max( 1, (int) $request->get_param( 'page' ) );

		$query = new WP_Query(
			array(
				'post_type'           => self::article_post_types(),
				'post_status'         => 'publish',
				// Polylang/WPML: every language, not only the default one.
				'lang'                => '',
				'has_password'        => false,
				'posts_per_page'      => $per_page,
				'paged'               => $page,
				'orderby'             => 'date',
				'order'               => 'DESC',
				'ignore_sticky_posts' => true,
				'suppress_filters'    => true,
				'meta_query'          => array(
					'relation' => 'OR',
					array(
						'key'     => Sevof_Connector_Rest_Controller::MANAGED_META_KEY,
						'compare' => 'NOT EXISTS',
					),
					array(
						'key'     => Sevof_Connector_Rest_Controller::MANAGED_META_KEY,
						'value'   => '1',
						'compare' => '!=',
					),
				),
			)
		);

		$items = array();
		foreach ( $query->posts as $post ) {
			$editability = self::editability( $post );
			$items[]     = array(
				'id'                  => (int) $post->ID,
				'post_type'           => $post->post_type,
				'title'               => html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ),
				'link'                => get_permalink( $post ),
				'date'                => $post->post_date_gmt,
				'modified'            => $post->post_modified_gmt,
				'word_count'          => self::word_count( $post->post_content ),
				'editable'            => $editability['editable'],
				'not_editable_reason' => $editability['reason'],
				'last_refresh'        => (string) get_post_meta( $post->ID, self::REFRESH_META_KEY, true ),
			);
		}

		return new WP_REST_Response(
			array(
				'items' => $items,
				'page'  => $page,
				'pages' => (int) $query->max_num_pages,
				'total' => (int) $query->found_posts,
			),
			200
		);
	}

	/**
	 * Full raw content of one post plus its current SEO title/description.
	 */
	public static function show_post( WP_REST_Request $request ): WP_REST_Response {
		$post = self::get_existing_post( absint( $request->get_param( 'id' ) ) );
		if ( ! $post ) {
			return self::not_found();
		}

		return new WP_REST_Response( self::post_payload( $post ), 200 );
	}

	/**
	 * Replaces the post content (and optionally the SEO title/description).
	 */
	public static function update_post( WP_REST_Request $request ): WP_REST_Response {
		$post = self::get_existing_post( absint( $request->get_param( 'id' ) ) );
		if ( ! $post ) {
			return self::not_found();
		}

		$editability = self::editability( $post );
		if ( ! $editability['editable'] ) {
			return new WP_REST_Response(
				array(
					'code'    => 'sevof_not_editable',
					'reason'  => $editability['reason'],
					'message' => __( 'This post cannot be edited safely by the connector.', 'sevof-connector' ),
				),
				422
			);
		}

		if ( (string) $request->get_param( 'expected_modified' ) !== $post->post_modified_gmt ) {
			return new WP_REST_Response(
				array(
					'code'     => 'sevof_conflict',
					'modified' => $post->post_modified_gmt,
					'message'  => __( 'The post was changed in WordPress after it was read.', 'sevof-connector' ),
				),
				409
			);
		}

		$content = (string) $request->get_param( 'content' );
		if ( '' === trim( $content ) || strlen( $content ) > self::MAX_CONTENT_BYTES ) {
			return new WP_REST_Response( array( 'code' => 'sevof_invalid_content', 'message' => __( 'The content is empty or too large.', 'sevof-connector' ) ), 422 );
		}

		// The request is HMAC-signed by the Sevof service and keeps the post's own
		// embeds, scripts and shortcodes byte for byte; kses would silently strip
		// them for a request without a logged-in user. The filters are restored
		// right after, exactly as WordPress sets them for the current user.
		kses_remove_filters();
		try {
			$result = wp_update_post(
				array(
					'ID'           => $post->ID,
					'post_content' => wp_slash( $content ),
				),
				true
			);
		} finally {
			kses_init();
		}

		if ( is_wp_error( $result ) ) {
			sevof_connector_log( 'existing_post_update_failed', array( 'post_id' => $post->ID ) );

			return new WP_REST_Response( array( 'code' => 'sevof_update_failed', 'message' => $result->get_error_message() ), 422 );
		}

		$seo = self::seo_keys();
		if ( $seo ) {
			foreach ( array( 'meta_title' => $seo['title'], 'meta_description' => $seo['description'] ) as $param => $meta_key ) {
				if ( ! $request->has_param( $param ) ) {
					continue;
				}
				$value = mb_substr( trim( (string) $request->get_param( $param ) ), 0, self::MAX_META_LENGTH );
				if ( '' === $value ) {
					delete_post_meta( $post->ID, $meta_key );
				} else {
					update_post_meta( $post->ID, $meta_key, $value );
				}
			}
		}

		update_post_meta( $post->ID, self::REFRESH_META_KEY, current_time( 'mysql' ) );
		clean_post_cache( $post->ID );
		sevof_connector_log( 'existing_post_updated', array( 'post_id' => $post->ID ) );

		return new WP_REST_Response( self::post_payload( get_post( $post->ID ), false ), 200 );
	}

	private static function post_payload( WP_Post $post, bool $with_content = true ): array {
		$editability = self::editability( $post );
		$seo         = self::seo_keys();

		$payload = array(
			'id'                  => (int) $post->ID,
			'title'               => html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ),
			'link'                => get_permalink( $post ),
			'modified'            => $post->post_modified_gmt,
			'editable'            => $editability['editable'],
			'not_editable_reason' => $editability['reason'],
			'seo'                 => array(
				'plugin'           => $seo ? $seo['plugin'] : null,
				'meta_title'       => $seo ? (string) get_post_meta( $post->ID, $seo['title'], true ) : null,
				'meta_description' => $seo ? (string) get_post_meta( $post->ID, $seo['description'], true ) : null,
			),
		);

		if ( $with_content ) {
			$payload['content'] = $post->post_content;
		}

		return $payload;
	}

	private static function get_existing_post( int $post_id ): ?WP_Post {
		$post = $post_id > 0 ? get_post( $post_id ) : null;

		if ( ! $post
			|| ! in_array( $post->post_type, self::article_post_types(), true )
			|| 'publish' !== $post->post_status
			|| '' !== $post->post_password
			|| '1' === get_post_meta( $post_id, Sevof_Connector_Rest_Controller::MANAGED_META_KEY, true ) ) {
			return null;
		}

		return $post;
	}

	/**
	 * Post types that hold articles: "post" plus any public type with an editor that
	 * a theme or plugin uses for its blog (e.g. "blog", "article", "news"). Pages,
	 * products, media and page-builder templates are never included.
	 * Adjust with the `sevof_connector_existing_post_types` filter.
	 *
	 * @return string[]
	 */
	public static function article_post_types(): array {
		$excluded = array( 'page', 'attachment', 'product', 'elementor_library', 'e-landing-page', 'wp_block', 'wp_template', 'wp_template_part', 'wp_navigation', 'ct_template', 'bricks_template', 'fl-builder-template', 'et_pb_layout' );
		$types    = array( 'post' );

		foreach ( get_post_types( array( 'public' => true ), 'names' ) as $type ) {
			if ( ! in_array( $type, $excluded, true ) && post_type_supports( $type, 'editor' ) ) {
				$types[] = $type;
			}
		}

		$types = (array) apply_filters( 'sevof_connector_existing_post_types', array_values( array_unique( $types ) ) );

		return array_values( array_filter( $types, 'is_string' ) );
	}

	/**
	 * A post is editable only when its visible content really is post_content.
	 *
	 * @return array{editable: bool, reason: ?string}
	 */
	public static function editability( WP_Post $post ): array {
		$id      = (int) $post->ID;
		$content = (string) $post->post_content;

		$builders = array(
			'elementor' => 'builder' === get_post_meta( $id, '_elementor_edit_mode', true ),
			'divi'      => 'on' === get_post_meta( $id, '_et_pb_use_builder', true ),
			'beaver'    => (bool) get_post_meta( $id, '_fl_builder_enabled', true ),
			'wpbakery'  => 'true' === get_post_meta( $id, '_wpb_vc_js_status', true ) || false !== strpos( $content, '[vc_row' ),
			'oxygen'    => '' !== (string) get_post_meta( $id, 'ct_builder_shortcodes', true ),
			'bricks'    => 'bricks' === get_post_meta( $id, '_bricks_editor_mode', true ),
			'thrive'    => (bool) get_post_meta( $id, 'tcb_editor_enabled', true ),
		);

		foreach ( $builders as $name => $used ) {
			if ( $used ) {
				return array( 'editable' => false, 'reason' => $name );
			}
		}

		if ( '' === trim( wp_strip_all_tags( $content ) ) ) {
			return array( 'editable' => false, 'reason' => 'empty' );
		}

		if ( strlen( $content ) > self::MAX_CONTENT_BYTES ) {
			return array( 'editable' => false, 'reason' => 'too_large' );
		}

		return array( 'editable' => true, 'reason' => null );
	}

	/**
	 * Post meta keys of the active SEO plugin, or null when none is active
	 * (or the active one does not keep titles in post meta, like AIOSEO).
	 *
	 * @return array{plugin: string, title: string, description: string}|null
	 */
	private static function seo_keys(): ?array {
		if ( defined( 'WPSEO_VERSION' ) ) {
			return array( 'plugin' => 'yoast', 'title' => '_yoast_wpseo_title', 'description' => '_yoast_wpseo_metadesc' );
		}
		if ( defined( 'RANK_MATH_VERSION' ) ) {
			return array( 'plugin' => 'rank_math', 'title' => 'rank_math_title', 'description' => 'rank_math_description' );
		}
		if ( defined( 'SEOPRESS_VERSION' ) ) {
			return array( 'plugin' => 'seopress', 'title' => '_seopress_titles_title', 'description' => '_seopress_titles_desc' );
		}

		return null;
	}

	private static function word_count( string $content ): int {
		$text = trim( wp_strip_all_tags( strip_shortcodes( $content ) ) );

		return '' === $text ? 0 : count( preg_split( '/\s+/u', $text ) );
	}

	private static function id_argument(): array {
		return array(
			'id' => array(
				'type'              => 'integer',
				'required'          => true,
				'sanitize_callback' => 'absint',
			),
		);
	}

	private static function not_found(): WP_REST_Response {
		return new WP_REST_Response( array( 'code' => 'sevof_post_not_found', 'message' => __( 'The requested post was not found.', 'sevof-connector' ) ), 404 );
	}
}
