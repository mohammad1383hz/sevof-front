<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Manages the single Sevof administration page, connection credentials, and dashboard cache.
 */
class Sevof_Connector_Dashboard_Page {
	const CACHE_TTL = 60;
	const PAGE_SLUG = 'sevof-connector';
	const CAPABILITY = 'manage_options';

	/**
	 * Registers administration hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( self::class, 'register_menu' ) );
		add_action( 'admin_init', array( self::class, 'handle_form_submit' ) );
		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue_assets' ) );
	}

	/**
	 * Registers the top-level Sevof menu page.
	 */
	public static function register_menu() {
		add_menu_page(
			__( 'Sevof', 'sevof-connector' ),
			__( 'Sevof', 'sevof-connector' ),
			self::CAPABILITY,
			self::PAGE_SLUG,
			array( self::class, 'render_page' ),
			self::menu_icon_svg(),
			26
		);
	}

	/**
	 * Processes the connect and disconnect form actions.
	 */
	public static function handle_form_submit() {
		if ( ! isset( $_POST['sevof_connector_nonce'] ) ) {
			return;
		}

		$nonce = sanitize_text_field( wp_unslash( $_POST['sevof_connector_nonce'] ) );
		if ( ! wp_verify_nonce( $nonce, 'sevof_connector_save' ) || ! current_user_can( self::CAPABILITY ) ) {
			return;
		}

		$action = isset( $_POST['sevof_connector_action'] ) ? sanitize_key( wp_unslash( $_POST['sevof_connector_action'] ) ) : '';
		if ( 'save_and_connect' === $action ) {
			$client_id = isset( $_POST['client_id'] ) ? sanitize_text_field( wp_unslash( $_POST['client_id'] ) ) : '';
			$client_secret = isset( $_POST['client_secret'] ) ? sanitize_text_field( wp_unslash( $_POST['client_secret'] ) ) : '';
			$api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( wp_unslash( $_POST['api_key'] ) ) : '';

			if ( '' !== $client_id ) {
				self::save_credential_option( 'sevof_connector_client_id', $client_id );
			}
			if ( '' !== $client_secret ) {
				self::save_credential_option( 'sevof_connector_client_secret', $client_secret );
			}
			if ( '' !== $api_key ) {
				self::save_credential_option( 'sevof_connector_api_key', $api_key );
			}

			$result = Sevof_Connector_Api_Client::handshake();
			update_option( 'sevof_connector_status', ! empty( $result['ok'] ) ? 'connected' : 'failed', false );
			update_option(
				'sevof_connector_last_message',
				! empty( $result['ok'] )
					? __( 'Connected to Sevof.', 'sevof-connector' )
					: ( $result['message'] ?? __( 'Could not connect to Sevof.', 'sevof-connector' ) ),
				false
			);
		} elseif ( 'disconnect' === $action ) {
			update_option( 'sevof_connector_status', 'disconnected', false );
			update_option( 'sevof_connector_last_message', __( 'Disconnected from Sevof.', 'sevof-connector' ), false );
			self::delete_dashboard_transients();
		}

		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE_SLUG ) );
		exit;
	}

	/**
	 * Renders the connection form or, once connected, the dashboard.
	 */
	public static function render_page() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}

		$client_id = (string) get_option( 'sevof_connector_client_id', '' );
		$client_secret = (string) get_option( 'sevof_connector_client_secret', '' );
		$api_key = (string) get_option( 'sevof_connector_api_key', '' );
		$status = (string) get_option( 'sevof_connector_status', 'not_connected' );
		$message = (string) get_option( 'sevof_connector_last_message', '' );
		$has_client_id = '' !== $client_id;
		$has_client_secret = '' !== $client_secret;
		$has_api_key = '' !== $api_key;

		$dashboard = null;
		$keywords = null;
		$entities = null;
		$articles = null;
		$product_articles = null;
		$subscription = null;
		$debug_log_state = self::read_recent_debug_log_entries();
		$last_error = Sevof_Connector_Api_Client::get_last_error();
		$environment_report = Sevof_Connector_Api_Client::environment_report();

		if ( 'connected' === $status ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only flag that only bypasses the local cache for this request; no data is written.
			$force_refresh = isset( $_GET['sevof_refresh'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['sevof_refresh'] ) );
			$dashboard = self::cached_fetch( 'sevof_connector_cache_dashboard', array( Sevof_Connector_Api_Client::class, 'get_dashboard' ), $force_refresh );
			$keywords = self::cached_fetch( 'sevof_connector_cache_keywords', array( Sevof_Connector_Api_Client::class, 'get_keywords' ), $force_refresh );
			$entities = self::cached_fetch( 'sevof_connector_cache_entities', array( Sevof_Connector_Api_Client::class, 'get_entities' ), $force_refresh );
			$articles = self::cached_fetch( 'sevof_connector_cache_articles', array( Sevof_Connector_Api_Client::class, 'get_articles' ), $force_refresh );
			$product_articles = self::cached_fetch( 'sevof_connector_cache_product_articles', array( Sevof_Connector_Api_Client::class, 'get_product_articles' ), $force_refresh );
			$subscription = self::cached_fetch( 'sevof_connector_cache_subscription', array( Sevof_Connector_Api_Client::class, 'get_subscription' ), $force_refresh );
		}

		include SEVOF_CONNECTOR_PATH . 'includes/views/dashboard-page.php';
	}

	/**
	 * Loads the dashboard stylesheet and script on this plugin's page only.
	 *
	 * @param string $hook_suffix Current admin page hook.
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if ( 'toplevel_page_' . self::PAGE_SLUG !== $hook_suffix ) {
			return;
		}

		wp_enqueue_style( 'sevof-connector-admin', SEVOF_CONNECTOR_URL . 'assets/css/admin.css', array(), SEVOF_CONNECTOR_VERSION );
		wp_enqueue_script( 'sevof-connector-admin', SEVOF_CONNECTOR_URL . 'assets/js/admin.js', array(), SEVOF_CONNECTOR_VERSION, true );
		wp_localize_script(
			'sevof-connector-admin',
			'sevofConnectorAdmin',
			array( 'confirmDisconnect' => __( 'Disconnect this site from Sevof?', 'sevof-connector' ) )
		);
	}

	/**
	 * Returns a localized label when one is available.
	 */
	public static function label( ?string $value, array $labels ): string {
		if ( null === $value || '' === $value ) {
			return '-';
		}

		return $labels[ $value ] ?? $value;
	}

	private static function save_credential_option( string $option_name, string $value ) {
		delete_option( $option_name );
		add_option( $option_name, $value, '', 'no' );
	}

	private static function delete_dashboard_transients() {
		foreach ( array( 'sevof_connector_cache_dashboard', 'sevof_connector_cache_keywords', 'sevof_connector_cache_entities', 'sevof_connector_cache_articles', 'sevof_connector_cache_product_articles', 'sevof_connector_cache_subscription' ) as $transient ) {
			delete_transient( $transient );
		}
	}

	/**
	 * Reads only this plugin's own log lines (already stripped of secrets and request/response
	 * bodies by Sevof_Connector_Api_Client::debug_log()) from the WordPress debug log, so the site
	 * owner can see them on the connection screen without opening the server file themselves.
	 *
	 * Returns an array shaped as:
	 *   'state' => 'disabled' | 'unreadable' | 'empty' | 'ok'
	 *   'lines' => string[] (only when state is 'ok')
	 */
	private static function read_recent_debug_log_entries( int $max_lines = 20, int $max_bytes_to_scan = 262144 ): array {
		if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG || ! defined( 'WP_DEBUG_LOG' ) || ! WP_DEBUG_LOG ) {
			return array( 'state' => 'disabled', 'lines' => array() );
		}

		$log_path = ( true === WP_DEBUG_LOG )
			? trailingslashit( WP_CONTENT_DIR ) . 'debug.log'
			: (string) WP_DEBUG_LOG;

		if ( '' === $log_path || ! is_file( $log_path ) || ! is_readable( $log_path ) ) {
			return array( 'state' => 'unreadable', 'lines' => array() );
		}

		$handle = fopen( $log_path, 'rb' );
		if ( false === $handle ) {
			return array( 'state' => 'unreadable', 'lines' => array() );
		}

		// Only scan the tail of the file so a large, unrelated debug.log doesn't get loaded into memory.
		$file_size = filesize( $log_path );
		if ( is_int( $file_size ) && $file_size > $max_bytes_to_scan ) {
			fseek( $handle, -$max_bytes_to_scan, SEEK_END );
		}
		$contents = stream_get_contents( $handle );
		fclose( $handle );

		if ( ! is_string( $contents ) || '' === $contents ) {
			return array( 'state' => 'empty', 'lines' => array() );
		}

		$all_lines = preg_split( '/\r\n|\r|\n/', $contents );
		if ( ! is_array( $all_lines ) ) {
			return array( 'state' => 'empty', 'lines' => array() );
		}

		// Only surface lines this plugin itself wrote; never expose unrelated host/site log content.
		$plugin_lines = array_values(
			array_filter(
				$all_lines,
				static function ( string $line ): bool {
					return false !== strpos( $line, '[Sevof Connector]' );
				}
			)
		);

		if ( empty( $plugin_lines ) ) {
			return array( 'state' => 'empty', 'lines' => array() );
		}

		$recent_lines = array_slice( $plugin_lines, -$max_lines );

		return array( 'state' => 'ok', 'lines' => array_reverse( $recent_lines ) );
	}

	private static function menu_icon_svg(): string {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="8" width="16" height="11" rx="3"></rect><line x1="12" y1="3" x2="12" y2="6"></line><circle cx="12" cy="3" r="1"></circle><circle cx="9" cy="13" r="1.2" fill="currentColor"></circle><circle cx="15" cy="13" r="1.2" fill="currentColor"></circle><line x1="9" y1="17" x2="15" y2="17"></line></svg>';

		return 'data:image/svg+xml;base64,' . base64_encode( $svg );
	}

	private static function cached_fetch( string $cache_key, callable $fetcher, bool $force_refresh ): array {
		if ( ! $force_refresh ) {
			$cached = get_transient( $cache_key );
			if ( false !== $cached && is_array( $cached ) ) {
				return $cached;
			}
		}

		$result = call_user_func( $fetcher );
		if ( ! empty( $result['ok'] ) ) {
			set_transient( $cache_key, $result, self::CACHE_TTL );
		} else {
			delete_transient( $cache_key );
		}

		return is_array( $result ) ? $result : array( 'ok' => false, 'message' => __( 'Unable to retrieve Sevof data.', 'sevof-connector' ) );
	}
}
