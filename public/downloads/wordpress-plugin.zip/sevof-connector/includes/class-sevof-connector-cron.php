<?php

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Reports health status to Laravel every 12 hours
 * so the panel shows when the WordPress site was last alive.
 */
class Sevof_Connector_Cron
{
    const HEALTH_HOOK = 'sevof_connector_health_ping';
    const REPLAY_CLEANUP_HOOK = 'sevof_connector_cleanup_replay_tokens';

    public static function init()
    {
        add_action(self::HEALTH_HOOK, [self::class, 'run_health_ping']);
        add_action(self::REPLAY_CLEANUP_HOOK, [Sevof_Connector_Signature::class, 'cleanup_replay_tokens']);
    }

    public static function activate()
    {
        if (! wp_next_scheduled(self::HEALTH_HOOK)) {
            wp_schedule_event(time(), 'twicedaily', self::HEALTH_HOOK);
        }

        if (! wp_next_scheduled(self::REPLAY_CLEANUP_HOOK)) {
            wp_schedule_event(time(), 'hourly', self::REPLAY_CLEANUP_HOOK);
        }
    }

    public static function deactivate()
    {
        wp_clear_scheduled_hook(self::HEALTH_HOOK);
        wp_clear_scheduled_hook(self::REPLAY_CLEANUP_HOOK);
    }

    public static function run_health_ping()
    {
        if (get_option('sevof_connector_status') !== 'connected') {
            return;
        }

        Sevof_Connector_Api_Client::ping_health();
    }
}
