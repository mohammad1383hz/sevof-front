<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * All outbound requests from this site to the Sevof service are centralized here.
 */
class Sevof_Connector_Api_Client {
	const PANEL_URL = 'https://api.sevof.com';
	const REQUEST_TIMEOUT = 20;

	/**
	 * Returns the HTTPS endpoint for all outbound requests.
	 *
	 * Always the fixed production endpoint, except when the site owner defines
	 * SEVOF_CONNECTOR_API_URL in wp-config.php (for Sevof staging); that value must be HTTPS.
	 */
	private static function base_url(): string {
		if ( defined( 'SEVOF_CONNECTOR_API_URL' ) && is_string( SEVOF_CONNECTOR_API_URL ) ) {
			$parsed = wp_parse_url( SEVOF_CONNECTOR_API_URL );
			if ( is_array( $parsed ) && ! empty( $parsed['host'] ) && 'https' === strtolower( $parsed['scheme'] ?? '' ) ) {
				return untrailingslashit( SEVOF_CONNECTOR_API_URL );
			}
		}

		return self::PANEL_URL;
	}

	/**
	 * Final connection verification, called after the site administrator saves credentials.
	 */
	public static function handshake(): array {
		$body = wp_json_encode(
			array(
				'wp_url'         => home_url(),
				'wp_version'     => get_bloginfo( 'version' ),
				'plugin_version' => SEVOF_CONNECTOR_VERSION,
			)
		);

		if ( false === $body ) {
			self::debug_log( 'json_encode_failed' );
			self::record_last_error( 'json_encode_failed' );

			return self::error_result();
		}

		return self::send( 'POST', '/api/agent/connect/handshake', $body );
	}

	/**
	 * Periodic health ping, invoked by WP-Cron while the service is connected.
	 */
	public static function ping_health(): array {
		$body = wp_json_encode(
			array(
				'wp_version'     => get_bloginfo( 'version' ),
				'plugin_version' => SEVOF_CONNECTOR_VERSION,
			)
		);

		if ( false === $body ) {
			self::debug_log( 'json_encode_failed' );
			self::record_last_error( 'json_encode_failed' );

			return self::error_result();
		}

		return self::send( 'POST', '/api/agent/health', $body );
	}

	/**
	 * Retrieves overall dashboard statistics.
	 */
	public static function get_dashboard(): array {
		return self::get( '/api/agent/dashboard' );
	}

	/**
	 * Retrieves suggested keywords.
	 */
	public static function get_keywords(): array {
		return self::get( '/api/agent/keywords' );
	}

	/**
	 * Retrieves entities extracted from ideas.
	 */
	public static function get_entities(): array {
		return self::get( '/api/agent/entities' );
	}

	/**
	 * Retrieves the site owner's subscription status: active plan, credit usage,
	 * and any queued plan waiting to take over once the current one ends.
	 */
	public static function get_subscription(): array {
		return self::get( '/api/agent/subscription' );
	}

	/**
	 * Retrieves the summary list of articles for this site.
	 */
	public static function get_articles(): array {
		return self::get( '/api/agent/articles' );
	}

	/**
	 * Retrieves the summary list of product articles for this site.
	 */
	public static function get_product_articles(): array {
		return self::get( '/api/agent/product-articles' );
	}

	/**
	 * Retrieves one article from the Sevof service.
	 */
	public static function get_article( int $article_id ): array {
		return self::get( '/api/agent/articles/' . absint( $article_id ) );
	}

	private static function get( string $path ): array {
		return self::send( 'GET', $path, '' );
	}

	/**
	 * Sends an authenticated request without logging credentials, request bodies, or response bodies.
	 */
	private static function send( string $method, string $path, string $body ): array {
		if ( ! self::has_credentials() ) {
			self::debug_log( 'missing_credentials' );
			self::record_last_error( 'missing_credentials' );

			return self::error_result();
		}

		$url = self::base_url() . $path;
		$parsed_url = wp_parse_url( $url );

		if ( ! is_array( $parsed_url ) || empty( $parsed_url['host'] ) || empty( $parsed_url['scheme'] ) || 'https' !== strtolower( $parsed_url['scheme'] ) ) {
			self::debug_log( 'invalid_endpoint', array( 'path' => $path ) );
			self::record_last_error( 'invalid_endpoint', array( 'path' => $path ) );

			return self::error_result();
		}

		$signing_path = ltrim( $path, '/' );
		$headers = array_merge(
			array(
				'Accept'       => 'application/json',
				'Content-Type' => 'application/json; charset=utf-8',
			),
			Sevof_Connector_Signature::build_outbound_headers( $body, $method, $signing_path )
		);

		$response = wp_remote_request(
			$url,
			array(
				'method'             => strtoupper( $method ),
				'timeout'            => self::REQUEST_TIMEOUT,
				'redirection'        => 0,
				'reject_unsafe_urls' => true,
				'sslverify'          => true,
				'headers'            => $headers,
				'body'               => $body,
				'user-agent'         => 'Sevof-Connector/' . SEVOF_CONNECTOR_VERSION . '; ' . home_url( '/' ),
			)
		);

		if ( is_wp_error( $response ) ) {
			$wp_error_context = array(
				'method'        => strtoupper( $method ),
				'path'          => $path,
				'error_code'    => $response->get_error_code(),
				'error_message' => $response->get_error_message(),
			);

			self::debug_log( 'wp_error', $wp_error_context );
			self::record_last_error( 'wp_error', $wp_error_context );

			return self::error_result();
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		$raw_body = (string) wp_remote_retrieve_body( $response );
		$decoded_body = json_decode( $raw_body, true );
		$ok = $status_code >= 200 && $status_code < 300;

		if ( ! $ok ) {
			$http_error_context = array(
				'method'      => strtoupper( $method ),
				'path'        => $path,
				'status_code' => $status_code,
			);

			self::debug_log( 'http_error', $http_error_context );
			self::record_last_error( 'http_error', $http_error_context );
		} else {
			self::clear_last_error();
		}

		return array(
			'ok'          => $ok,
			'status_code' => $status_code,
			'body'        => is_array( $decoded_body ) ? $decoded_body : array(),
			'message'     => $ok ? '' : self::public_error_message( $status_code ) . self::diagnostic_suffix( $status_code, $path ),
		);
	}

	/**
	 * Appends the HTTP status and endpoint path (never credentials or bodies) to generic
	 * 4xx errors, so the dashboard shows WHICH endpoint failed and why (e.g. 404 = route
	 * missing on the Sevof service, 422 = rejected request, 429 = rate limited).
	 */
	private static function diagnostic_suffix( int $status_code, string $path ): string {
		if ( $status_code < 400 || $status_code >= 500 || 401 === $status_code || 403 === $status_code ) {
			return '';
		}

		return ' [HTTP ' . $status_code . ' ' . $path . ']';
	}

	private static function has_credentials(): bool {
		return (bool) get_option( 'sevof_connector_client_id' )
			&& (bool) get_option( 'sevof_connector_client_secret' )
			&& (bool) get_option( 'sevof_connector_api_key' );
	}

	/**
	 * Builds the generic failure result shape. Callers are responsible for logging/recording
	 * the specific reason (via debug_log()/record_last_error()) BEFORE calling this, each with
	 * whatever context they have — this avoids a richer record being silently overwritten by
	 * a later, context-less one for the same failed request.
	 */
	private static function error_result(): array {
		return array(
			'ok'          => false,
			'status_code' => 0,
			'body'        => array(),
			'message'     => self::public_error_message( 0 ),
		);
	}

	private static function public_error_message( int $status_code ): string {
		if ( 401 === $status_code || 403 === $status_code ) {
			return __( 'Authentication with the Sevof service failed. Please verify the saved credentials.', 'sevof-connector' );
		}

		if ( $status_code >= 500 ) {
			return __( 'The Sevof service is temporarily unavailable. Please try again later.', 'sevof-connector' );
		}

		return __( 'Unable to communicate with the Sevof service. Please try again later.', 'sevof-connector' );
	}

	/**
	 * Writes a minimal operational event only when WordPress debug logging is explicitly enabled.
	 * Secrets, signed headers, request bodies, response bodies, and personally identifiable data
	 * are intentionally excluded.
	 */
	private static function debug_log( string $event, array $context = array() ) {
		if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG || ! defined( 'WP_DEBUG_LOG' ) || ! WP_DEBUG_LOG ) {
			return;
		}

		$allowed_context = self::scrub_context( $context );

		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- intentional, and only ever runs when the site owner has explicitly enabled WP_DEBUG and WP_DEBUG_LOG.
		error_log( '[Sevof Connector] ' . sanitize_key( $event ) . ' ' . wp_json_encode( $allowed_context ) );
	}

	/**
	 * Keeps only the small, pre-approved set of diagnostic fields, and never
	 * credentials, signed headers, or request/response bodies. Shared by the
	 * error_log writer above and by the persisted "last error" record below,
	 * so both surfaces expose exactly the same scrubbed data.
	 */
	private static function scrub_context( array $context ): array {
		$allowed_context = array();
		foreach ( array( 'method', 'path', 'status_code', 'error_code' ) as $key ) {
			if ( isset( $context[ $key ] ) ) {
				$allowed_context[ $key ] = is_scalar( $context[ $key ] ) ? (string) $context[ $key ] : '';
			}
		}

		// error_message is free-form text from the HTTP transport (e.g. a cURL error
		// such as "Could not resolve host" or an SSL failure) rather than a fixed code,
		// so it is length-capped defensively before being stored. It never contains
		// credentials, headers, or request/response bodies.
		if ( isset( $context['error_message'] ) && is_string( $context['error_message'] ) && '' !== $context['error_message'] ) {
			$allowed_context['error_message'] = mb_substr( $context['error_message'], 0, 300 );
		}

		return $allowed_context;
	}

	/**
	 * Persists the last failed request to an option, independent of WP_DEBUG, so a site
	 * owner who has never touched wp-config.php can still see (and copy) exactly why the
	 * last connection attempt failed on the plugin's own admin screen.
	 */
	private static function record_last_error( string $event, array $context = array() ) {
		$record = array_merge(
			array(
				'event' => sanitize_key( $event ),
				'time'  => current_time( 'mysql' ),
			),
			self::scrub_context( $context )
		);

		update_option( 'sevof_connector_last_error', $record, false );
	}

	/**
	 * Returns the last recorded failure (see record_last_error()), or an empty array
	 * if none is stored or the last request succeeded.
	 */
	public static function get_last_error(): array {
		$record = get_option( 'sevof_connector_last_error', array() );

		return is_array( $record ) ? $record : array();
	}

	/**
	 * Clears the persisted failure record after a successful request.
	 */
	private static function clear_last_error() {
		delete_option( 'sevof_connector_last_error' );
	}

	/**
	 * Lightweight, read-only environment checks for the most common reasons a WordPress
	 * install cannot reach an external HTTPS host: PHP's cURL extension missing, or
	 * WordPress itself configured (via WP_HTTP_BLOCK_EXTERNAL) to block outbound requests
	 * to hosts not explicitly allow-listed. Contains no secrets and is safe to display.
	 */
	public static function environment_report(): array {
		$host = (string) wp_parse_url( self::base_url(), PHP_URL_HOST );

		$block_external = defined( 'WP_HTTP_BLOCK_EXTERNAL' ) && WP_HTTP_BLOCK_EXTERNAL;
		$host_allowed = null;

		if ( $block_external ) {
			$host_allowed = false;
			if ( defined( 'WP_ACCESSIBLE_HOSTS' ) && '' !== WP_ACCESSIBLE_HOSTS ) {
				$allowed_hosts = array_map( 'trim', explode( ',', WP_ACCESSIBLE_HOSTS ) );
				foreach ( $allowed_hosts as $allowed_host ) {
					if ( '' === $allowed_host ) {
						continue;
					}
					// WP_ACCESSIBLE_HOSTS entries may use a leading '*.' wildcard for subdomains.
					$pattern = '/^' . str_replace( '\*', '.+', preg_quote( $allowed_host, '/' ) ) . '$/i';
					if ( preg_match( $pattern, $host ) ) {
						$host_allowed = true;
						break;
					}
				}
			}
		}

		return array(
			'target_host'        => $host,
			'php_version'        => PHP_VERSION,
			'wp_version'         => get_bloginfo( 'version' ),
			'curl_available'     => function_exists( 'curl_init' ),
			'openssl_available'  => extension_loaded( 'openssl' ),
			'block_external'     => $block_external,
			'target_host_allowed' => $host_allowed,
		);
	}
}
