<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings page: brand color + full palette, with a live preview.
 *
 * @var array       $groups        Token groups (see Sevof_Connector_Style_Settings::groups()).
 * @var array       $tiles         token => array( value, auto, custom ).
 * @var string      $primary       Brand color in use (#rrggbb).
 * @var bool        $manual        True when the owner pinned the brand color on this page / by option.
 * @var bool        $accent_locked True when code pins the brand color through a filter.
 * @var string|null $auto_primary  Brand color "automatic" gives, when it is known.
 * @var array|null  $logo          Logo detection result (hex, chromatic, share, source) or null.
 * @var string      $logo_url      Thumbnail URL of the logo, or ''.
 * @var string      $logo_source   Human label of where the logo color came from.
 * @var string      $notice        '', 'saved' or 'reset'.
 */

$yxs_class = 'Sevof_Connector_Style_Settings';

// Initial CSS variables of the live preview (the script keeps them in sync afterwards).
$yxs_vars = '--yt-primary:' . $primary . ';';
foreach ( $groups as $yxs_group ) {
	foreach ( $yxs_group['tokens'] as $yxs_key => $yxs_meta ) {
		$yxs_vars .= '--yt-' . str_replace( '_', '-', $yxs_key ) . ':' . $yxs_class::css_value( $tiles[ $yxs_key ]['value'], $yxs_meta['type'] ) . ';';
	}
}

$yxs_ribbon = array(
	'primary'        => __( 'Brand color', 'sevof-connector' ),
	'primary_deep'   => __( 'Dark', 'sevof-connector' ),
	'primary_text'   => __( 'Text', 'sevof-connector' ),
	'heading_text'   => __( 'Heading', 'sevof-connector' ),
	'paragraph_text' => __( 'Paragraph', 'sevof-connector' ),
	'icon_bg'        => __( 'Icon', 'sevof-connector' ),
	'list_border'    => __( 'Border', 'sevof-connector' ),
	'list_bg'        => __( 'Background', 'sevof-connector' ),
);

$yxs_custom_count = 0;
foreach ( $tiles as $yxs_tile ) {
	if ( ! empty( $yxs_tile['custom'] ) ) {
		++$yxs_custom_count;
	}
}
?>
<div class="wrap sevof-wrap yxs-wrap">
	<h1 class="wp-heading-inline"><?php esc_html_e( 'Appearance and colors', 'sevof-connector' ); ?></h1>
	<hr class="wp-header-end">

	<?php if ( 'saved' === $notice ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Saved. The colors now apply to Sevof articles and products. If your site uses a caching plugin, clear its cache once.', 'sevof-connector' ); ?></p></div>
	<?php elseif ( 'reset' === $notice ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Colors are back to automatic (based on your logo).', 'sevof-connector' ); ?></p></div>
	<?php endif; ?>

	<p class="yxs-lead">
		<?php esc_html_e( 'Sevof builds the colors of articles, product cards, FAQs and tables from your logo color. This page shows that palette and lets you change any color. Anything you leave untouched stays automatic.', 'sevof-connector' ); ?>
	</p>

	<form id="yxs-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" autocomplete="off">
		<input type="hidden" name="action" value="<?php echo esc_attr( $yxs_class::SAVE_ACTION ); ?>">
		<?php wp_nonce_field( $yxs_class::SAVE_ACTION, $yxs_class::NONCE_FIELD ); ?>

		<div class="yxs-layout">
			<div class="yxs-main">

				<!-- Brand color -->
				<section class="yxs-card yxs-primary" aria-labelledby="yxs-primary-title">
					<header class="yxs-card-head">
						<h2 id="yxs-primary-title"><?php esc_html_e( 'Brand color', 'sevof-connector' ); ?></h2>
						<p><?php esc_html_e( 'All other colors (text, backgrounds, borders and shadows) are derived from this one, so changing it updates the whole palette.', 'sevof-connector' ); ?></p>
					</header>

					<?php if ( $accent_locked ) : ?>
						<div class="yxs-lock">
							<?php esc_html_e( 'The brand color is locked by your theme or another plugin (sevof_connector_accent_color filter) and cannot be changed here. You can still adjust the other colors.', 'sevof-connector' ); ?>
						</div>
					<?php endif; ?>

					<div class="yxs-primary-grid">
						<div class="yxs-logo-box">
							<div class="yxs-logo-thumb">
								<?php if ( '' !== $logo_url ) : ?>
									<img src="<?php echo esc_url( $logo_url ); ?>" alt="">
								<?php else : ?>
									<span class="yxs-logo-empty" aria-hidden="true">
										<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="3"></rect><circle cx="9" cy="10" r="1.6"></circle><path d="M21 16l-5-5-8 8"></path></svg>
									</span>
								<?php endif; ?>
							</div>
							<div class="yxs-logo-info">
								<strong><?php esc_html_e( 'Detected from your logo', 'sevof-connector' ); ?></strong>
								<?php if ( $logo ) : ?>
									<div class="yxs-logo-color">
										<span class="yxs-dot" style="background:<?php echo esc_attr( $logo['hex'] ); ?>"></span>
										<code dir="ltr"><?php echo esc_html( $logo['hex'] ); ?></code>
										<?php if ( ! empty( $logo['chromatic'] ) ) : ?>
											<span class="yxs-pill is-ok"><?php esc_html_e( 'Brand color', 'sevof-connector' ); ?></span>
										<?php else : ?>
											<span class="yxs-pill is-warn"><?php esc_html_e( 'Logo is monochrome', 'sevof-connector' ); ?></span>
										<?php endif; ?>
									</div>
									<?php if ( '' !== $logo_source ) : ?>
										<small><?php echo esc_html( sprintf( /* translators: %s: where the logo was found */ __( 'Source: %s', 'sevof-connector' ), $logo_source ) ); ?></small>
									<?php endif; ?>
									<?php if ( empty( $logo['chromatic'] ) ) : ?>
										<small><?php esc_html_e( 'A black or grey logo has no brand color, so in automatic mode the color comes from your theme.', 'sevof-connector' ); ?></small>
									<?php endif; ?>
								<?php else : ?>
									<small><?php esc_html_e( 'No logo was found. In automatic mode the color comes from your theme settings or the default teal.', 'sevof-connector' ); ?></small>
								<?php endif; ?>
							</div>
						</div>

						<div class="yxs-primary-pick">
							<div class="yxs-seg" role="radiogroup" aria-label="<?php esc_attr_e( 'How the brand color is chosen', 'sevof-connector' ); ?>">
								<label>
									<input type="radio" name="yx_primary_mode" value="auto" <?php checked( ! $manual ); ?> <?php disabled( $accent_locked ); ?>>
									<span><?php esc_html_e( 'Automatic (from logo)', 'sevof-connector' ); ?></span>
								</label>
								<label>
									<input type="radio" name="yx_primary_mode" value="manual" <?php checked( $manual ); ?> <?php disabled( $accent_locked ); ?>>
									<span><?php esc_html_e( 'Pick manually', 'sevof-connector' ); ?></span>
								</label>
							</div>

							<div class="yxs-primary-row">
								<label class="yxs-swatch yxs-swatch--lg" style="--c:<?php echo esc_attr( $primary ); ?>">
									<input type="color" id="yxs-primary-color" value="<?php echo esc_attr( $primary ); ?>" aria-label="<?php esc_attr_e( 'Brand color', 'sevof-connector' ); ?>" <?php disabled( $accent_locked ); ?>>
								</label>
								<div class="yxs-primary-fields">
									<input type="text" id="yxs-primary-hex" class="yxs-hex" value="<?php echo esc_attr( $primary ); ?>" maxlength="7" dir="ltr" spellcheck="false" aria-label="<?php esc_attr_e( 'Brand color hex code', 'sevof-connector' ); ?>" <?php disabled( $accent_locked ); ?>>
									<input type="hidden" name="yx_primary" id="yxs-primary-value" value="<?php echo esc_attr( $primary ); ?>">
									<?php if ( $logo && ! empty( $logo['chromatic'] ) && ! $accent_locked ) : ?>
										<button type="button" class="button yxs-use-logo" id="yxs-use-logo" data-hex="<?php echo esc_attr( $logo['hex'] ); ?>">
											<?php esc_html_e( 'Use logo color', 'sevof-connector' ); ?>
										</button>
									<?php endif; ?>
								</div>
							</div>

							<p class="yxs-note" id="yxs-primary-note" hidden></p>
						</div>
					</div>

					<div class="yxs-ribbon" id="yxs-ribbon" aria-label="<?php esc_attr_e( 'Palette overview', 'sevof-connector' ); ?>"
						data-auto-primary="<?php echo esc_attr( null !== $auto_primary ? $auto_primary : '' ); ?>">
						<?php foreach ( $yxs_ribbon as $yxs_rkey => $yxs_rlabel ) : ?>
							<div class="yxs-rib" data-key="<?php echo esc_attr( $yxs_rkey ); ?>">
								<span class="yxs-rib-chip"></span>
								<small><?php echo esc_html( $yxs_rlabel ); ?></small>
							</div>
						<?php endforeach; ?>
					</div>
				</section>

				<!-- Full palette -->
				<?php foreach ( $groups as $yxs_gkey => $yxs_group ) : ?>
					<section class="yxs-card yxs-group" aria-labelledby="yxs-g-<?php echo esc_attr( $yxs_gkey ); ?>">
						<header class="yxs-card-head">
							<h2 id="yxs-g-<?php echo esc_attr( $yxs_gkey ); ?>"><?php echo esc_html( $yxs_group['title'] ); ?></h2>
							<p><?php echo esc_html( $yxs_group['desc'] ); ?></p>
						</header>

						<div class="yxs-tiles">
							<?php
							foreach ( $yxs_group['tokens'] as $yxs_key => $yxs_meta ) :
								$yxs_tile   = $tiles[ $yxs_key ];
								$yxs_is_a   = ( 'alpha' === $yxs_meta['type'] );
								$yxs_val    = $yxs_tile['value'];
								$yxs_autoV  = $yxs_tile['auto'];
								$yxs_css    = $yxs_class::css_value( $yxs_val, $yxs_meta['type'] );
								$yxs_custom = ! empty( $yxs_tile['custom'] );
								?>
								<div class="yxs-tile<?php echo $yxs_custom ? ' is-custom' : ''; ?><?php echo $yxs_is_a ? ' is-alpha' : ''; ?>"
									data-key="<?php echo esc_attr( $yxs_key ); ?>"
									data-type="<?php echo esc_attr( $yxs_meta['type'] ); ?>"
									data-check="<?php echo esc_attr( isset( $yxs_meta['check'] ) ? $yxs_meta['check'] : '' ); ?>"
									data-auto-hex="<?php echo esc_attr( $yxs_autoV['hex'] ); ?>"
									data-auto-pct="<?php echo esc_attr( null === $yxs_autoV['pct'] ? '' : $yxs_autoV['pct'] ); ?>">

									<label class="yxs-swatch<?php echo $yxs_is_a ? ' yxs-swatch--alpha' : ''; ?>" style="--c:<?php echo esc_attr( $yxs_css ); ?>">
										<input type="color" class="yxs-color" name="yx_tokens[<?php echo esc_attr( $yxs_key ); ?>]" value="<?php echo esc_attr( $yxs_val['hex'] ); ?>" aria-label="<?php echo esc_attr( $yxs_meta['label'] ); ?>">
									</label>

									<div class="yxs-tile-body">
										<div class="yxs-tile-head">
											<span class="yxs-name"><?php echo esc_html( $yxs_meta['label'] ); ?></span>
											<span class="yxs-badge <?php echo $yxs_custom ? 'is-custom' : 'is-auto'; ?>"><?php echo $yxs_custom ? esc_html__( 'Custom', 'sevof-connector' ) : esc_html__( 'Auto', 'sevof-connector' ); ?></span>
										</div>
										<div class="yxs-hint"><?php echo esc_html( $yxs_meta['hint'] ); ?></div>

										<div class="yxs-controls">
											<input type="text" class="yxs-hex" value="<?php echo esc_attr( $yxs_val['hex'] ); ?>" maxlength="7" dir="ltr" spellcheck="false" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: color name */ __( 'Hex code: %s', 'sevof-connector' ), $yxs_meta['label'] ) ); ?>">
											<?php if ( $yxs_is_a ) : ?>
												<div class="yxs-alpha-wrap">
													<input type="range" class="yxs-alpha" name="yx_alpha[<?php echo esc_attr( $yxs_key ); ?>]" min="0" max="100" step="0.5" value="<?php echo esc_attr( $yxs_val['pct'] ); ?>" aria-label="<?php esc_attr_e( 'Opacity', 'sevof-connector' ); ?>">
													<output class="yxs-alpha-out" dir="ltr"><?php echo esc_html( $yxs_val['pct'] ); ?>%</output>
												</div>
											<?php endif; ?>
											<button type="button" class="yxs-reset" title="<?php esc_attr_e( 'Reset to automatic color', 'sevof-connector' ); ?>" aria-label="<?php esc_attr_e( 'Reset to automatic color', 'sevof-connector' ); ?>" <?php echo $yxs_custom ? '' : 'hidden'; ?>>
												<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12a9 9 0 1 0 3-6.7"></path><path d="M3 4v5h5"></path></svg>
											</button>
										</div>
										<span class="yxs-contrast" hidden></span>
									</div>

									<input type="hidden" class="yxs-custom" name="yx_custom[<?php echo esc_attr( $yxs_key ); ?>]" value="<?php echo $yxs_custom ? '1' : '0'; ?>">
								</div>
							<?php endforeach; ?>
						</div>
					</section>
				<?php endforeach; ?>
			</div>

			<!-- Live preview -->
			<aside class="yxs-side" aria-label="<?php esc_attr_e( 'Live preview', 'sevof-connector' ); ?>">
				<div class="yxs-sticky">
					<div class="yxs-side-head">
						<h2><?php esc_html_e( 'Live preview', 'sevof-connector' ); ?></h2>
						<span><?php esc_html_e( 'See every change here as you make it', 'sevof-connector' ); ?></span>
					</div>

					<div class="yxs-preview" id="yxs-preview" style="<?php echo esc_attr( $yxs_vars ); ?>">
						<h2 class="pv-h2"><?php esc_html_e( 'A section heading', 'sevof-connector' ); ?></h2>
						<p class="pv-p">
							<?php esc_html_e( 'This is sample text to show the paragraph color.', 'sevof-connector' ); ?>
							<strong class="pv-strong"><?php esc_html_e( 'Bold text', 'sevof-connector' ); ?></strong>
							<?php esc_html_e( 'and', 'sevof-connector' ); ?>
							<span class="pv-link"><?php esc_html_e( 'a link in the text', 'sevof-connector' ); ?></span>
							<?php esc_html_e( 'look like this.', 'sevof-connector' ); ?>
						</p>
						<h3 class="pv-h3"><?php esc_html_e( 'A subheading', 'sevof-connector' ); ?></h3>
						<ul class="pv-ul">
							<li><?php esc_html_e( 'First list item', 'sevof-connector' ); ?></li>
							<li><?php esc_html_e( 'Second list item', 'sevof-connector' ); ?></li>
						</ul>
						<ol class="pv-ol">
							<li><?php esc_html_e( 'Step one', 'sevof-connector' ); ?></li>
							<li><?php esc_html_e( 'Step two', 'sevof-connector' ); ?></li>
						</ol>
						<blockquote class="pv-bq"><?php esc_html_e( 'A quote or key tip looks like this.', 'sevof-connector' ); ?></blockquote>
						<p class="pv-cap"><?php esc_html_e( 'Image caption (muted text)', 'sevof-connector' ); ?></p>

						<div class="pv-card">
							<div class="pv-media">
								<span class="pv-badge">20%</span>
								<svg viewBox="0 0 24 24" width="54" height="54" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 8h12l-1 11H7L6 8z"></path><path d="M9 8a3 3 0 0 1 6 0"></path></svg>
							</div>
							<div class="pv-body">
								<span class="pv-cat"><?php esc_html_e( 'Category', 'sevof-connector' ); ?></span>
								<div class="pv-title"><?php esc_html_e( 'Sample product', 'sevof-connector' ); ?></div>
								<div class="pv-pricing">
									<span class="pv-price"><?php esc_html_e( '$129.00', 'sevof-connector' ); ?></span>
									<span class="pv-old">1,500,000</span>
									<span class="pv-stock"><?php esc_html_e( 'In stock', 'sevof-connector' ); ?></span>
								</div>
								<div class="pv-spec"><span class="pv-spec-k"><?php esc_html_e( 'Material', 'sevof-connector' ); ?></span><i></i><b><?php esc_html_e( 'Steel', 'sevof-connector' ); ?></b></div>
								<div class="pv-spec"><span class="pv-spec-k"><?php esc_html_e( 'Warranty', 'sevof-connector' ); ?></span><i></i><b><?php esc_html_e( '18 months', 'sevof-connector' ); ?></b></div>
								<span class="pv-cta"><?php esc_html_e( 'View product', 'sevof-connector' ); ?></span>
							</div>
						</div>

						<div class="pv-table-wrap">
							<table class="pv-table">
								<thead><tr><th><?php esc_html_e( 'Feature', 'sevof-connector' ); ?></th><th><?php esc_html_e( 'Model A', 'sevof-connector' ); ?></th><th><?php esc_html_e( 'Model B', 'sevof-connector' ); ?></th></tr></thead>
								<tbody>
									<tr><td><?php esc_html_e( 'Weight', 'sevof-connector' ); ?></td><td>2 kg</td><td>3 kg</td></tr>
									<tr><td><?php esc_html_e( 'Capacity', 'sevof-connector' ); ?></td><td>5 L</td><td>7 L</td></tr>
									<tr><td><?php esc_html_e( 'Price', 'sevof-connector' ); ?></td><td>1.2M</td><td>1.6M</td></tr>
								</tbody>
							</table>
						</div>

						<div class="pv-faq">
							<div class="pv-faq-title"><?php esc_html_e( 'Frequently asked questions', 'sevof-connector' ); ?></div>
							<div class="pv-faq-item is-open">
								<div class="pv-q"><span class="pv-ico">&minus;</span><?php esc_html_e( 'An open question', 'sevof-connector' ); ?></div>
								<div class="pv-ans"><?php esc_html_e( 'The answer to the question appears here.', 'sevof-connector' ); ?></div>
							</div>
							<div class="pv-faq-item">
								<div class="pv-q"><span class="pv-ico">+</span><?php esc_html_e( 'A closed question', 'sevof-connector' ); ?></div>
							</div>
						</div>
					</div>
				</div>
			</aside>
		</div>

		<div class="yxs-bar">
			<div class="yxs-bar-status">
				<span class="yxs-state" id="yxs-state" data-custom="<?php echo esc_attr( (string) $yxs_custom_count ); ?>"><?php esc_html_e( 'All changes saved.', 'sevof-connector' ); ?></span>
			</div>
			<div class="yxs-bar-actions">
				<button type="submit" name="yx_do" value="save" class="button button-primary yxs-save"><?php esc_html_e( 'Save changes', 'sevof-connector' ); ?></button>
				<button type="submit" name="yx_do" value="reset" class="button yxs-reset-all" id="yxs-reset-all"><?php esc_html_e( 'Reset all to automatic', 'sevof-connector' ); ?></button>
			</div>
		</div>
	</form>
</div>
