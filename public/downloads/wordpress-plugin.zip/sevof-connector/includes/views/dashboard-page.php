<?php
/**
 * Sevof dashboard page: connection form when not connected, service data when connected.
 *
 * @package SevofConnector
 *
 * @var string     $status
 * @var string     $message
 * @var bool       $has_client_id
 * @var bool       $has_client_secret
 * @var bool       $has_api_key
 * @var array|null $dashboard
 * @var array|null $keywords
 * @var array|null $entities
 * @var array|null $articles
 * @var array|null $product_articles
 * @var array|null $subscription
 * @var array      $debug_log_state
 * @var array      $last_error
 * @var array      $environment_report
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$sevof_panel_url = 'https://sevof.com';

$sevof_status_labels = array(
	'connected'     => __( 'Connected', 'sevof-connector' ),
	'disconnected'  => __( 'Disconnected', 'sevof-connector' ),
	'failed'        => __( 'Failed', 'sevof-connector' ),
	'not_connected' => __( 'Not connected', 'sevof-connector' ),
);

$sevof_enum_labels = array(
	'pending'    => __( 'Pending', 'sevof-connector' ),
	'completed'  => __( 'Completed', 'sevof-connector' ),
	'failed'     => __( 'Failed', 'sevof-connector' ),
	'published'  => __( 'Published', 'sevof-connector' ),
	'draft'      => __( 'Draft', 'sevof-connector' ),
	'processing' => __( 'Processing', 'sevof-connector' ),
	'generating' => __( 'Generating', 'sevof-connector' ),
	'paused'     => __( 'Paused (out of credit)', 'sevof-connector' ),
);

$sevof_keep_hint  = __( 'Leave empty to keep the saved value.', 'sevof-connector' );
$sevof_first_hint = __( 'Required for the first connection.', 'sevof-connector' );
?>
<div class="wrap sevof-wrap">
	<h1 class="wp-heading-inline"><?php esc_html_e( 'Sevof', 'sevof-connector' ); ?></h1>

	<?php if ( 'connected' === $status ) : ?>
		<a href="<?php echo esc_url( add_query_arg( array( 'page' => Sevof_Connector_Dashboard_Page::PAGE_SLUG, 'sevof_refresh' => '1' ), admin_url( 'admin.php' ) ) ); ?>" class="page-title-action"><?php esc_html_e( 'Refresh data', 'sevof-connector' ); ?></a>
	<?php endif; ?>

	<hr class="wp-header-end">

	<?php if ( '' !== $message ) : ?>
		<div class="notice notice-info"><p><?php echo esc_html( $message ); ?></p></div>
	<?php endif; ?>

	<?php if ( 'connected' !== $status ) : ?>
		<div class="yx-card">
			<h2><?php esc_html_e( 'Connect to Sevof', 'sevof-connector' ); ?></h2>

			<p>
				<?php esc_html_e( 'Current status:', 'sevof-connector' ); ?>
				<strong><?php echo esc_html( $sevof_status_labels[ $status ] ?? $status ); ?></strong>
			</p>

			<p class="yx-muted">
				<?php
				printf(
					/* translators: %s: link to the Sevof panel. */
					esc_html__( 'Enter the Client ID, Client Secret and API Key shown for this site in your %s account. They are stored on this site only and are never displayed again after saving.', 'sevof-connector' ),
					'<a href="' . esc_url( $sevof_panel_url ) . '" target="_blank" rel="noopener noreferrer">Sevof</a>'
				);
				?>
			</p>

			<form method="post">
				<?php wp_nonce_field( 'sevof_connector_save', 'sevof_connector_nonce' ); ?>
				<input type="hidden" name="sevof_connector_action" value="save_and_connect">

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="sevof-client-id"><?php esc_html_e( 'Client ID', 'sevof-connector' ); ?></label></th>
						<td>
							<input type="text" id="sevof-client-id" name="client_id" class="regular-text" value="" autocomplete="off" <?php echo $has_client_id ? '' : 'required'; ?> aria-describedby="sevof-client-id-description">
							<p id="sevof-client-id-description" class="description"><?php echo esc_html( $has_client_id ? $sevof_keep_hint : $sevof_first_hint ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="sevof-client-secret"><?php esc_html_e( 'Client Secret', 'sevof-connector' ); ?></label></th>
						<td>
							<input type="password" id="sevof-client-secret" name="client_secret" class="regular-text" value="" autocomplete="new-password" <?php echo $has_client_secret ? '' : 'required'; ?> aria-describedby="sevof-client-secret-description">
							<p id="sevof-client-secret-description" class="description"><?php echo esc_html( $has_client_secret ? $sevof_keep_hint : $sevof_first_hint ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="sevof-api-key"><?php esc_html_e( 'API Key', 'sevof-connector' ); ?></label></th>
						<td>
							<input type="password" id="sevof-api-key" name="api_key" class="regular-text" value="" autocomplete="new-password" <?php echo $has_api_key ? '' : 'required'; ?> aria-describedby="sevof-api-key-description">
							<p id="sevof-api-key-description" class="description"><?php echo esc_html( $has_api_key ? $sevof_keep_hint : $sevof_first_hint ); ?></p>
						</td>
					</tr>
				</table>

				<?php submit_button( __( 'Save and connect', 'sevof-connector' ), 'primary', 'submit', false ); ?>
			</form>
		</div>

		<?php if ( 'failed' === $status && ! empty( $last_error ) ) : ?>
			<?php
			$sevof_network_reason = __( 'WordPress could not reach the Sevof service at all (network or SSL error).', 'sevof-connector' );
			$sevof_block_labels   = array(
				'wp_error'            => $sevof_network_reason,
				'request_failed'      => $sevof_network_reason,
				'http_error'          => __( 'The Sevof service was reached but returned an error.', 'sevof-connector' ),
				'missing_credentials' => __( 'The Client ID, Client Secret or API Key is missing.', 'sevof-connector' ),
				'invalid_endpoint'    => __( 'The service address is invalid.', 'sevof-connector' ),
				'json_encode_failed'  => __( 'The request could not be built.', 'sevof-connector' ),
			);
			$sevof_yes_no         = static function ( $value ) {
				return ! empty( $value ) ? 'yes' : 'no';
			};
			$sevof_report_lines   = array(
				'Time: ' . ( $last_error['time'] ?? '-' ),
				'Event: ' . ( $last_error['event'] ?? '-' ),
				'HTTP status: ' . ( $last_error['status_code'] ?? '-' ),
				'Transport error code: ' . ( $last_error['error_code'] ?? '-' ),
				'Transport error message: ' . ( $last_error['error_message'] ?? '-' ),
				'Target host: ' . ( $environment_report['target_host'] ?? '-' ),
				'Plugin version: ' . SEVOF_CONNECTOR_VERSION,
				'PHP version: ' . ( $environment_report['php_version'] ?? '-' ),
				'WordPress version: ' . ( $environment_report['wp_version'] ?? '-' ),
				'cURL available: ' . $sevof_yes_no( $environment_report['curl_available'] ?? false ),
				'OpenSSL available: ' . $sevof_yes_no( $environment_report['openssl_available'] ?? false ),
				'WP_HTTP_BLOCK_EXTERNAL: ' . $sevof_yes_no( $environment_report['block_external'] ?? false ),
			);
			if ( ! empty( $environment_report['block_external'] ) ) {
				$sevof_report_lines[] = 'Host allowed in WP_ACCESSIBLE_HOSTS: ' . $sevof_yes_no( $environment_report['target_host_allowed'] ?? false );
			}
			?>
			<div class="yx-card">
				<h2><?php esc_html_e( 'Technical details (for Sevof support)', 'sevof-connector' ); ?></h2>
				<p class="yx-muted"><?php echo esc_html( $sevof_block_labels[ $last_error['event'] ?? '' ] ?? __( 'The connection failed.', 'sevof-connector' ) ); ?></p>

				<?php if ( ! empty( $environment_report['block_external'] ) && empty( $environment_report['target_host_allowed'] ) ) : ?>
					<div class="notice notice-warning inline"><p>
						<?php esc_html_e( 'WP_HTTP_BLOCK_EXTERNAL is enabled on this site and api.sevof.com is not listed in WP_ACCESSIBLE_HOSTS. This is most likely the cause.', 'sevof-connector' ); ?>
					</p></div>
				<?php elseif ( empty( $environment_report['curl_available'] ) ) : ?>
					<div class="notice notice-warning inline"><p>
						<?php esc_html_e( 'The PHP cURL extension is not enabled on this server. This is most likely the cause.', 'sevof-connector' ); ?>
					</p></div>
				<?php endif; ?>

				<p class="yx-muted"><?php esc_html_e( 'This report contains no credentials and is safe to send to Sevof support.', 'sevof-connector' ); ?></p>
				<label class="screen-reader-text" for="sevof-report"><?php esc_html_e( 'Technical report', 'sevof-connector' ); ?></label>
				<textarea id="sevof-report" class="yx-report" readonly rows="9"><?php echo esc_textarea( implode( "\n", $sevof_report_lines ) ); ?></textarea>
			</div>
		<?php endif; ?>

		<div class="yx-card">
			<h2><?php esc_html_e( 'Connection log', 'sevof-connector' ); ?></h2>

			<?php if ( 'disabled' === $debug_log_state['state'] ) : ?>
				<p class="yx-muted"><?php esc_html_e( 'WordPress debug logging is off, so there is no log to show.', 'sevof-connector' ); ?></p>
				<p class="yx-muted"><?php esc_html_e( 'To see connection details here, add these lines to wp-config.php (above the "That\'s all, stop editing!" line) and try connecting again:', 'sevof-connector' ); ?></p>
				<pre>define( 'WP_DEBUG', true );
define( 'WP_DEBUG_LOG', true );
define( 'WP_DEBUG_DISPLAY', false );</pre>
				<p class="yx-muted"><?php esc_html_e( 'This only writes a log file on your server; visitors never see the errors.', 'sevof-connector' ); ?></p>
			<?php elseif ( 'unreadable' === $debug_log_state['state'] ) : ?>
				<p class="yx-muted"><?php esc_html_e( 'Debug logging is on, but the debug log file could not be found or opened. Ask your host where the file is and check its permissions.', 'sevof-connector' ); ?></p>
			<?php elseif ( 'empty' === $debug_log_state['state'] ) : ?>
				<p class="yx-muted"><?php esc_html_e( 'Nothing has been logged yet. Try connecting again, then reload this page.', 'sevof-connector' ); ?></p>
			<?php else : ?>
				<p class="yx-muted"><?php esc_html_e( 'Newest entries first. Credentials are never written to this log.', 'sevof-connector' ); ?></p>
				<pre class="yx-log"><?php echo esc_html( implode( "\n", $debug_log_state['lines'] ) ); ?></pre>
				<p class="yx-muted"><?php esc_html_e( 'If you see an error above, copy it and send it to Sevof support.', 'sevof-connector' ); ?></p>
			<?php endif; ?>
		</div>
	</div>
		<?php
		return;
	endif;

	$sevof_summary              = ! empty( $dashboard['ok'] ) ? ( $dashboard['body']['data'] ?? array() ) : array();
	$sevof_keyword_list         = ! empty( $keywords['ok'] ) ? ( $keywords['body']['data'] ?? array() ) : array();
	$sevof_entity_list          = ! empty( $entities['ok'] ) ? ( $entities['body']['data'] ?? array() ) : array();
	$sevof_article_list         = ! empty( $articles['ok'] ) ? ( $articles['body']['data'] ?? array() ) : array();
	$sevof_product_article_list = ! empty( $product_articles['ok'] ) ? ( $product_articles['body']['data'] ?? array() ) : array();
	$sevof_product_stats        = is_array( $sevof_summary['product_statistics'] ?? null ) ? $sevof_summary['product_statistics'] : array();
	$sevof_sub                  = ! empty( $subscription['ok'] ) ? ( $subscription['body']['data'] ?? array() ) : array();

	// The limit can be 0 on a plan without credit; the low-credit warning needs a known limit.
	$sevof_credit_used          = (float) ( $sevof_sub['credit_used'] ?? 0 );
	$sevof_credit_limit         = (float) ( $sevof_sub['credit_limit'] ?? 0 );
	$sevof_credit_remaining     = max( 0, $sevof_credit_limit - $sevof_credit_used );
	$sevof_credit_used_pct      = $sevof_credit_limit > 0 ? min( 100, ( $sevof_credit_used / $sevof_credit_limit ) * 100 ) : 0;
	$sevof_credit_remaining_pct = $sevof_credit_limit > 0 ? max( 0, 100 - $sevof_credit_used_pct ) : 0;
	$sevof_has_queued_plan      = ! empty( $sevof_sub['has_queued_plan'] );
	// A queued plan takes over automatically, so the "renew now" alert only shows without one.
	$sevof_show_low_alert   = ! empty( $subscription['ok'] ) && $sevof_credit_limit > 0 && $sevof_credit_remaining_pct < 20 && ! $sevof_has_queued_plan;
	$sevof_credit_exhausted = $sevof_credit_limit > 0 && $sevof_credit_remaining <= 0;
	$sevof_is_free_plan     = ! empty( $sevof_sub['is_free'] );
	$sevof_subscription_url = $sevof_panel_url . '/subscription';

	$sevof_fmt_credit = static function ( $value ) {
		$value = (float) $value;

		return number_format_i18n( $value, abs( $value - round( $value ) ) < 0.005 ? 0 : 1 );
	};

	// Prices come from the service in the smallest currency unit (cents).
	$sevof_fmt_price = static function ( $cents, $currency ) {
		$amount   = number_format_i18n( ( (int) $cents ) / 100, 2 );
		$currency = strtoupper( (string) $currency );

		return 'USD' === $currency ? '$' . $amount : $amount . ' ' . $currency;
	};

	$sevof_format_date = static function ( $value ) {
		if ( ! is_string( $value ) || '' === $value ) {
			return '-';
		}
		$timestamp = strtotime( $value );

		return false === $timestamp ? $value : wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp );
	};

	$sevof_render_stats = static function ( array $cards ) {
		echo '<div class="yx-stats">';
		foreach ( $cards as $label => $value ) {
			echo '<div class="yx-stat"><div class="yx-stat-num">' . esc_html( $value ) . '</div><div class="yx-stat-label">' . esc_html( $label ) . '</div></div>';
		}
		echo '</div>';
	};

	$sevof_stat_cards = static function ( array $stats, string $total_label ) {
		return array(
			$total_label                              => $stats['total_articles'] ?? '-',
			__( 'Published', 'sevof-connector' )      => $stats['published'] ?? '-',
			__( 'Generating', 'sevof-connector' )     => $stats['generating'] ?? '-',
			__( 'Failed', 'sevof-connector' )         => $stats['failed'] ?? '-',
		);
	};

	// Regular and product articles share the columns; only regular articles have an SEO score.
	$sevof_render_articles_table = static function ( array $list, array $labels, bool $show_seo ) use ( $sevof_format_date ) {
		?>
		<table class="wp-list-table widefat fixed striped">
			<thead><tr>
				<th scope="col"><?php esc_html_e( 'Title', 'sevof-connector' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Status', 'sevof-connector' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Publishing', 'sevof-connector' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Post', 'sevof-connector' ); ?></th>
				<?php if ( $show_seo ) : ?>
					<th scope="col"><?php esc_html_e( 'SEO score', 'sevof-connector' ); ?></th>
				<?php endif; ?>
				<th scope="col"><?php esc_html_e( 'Words', 'sevof-connector' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Published', 'sevof-connector' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Last sync', 'sevof-connector' ); ?></th>
			</tr></thead>
			<tbody>
				<?php foreach ( $list as $sevof_article ) : ?>
					<tr>
						<td><?php echo esc_html( $sevof_article['title'] ?? '-' ); ?></td>
						<td><?php echo esc_html( Sevof_Connector_Dashboard_Page::label( $sevof_article['status'] ?? null, $labels ) ); ?></td>
						<td><?php echo esc_html( Sevof_Connector_Dashboard_Page::label( $sevof_article['publish_status'] ?? null, $labels ) ); ?></td>
						<td>
							<?php if ( ! empty( $sevof_article['wp_permalink'] ) ) : ?>
								<a href="<?php echo esc_url( $sevof_article['wp_permalink'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'View', 'sevof-connector' ); ?></a>
							<?php elseif ( ! empty( $sevof_article['wp_post_id'] ) ) : ?>
								#<?php echo esc_html( $sevof_article['wp_post_id'] ); ?>
							<?php else : ?>
								<?php esc_html_e( 'Not published', 'sevof-connector' ); ?>
							<?php endif; ?>
						</td>
						<?php if ( $show_seo ) : ?>
							<td><?php echo esc_html( $sevof_article['seo_score'] ?? '-' ); ?></td>
						<?php endif; ?>
						<td><?php echo esc_html( isset( $sevof_article['word_count'] ) ? number_format_i18n( (int) $sevof_article['word_count'] ) : '-' ); ?></td>
						<td><?php echo esc_html( $sevof_format_date( $sevof_article['published_at'] ?? null ) ); ?></td>
						<td><?php echo esc_html( $sevof_format_date( $sevof_article['last_synced_at'] ?? null ) ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	};
	?>

	<p>
		<?php esc_html_e( 'Connection status:', 'sevof-connector' ); ?>
		<strong class="yx-ok"><?php esc_html_e( 'Connected', 'sevof-connector' ); ?></strong>
	</p>

	<?php if ( $sevof_show_low_alert ) : ?>
		<div class="yx-credit-alert" role="alert">
			<div class="yx-credit-alert-icon" aria-hidden="true">⚠️</div>
			<div class="yx-credit-alert-body">
				<strong>
					<?php
					echo esc_html(
						$sevof_credit_exhausted
							? __( 'Your credit has run out.', 'sevof-connector' )
							: __( 'Your credit is running low.', 'sevof-connector' )
					);
					?>
				</strong>
				<p>
					<?php
					echo esc_html(
						$sevof_credit_exhausted
							? __( 'Renew or upgrade your plan to keep generating and publishing articles.', 'sevof-connector' )
							: sprintf(
								/* translators: %s: percentage of credit remaining. */
								__( 'Only %s%% of your credit is left. Renew your plan so article generation and publishing do not stop.', 'sevof-connector' ),
								number_format_i18n( $sevof_credit_remaining_pct, 1 )
							)
					);
					?>
				</p>
			</div>
			<a href="<?php echo esc_url( $sevof_subscription_url ); ?>" target="_blank" rel="noopener noreferrer" class="yx-credit-alert-btn"><?php esc_html_e( 'Renew plan', 'sevof-connector' ); ?></a>
		</div>
	<?php endif; ?>

	<h2><?php esc_html_e( 'Plan and credit', 'sevof-connector' ); ?></h2>
	<?php if ( empty( $subscription['ok'] ) ) : ?>
		<div class="notice notice-error inline"><p><?php echo esc_html( $subscription['message'] ?? __( 'Could not load your plan.', 'sevof-connector' ) ); ?></p></div>
	<?php else : ?>
		<div class="yx-card yx-sub-card">
			<div class="yx-sub-head">
				<div class="yx-sub-plan">
					<span class="yx-badge <?php echo $sevof_is_free_plan ? 'yx-badge--free' : 'yx-badge--paid'; ?>">
						<?php echo esc_html( $sevof_is_free_plan ? __( 'Free plan', 'sevof-connector' ) : __( 'Paid plan', 'sevof-connector' ) ); ?>
					</span>
					<?php if ( ! $sevof_is_free_plan && ! empty( $sevof_sub['price'] ) ) : ?>
						<span class="yx-sub-price"><?php echo esc_html( $sevof_fmt_price( $sevof_sub['price'], $sevof_sub['currency'] ?? 'USD' ) ); ?></span>
						<?php if ( ! empty( $sevof_sub['discount_percentage'] ) ) : ?>
							<span class="yx-badge yx-badge--discount">
								<?php
								/* translators: %s: discount percentage. */
								echo esc_html( sprintf( __( '%s%% off', 'sevof-connector' ), number_format_i18n( $sevof_sub['discount_percentage'] ) ) );
								?>
							</span>
						<?php endif; ?>
					<?php endif; ?>
				</div>
				<a href="<?php echo esc_url( $sevof_subscription_url ); ?>" target="_blank" rel="noopener noreferrer" class="button button-primary yx-sub-manage"><?php esc_html_e( 'Manage plan', 'sevof-connector' ); ?></a>
			</div>

			<?php if ( $sevof_credit_limit > 0 ) : ?>
				<div class="yx-credit-block">
					<div class="yx-credit-row">
						<span>
							<?php
							/* translators: 1: credit used, 2: credit limit. */
							echo esc_html( sprintf( __( '%1$s of %2$s credits used', 'sevof-connector' ), $sevof_fmt_credit( $sevof_credit_used ), $sevof_fmt_credit( $sevof_credit_limit ) ) );
							?>
						</span>
						<strong class="<?php echo $sevof_show_low_alert ? 'yx-credit-pct--low' : ''; ?>">
							<?php
							/* translators: %s: remaining percentage. */
							echo esc_html( sprintf( __( '%s%% left', 'sevof-connector' ), number_format_i18n( $sevof_credit_remaining_pct, 1 ) ) );
							?>
						</strong>
					</div>
					<div class="yx-credit-bar-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo esc_attr( round( $sevof_credit_used_pct ) ); ?>">
						<div class="yx-credit-bar-fill<?php echo $sevof_show_low_alert ? ' yx-credit-bar-fill--low' : ''; ?>" style="width:<?php echo esc_attr( round( $sevof_credit_used_pct, 2 ) ); ?>%;"></div>
					</div>
				</div>
			<?php else : ?>
				<p class="yx-muted yx-sub-note"><?php esc_html_e( 'This plan has no credit limit set.', 'sevof-connector' ); ?></p>
			<?php endif; ?>

			<?php if ( $sevof_has_queued_plan ) : ?>
				<div class="yx-queued-plan">
					<span class="yx-queued-icon" aria-hidden="true">⏭</span>
					<div class="yx-queued-text">
						<div>
							<?php esc_html_e( 'Next plan (queued):', 'sevof-connector' ); ?>
							<strong><?php echo esc_html( ! empty( $sevof_sub['queued_plan_name'] ) ? $sevof_sub['queued_plan_name'] : '-' ); ?></strong>
							<span class="yx-queued-sep" aria-hidden="true">•</span>
							<?php
							/* translators: %s: credit of the queued plan. */
							echo esc_html( sprintf( __( 'Credit: %s', 'sevof-connector' ), $sevof_fmt_credit( $sevof_sub['queued_plan_credit'] ?? 0 ) ) );
							?>
						</div>
						<small class="yx-muted"><?php esc_html_e( 'It starts automatically when the current plan ends, so article generation continues without a break.', 'sevof-connector' ); ?></small>
					</div>
				</div>
			<?php endif; ?>

			<?php if ( $sevof_is_free_plan ) : ?>
				<div class="yx-upgrade-promo">
					<div class="yx-upgrade-promo-text">
						<h3><?php esc_html_e( 'Publish on autopilot', 'sevof-connector' ); ?></h3>
						<ul>
							<li><?php esc_html_e( 'Automatic, uninterrupted publishing', 'sevof-connector' ); ?></li>
							<li><?php esc_html_e( 'Schedule the exact day and time', 'sevof-connector' ); ?></li>
							<li><?php esc_html_e( 'Deeper, better optimized articles', 'sevof-connector' ); ?></li>
						</ul>
					</div>
					<a href="<?php echo esc_url( $sevof_subscription_url ); ?>" target="_blank" rel="noopener noreferrer" class="yx-upgrade-promo-btn"><?php esc_html_e( 'Upgrade', 'sevof-connector' ); ?></a>
				</div>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<h2><?php esc_html_e( 'Overview', 'sevof-connector' ); ?></h2>
	<?php if ( empty( $dashboard['ok'] ) ) : ?>
		<div class="notice notice-error inline"><p><?php echo esc_html( $dashboard['message'] ?? __( 'Could not load the overview.', 'sevof-connector' ) ); ?></p></div>
	<?php else : ?>
		<?php
		$sevof_render_stats( $sevof_stat_cards( (array) ( $sevof_summary['statistics'] ?? array() ), __( 'Total articles', 'sevof-connector' ) ) );
		$sevof_on  = __( 'On', 'sevof-connector' );
		$sevof_off = __( 'Off', 'sevof-connector' );
		?>
		<ul class="yx-summary">
			<li>
				<?php esc_html_e( 'Idea generation:', 'sevof-connector' ); ?>
				<strong><?php echo esc_html( ! empty( $sevof_summary['ideas']['enabled'] ) ? $sevof_on : $sevof_off ); ?></strong>
				<?php
				$sevof_daily_ideas = (int) ( $sevof_summary['ideas']['daily_count'] ?? 0 );
				/* translators: %s: number of ideas per day. */
				echo esc_html( sprintf( _n( '(%s idea per day)', '(%s ideas per day)', $sevof_daily_ideas, 'sevof-connector' ), number_format_i18n( $sevof_daily_ideas ) ) );
				?>
			</li>
			<li>
				<?php esc_html_e( 'Article generation:', 'sevof-connector' ); ?>
				<strong><?php echo esc_html( ! empty( $sevof_summary['articles']['enabled'] ) ? $sevof_on : $sevof_off ); ?></strong>
				<?php
				/* translators: %s: daily article limit. */
				echo esc_html( sprintf( __( '(daily limit: %s)', 'sevof-connector' ), number_format_i18n( (int) ( $sevof_summary['articles']['daily_limit'] ?? 0 ) ) ) );
				?>
			</li>
			<li>
				<?php esc_html_e( 'Agent status:', 'sevof-connector' ); ?>
				<strong><?php echo esc_html( $sevof_summary['agent_status'] ?? '-' ); ?></strong>
			</li>
		</ul>
	<?php endif; ?>

	<h2><?php esc_html_e( 'Articles', 'sevof-connector' ); ?></h2>

	<div class="yx-tabs" role="tablist">
		<button type="button" class="yx-tab" role="tab" id="yx-tab-articles" aria-controls="yx-panel-articles" aria-selected="true" data-yx-tab="articles">
			<?php esc_html_e( 'Articles', 'sevof-connector' ); ?>
			<?php if ( ! empty( $articles['ok'] ) ) : ?>
				<span class="yx-tab-count"><?php echo esc_html( number_format_i18n( count( $sevof_article_list ) ) ); ?></span>
			<?php endif; ?>
		</button>
		<button type="button" class="yx-tab" role="tab" id="yx-tab-products" aria-controls="yx-panel-products" aria-selected="false" data-yx-tab="products">
			<?php esc_html_e( 'Product articles', 'sevof-connector' ); ?>
			<?php if ( ! empty( $product_articles['ok'] ) ) : ?>
				<span class="yx-tab-count"><?php echo esc_html( number_format_i18n( count( $sevof_product_article_list ) ) ); ?></span>
			<?php endif; ?>
		</button>
	</div>

	<div class="yx-tabpanel" role="tabpanel" id="yx-panel-articles" aria-labelledby="yx-tab-articles">
		<?php if ( empty( $articles['ok'] ) ) : ?>
			<div class="notice notice-error inline"><p><?php echo esc_html( $articles['message'] ?? __( 'Could not load articles.', 'sevof-connector' ) ); ?></p></div>
		<?php elseif ( empty( $sevof_article_list ) ) : ?>
			<p><?php esc_html_e( 'No articles for this site yet.', 'sevof-connector' ); ?></p>
		<?php else : ?>
			<?php $sevof_render_articles_table( $sevof_article_list, $sevof_enum_labels, true ); ?>
		<?php endif; ?>
	</div>

	<div class="yx-tabpanel" role="tabpanel" id="yx-panel-products" aria-labelledby="yx-tab-products">
		<?php if ( empty( $product_articles['ok'] ) ) : ?>
			<div class="notice notice-error inline"><p><?php echo esc_html( $product_articles['message'] ?? __( 'Could not load product articles.', 'sevof-connector' ) ); ?></p></div>
		<?php else : ?>
			<?php
			if ( ! empty( $sevof_product_stats ) ) {
				$sevof_render_stats( $sevof_stat_cards( $sevof_product_stats, __( 'Total product articles', 'sevof-connector' ) ) );
			}
			?>
			<?php if ( empty( $sevof_product_article_list ) ) : ?>
				<p><?php esc_html_e( 'No product articles for this site yet.', 'sevof-connector' ); ?></p>
			<?php else : ?>
				<?php $sevof_render_articles_table( $sevof_product_article_list, $sevof_enum_labels, false ); ?>
			<?php endif; ?>
		<?php endif; ?>
	</div>

	<h2><?php esc_html_e( 'Suggested keywords', 'sevof-connector' ); ?></h2>
	<?php if ( empty( $keywords['ok'] ) ) : ?>
		<div class="notice notice-error inline"><p><?php echo esc_html( $keywords['message'] ?? __( 'Could not load keywords.', 'sevof-connector' ) ); ?></p></div>
	<?php elseif ( empty( $sevof_keyword_list ) ) : ?>
		<p><?php esc_html_e( 'No keywords yet.', 'sevof-connector' ); ?></p>
	<?php else : ?>
		<p>
			<?php foreach ( $sevof_keyword_list as $sevof_keyword ) : ?>
				<span class="yx-chip"><?php echo esc_html( is_scalar( $sevof_keyword ) ? $sevof_keyword : '' ); ?></span>
			<?php endforeach; ?>
		</p>
	<?php endif; ?>

	<h2><?php esc_html_e( 'Entities', 'sevof-connector' ); ?></h2>
	<?php if ( empty( $entities['ok'] ) ) : ?>
		<div class="notice notice-error inline"><p><?php echo esc_html( $entities['message'] ?? __( 'Could not load entities.', 'sevof-connector' ) ); ?></p></div>
	<?php elseif ( empty( $sevof_entity_list ) ) : ?>
		<p><?php esc_html_e( 'No entities yet.', 'sevof-connector' ); ?></p>
	<?php else : ?>
		<table class="wp-list-table widefat fixed striped yx-table-narrow">
			<thead><tr>
				<th scope="col"><?php esc_html_e( 'Name', 'sevof-connector' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Type', 'sevof-connector' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Scope', 'sevof-connector' ); ?></th>
			</tr></thead>
			<tbody>
				<?php foreach ( $sevof_entity_list as $sevof_entity ) : ?>
					<tr>
						<td><?php echo esc_html( $sevof_entity['name'] ?? '-' ); ?></td>
						<td><?php echo esc_html( $sevof_entity['type'] ?? '-' ); ?></td>
						<td><?php echo esc_html( $sevof_entity['scope'] ?? '-' ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>

	<p class="yx-muted yx-footnote">
		<?php
		printf(
			/* translators: %s: link to the Sevof panel. */
			esc_html__( 'Article ideas, settings and publishing schedules are managed in your %s panel.', 'sevof-connector' ),
			'<a href="' . esc_url( $sevof_panel_url ) . '" target="_blank" rel="noopener noreferrer">Sevof</a>'
		);
		?>
	</p>

	<hr>
	<h2><?php esc_html_e( 'Disconnect', 'sevof-connector' ); ?></h2>
	<p class="yx-muted"><?php esc_html_e( 'Disconnecting stops dashboard requests and health checks. Your credentials stay saved so you can reconnect later. Published posts are not touched.', 'sevof-connector' ); ?></p>
	<form method="post" data-sevof-disconnect>
		<?php wp_nonce_field( 'sevof_connector_save', 'sevof_connector_nonce' ); ?>
		<input type="hidden" name="sevof_connector_action" value="disconnect">
		<?php submit_button( __( 'Disconnect', 'sevof-connector' ), 'delete', 'submit', false ); ?>
	</form>
</div>
