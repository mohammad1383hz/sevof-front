<?php
/**
 * Brand color detection from the site's logo.
 *
 * The connector styles articles and product cards with the site's accent color.
 * This class finds that color from the one thing that defines a brand best: the
 * logo. It never touches the network, never changes the image, and any failure
 * simply means "no logo color" so the caller falls back to theme settings.
 *
 * How the color is picked
 *  - Raster logos (PNG, JPG, GIF, WebP, AVIF, BMP) are sampled on an even grid
 *    straight from the decoded image (no resizing, so anti-aliasing never invents
 *    colors). Transparent pixels are ignored.
 *  - SVG logos are read as text (no XML parser, no external loading). Every painted
 *    shape contributes its fill / stroke color weighted by its estimated area;
 *    gradients are averaged, <style> classes, inline styles, CSS variables,
 *    <use> references, transforms and opacity are honoured.
 *  - Both end up in the same color histogram. White / near-white paper, black and
 *    grey ink are set aside, the remaining vivid pixels vote for a hue (weighted
 *    by area x saturation) and the winning hue family yields the exact flat brand
 *    color, or the weighted mean for gradients / JPEG noise.
 *  - A logo with no real color (black or grey only) is reported as achromatic so
 *    the caller can prefer a colorful theme/site-icon accent over it.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sevof_Connector_Logo_Color {
	// Bump when the algorithm changes so cached results are recomputed.
	const ALGO_VERSION = 3;

	const CACHE_KEY = 'sevof_connector_logo_color';
	const CACHE_TTL = 2592000; // 30 days; the cache key also tracks the file itself.

	const MAX_RASTER_BYTES  = 8388608;
	const MAX_SVG_BYTES     = 1048576;
	const MAX_RASTER_PIXELS = 6000000;
	const SAMPLE_GRID       = 320;

	// SVG drawing: canvas size and safety limits.
	const GRID       = 160;
	const MAX_SHAPES = 6000;
	const MAX_POINTS = 500000;

	// A pixel needs this much saturation / brightness / chroma to count as "colored".
	const MIN_SATURATION = 0.25;
	const MIN_VALUE      = 0.22;
	const MIN_CHROMA     = 26;
	// Colored ink must be at least this share of all ink to call the logo colorful.
	const MIN_COLOR_SHARE = 0.03;
	// Hue family half-width (degrees) that counts as "the same brand color".
	const HUE_RADIUS = 20.0;

	const CSS_PROPS = array( 'fill', 'stroke', 'opacity', 'fill-opacity', 'stroke-opacity', 'stroke-width', 'color', 'stop-color', 'stop-opacity', 'fill-rule', 'display', 'visibility' );

	/**
	 * Named CSS colors (lowercase name => rrggbb), parsed lazily.
	 */
	const NAMED_COLORS = 'aliceblue:f0f8ff,antiquewhite:faebd7,aqua:00ffff,aquamarine:7fffd4,azure:f0ffff,beige:f5f5dc,bisque:ffe4c4,black:000000,blanchedalmond:ffebcd,blue:0000ff,blueviolet:8a2be2,brown:a52a2a,burlywood:deb887,cadetblue:5f9ea0,chartreuse:7fff00,chocolate:d2691e,coral:ff7f50,cornflowerblue:6495ed,cornsilk:fff8dc,crimson:dc143c,cyan:00ffff,darkblue:00008b,darkcyan:008b8b,darkgoldenrod:b8860b,darkgray:a9a9a9,darkgreen:006400,darkgrey:a9a9a9,darkkhaki:bdb76b,darkmagenta:8b008b,darkolivegreen:556b2f,darkorange:ff8c00,darkorchid:9932cc,darkred:8b0000,darksalmon:e9967a,darkseagreen:8fbc8f,darkslateblue:483d8b,darkslategray:2f4f4f,darkslategrey:2f4f4f,darkturquoise:00ced1,darkviolet:9400d3,deeppink:ff1493,deepskyblue:00bfff,dimgray:696969,dimgrey:696969,dodgerblue:1e90ff,firebrick:b22222,floralwhite:fffaf0,forestgreen:228b22,fuchsia:ff00ff,gainsboro:dcdcdc,ghostwhite:f8f8ff,gold:ffd700,goldenrod:daa520,gray:808080,green:008000,greenyellow:adff2f,grey:808080,honeydew:f0fff0,hotpink:ff69b4,indianred:cd5c5c,indigo:4b0082,ivory:fffff0,khaki:f0e68c,lavender:e6e6fa,lavenderblush:fff0f5,lawngreen:7cfc00,lemonchiffon:fffacd,lightblue:add8e6,lightcoral:f08080,lightcyan:e0ffff,lightgoldenrodyellow:fafad2,lightgray:d3d3d3,lightgreen:90ee90,lightgrey:d3d3d3,lightpink:ffb6c1,lightsalmon:ffa07a,lightseagreen:20b2aa,lightskyblue:87cefa,lightslategray:778899,lightslategrey:778899,lightsteelblue:b0c4de,lightyellow:ffffe0,lime:00ff00,limegreen:32cd32,linen:faf0e6,magenta:ff00ff,maroon:800000,mediumaquamarine:66cdaa,mediumblue:0000cd,mediumorchid:ba55d3,mediumpurple:9370db,mediumseagreen:3cb371,mediumslateblue:7b68ee,mediumspringgreen:00fa9a,mediumturquoise:48d1cc,mediumvioletred:c71585,midnightblue:191970,mintcream:f5fffa,mistyrose:ffe4e1,moccasin:ffe4b5,navajowhite:ffdead,navy:000080,oldlace:fdf5e6,olive:808000,olivedrab:6b8e23,orange:ffa500,orangered:ff4500,orchid:da70d6,palegoldenrod:eee8aa,palegreen:98fb98,paleturquoise:afeeee,palevioletred:db7093,papayawhip:ffefd5,peachpuff:ffdab9,peru:cd853f,pink:ffc0cb,plum:dda0dd,powderblue:b0e0e6,purple:800080,rebeccapurple:663399,red:ff0000,rosybrown:bc8f8f,royalblue:4169e1,saddlebrown:8b4513,salmon:fa8072,sandybrown:f4a460,seagreen:2e8b57,seashell:fff5ee,sienna:a0522d,silver:c0c0c0,skyblue:87ceeb,slateblue:6a5acd,slategray:708090,slategrey:708090,snow:fffafa,springgreen:00ff7f,steelblue:4682b4,tan:d2b48c,teal:008080,thistle:d8bfd8,tomato:ff6347,turquoise:40e0d0,violet:ee82ee,wheat:f5deb3,white:ffffff,whitesmoke:f5f5f5,yellow:ffff00,yellowgreen:9acd32';

	/**
	 * Detects the logo's brand color for this site.
	 *
	 * @return array|null array( 'hex' => '#rrggbb', 'chromatic' => bool, 'source' => string, 'share' => float ) or null.
	 */
	public static function detect() {
		static $done = false;
		static $memo = null;
		if ( $done ) {
			return $memo;
		}
		$done = true;

		try {
			$sources = self::collect_sources();
			if ( empty( $sources ) ) {
				return null;
			}

			$sig    = self::signature( $sources );
			$cached = get_transient( self::CACHE_KEY );
			if ( is_array( $cached ) && isset( $cached['sig'] ) && $cached['sig'] === $sig && array_key_exists( 'result', $cached ) ) {
				$memo = is_array( $cached['result'] ) ? $cached['result'] : null;
				return $memo;
			}

			$incomplete = false;
			$result     = self::resolve( $sources, $incomplete );
			if ( ! $incomplete ) {
				set_transient(
					self::CACHE_KEY,
					array(
						'sig'    => $sig,
						'result' => $result,
					),
					self::CACHE_TTL
				);
			}
			$memo = $result;
		} catch ( \Throwable $e ) {
			$memo = null;
		}

		return $memo;
	}

	/**
	 * Picks the best result across the candidate images: the first colorful one
	 * wins; otherwise the first achromatic (black/grey) one is kept as a fallback.
	 */
	private static function resolve( array $sources, &$incomplete ) {
		$achromatic = null;
		foreach ( $sources as $source ) {
			$res = self::analyze_source( $source, $incomplete );
			if ( ! $res ) {
				continue;
			}
			$res['source'] = $source['label'];
			if ( $res['chromatic'] ) {
				return $res;
			}
			if ( null === $achromatic ) {
				$achromatic = $res;
			}
		}

		return $achromatic;
	}

	/**
	 * Analyzes one image file (via its attachment when it is too big to decode).
	 */
	private static function analyze_source( array $source, &$incomplete ) {
		$path = $source['path'];
		$ext  = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );

		if ( 'svg' === $ext ) {
			return self::analyze_file( $path );
		}

		if ( ! in_array( $ext, array( 'png', 'jpg', 'jpeg', 'jpe', 'gif', 'webp', 'avif', 'bmp' ), true ) ) {
			return null;
		}
		if ( ! function_exists( 'imagecreatefromstring' ) ) {
			$incomplete = true;
			return null;
		}

		$size = @getimagesize( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- unreadable/corrupt images are simply skipped.
		if ( $size && ( (int) $size[0] * (int) $size[1] ) > self::MAX_RASTER_PIXELS ) {
			// Too large to decode safely: use a WordPress-generated, uncropped size.
			$alt = self::intermediate_path( $source, (int) $size[0], (int) $size[1] );
			if ( ! $alt ) {
				return null;
			}
			$path = $alt;
		}

		return self::analyze_file( $path );
	}

	/**
	 * Finds a resized copy of the attachment with the same aspect ratio (so it was
	 * not cropped) that is large enough to analyze and small enough to decode.
	 */
	private static function intermediate_path( array $source, $w, $h ) {
		if ( empty( $source['id'] ) || ! function_exists( 'wp_get_attachment_metadata' ) || $w <= 0 || $h <= 0 ) {
			return '';
		}
		$meta = wp_get_attachment_metadata( (int) $source['id'] );
		if ( ! is_array( $meta ) || empty( $meta['sizes'] ) || ! is_array( $meta['sizes'] ) ) {
			return '';
		}

		$ratio = $w / $h;
		$best  = '';
		$best_side = 0;
		foreach ( $meta['sizes'] as $size ) {
			if ( ! is_array( $size ) || empty( $size['file'] ) || empty( $size['width'] ) || empty( $size['height'] ) ) {
				continue;
			}
			$sw = (int) $size['width'];
			$sh = (int) $size['height'];
			if ( $sw <= 0 || $sh <= 0 || abs( ( $sw / $sh ) - $ratio ) / $ratio > 0.02 ) {
				continue;
			}
			$side = max( $sw, $sh );
			if ( $side < 200 || ( $sw * $sh ) > self::MAX_RASTER_PIXELS ) {
				continue;
			}
			// Prefer the smallest size that is still big enough.
			if ( '' === $best || $side < $best_side ) {
				$candidate = dirname( $source['path'] ) . '/' . basename( (string) $size['file'] );
				if ( is_readable( $candidate ) ) {
					$best      = $candidate;
					$best_side = $side;
				}
			}
		}

		return $best;
	}

	/**
	 * Lists the images that represent the brand, most authoritative first.
	 *
	 * @return array[] Each: array( 'label' => string, 'id' => int, 'path' => string ).
	 */
	private static function collect_sources(): array {
		$out  = array();
		$seen = array();

		$add = function ( $label, $id, $path ) use ( &$out, &$seen ) {
			$real = self::safe_path( $path );
			if ( '' === $real || isset( $seen[ $real ] ) || count( $out ) >= 8 ) {
				return;
			}
			$seen[ $real ] = true;
			$out[]         = array(
				'label' => $label,
				'id'    => (int) $id,
				'path'  => $real,
			);
		};

		$forced = apply_filters( 'sevof_connector_logo_path', '' );
		if ( is_string( $forced ) && '' !== $forced ) {
			$add( 'filter', 0, $forced );
		}

		$values = array(
			'custom_logo' => get_theme_mod( 'custom_logo' ),
			'site_logo'   => get_option( 'site_logo' ),
		);
		foreach ( array( 'logo', 'site_logo', 'header_logo', 'logo_image', 'theme_logo', 'main_logo', 'sticky_logo', 'retina_logo' ) as $mod ) {
			$values[ 'mod:' . $mod ] = get_theme_mod( $mod );
		}
		$astra = get_option( 'astra-settings' );
		if ( is_array( $astra ) ) {
			foreach ( array( 'ast-header-responsive-logo-desktop', 'ast-header-retina-logo' ) as $key ) {
				if ( isset( $astra[ $key ] ) ) {
					$values[ 'astra:' . $key ] = $astra[ $key ];
				}
			}
		}
		$divi = get_option( 'et_divi' );
		if ( is_array( $divi ) && isset( $divi['divi_logo'] ) ) {
			$values['divi'] = $divi['divi_logo'];
		}
		$values['site_icon'] = get_option( 'site_icon' );

		foreach ( $values as $label => $value ) {
			list( $id, $path ) = self::resolve_image_value( $value );
			if ( '' !== $path ) {
				$add( $label, $id, $path );
			}
		}

		return $out;
	}

	/**
	 * Turns an attachment ID, URL or {id,url} array from a theme setting into a
	 * local file path.
	 *
	 * @return array array( int $id, string $path ).
	 */
	private static function resolve_image_value( $value ): array {
		if ( is_array( $value ) ) {
			if ( isset( $value['id'] ) && is_numeric( $value['id'] ) && (int) $value['id'] > 0 ) {
				$value = $value['id'];
			} elseif ( isset( $value['url'] ) ) {
				$value = $value['url'];
			} else {
				return array( 0, '' );
			}
		}

		if ( is_numeric( $value ) && (int) $value > 0 ) {
			$id   = (int) $value;
			$file = get_attached_file( $id );
			return array( $id, is_string( $file ) ? $file : '' );
		}

		if ( is_string( $value ) && preg_match( '~^(https?:)?//|^/~i', $value ) ) {
			return array( 0, self::url_to_path( $value ) );
		}

		return array( 0, '' );
	}

	/**
	 * Maps a URL on this site (uploads, theme, wp-content) to its file path.
	 */
	private static function url_to_path( $url ): string {
		$url = preg_replace( '~[?#].*$~', '', (string) $url );
		if ( 0 === strpos( $url, '//' ) ) {
			$url = ( is_ssl() ? 'https:' : 'http:' ) . $url;
		}
		if ( 0 === strpos( $url, '/' ) ) {
			$url = home_url( $url );
		}

		$upload = wp_get_upload_dir();
		$maps   = array();
		if ( ! empty( $upload['baseurl'] ) && ! empty( $upload['basedir'] ) ) {
			$maps[] = array( $upload['baseurl'], $upload['basedir'] );
		}
		$maps[] = array( get_stylesheet_directory_uri(), get_stylesheet_directory() );
		$maps[] = array( get_template_directory_uri(), get_template_directory() );
		$maps[] = array( content_url(), WP_CONTENT_DIR );

		foreach ( $maps as $map ) {
			// Compare scheme-insensitively (http/https mixups are common in stored URLs).
			$base = preg_replace( '~^https?:~i', '', untrailingslashit( $map[0] ) );
			$cmp  = preg_replace( '~^https?:~i', '', $url );
			if ( '' !== $base && 0 === strpos( $cmp, $base . '/' ) ) {
				return untrailingslashit( $map[1] ) . '/' . rawurldecode( ltrim( substr( $cmp, strlen( $base ) ), '/' ) );
			}
		}

		return '';
	}

	/**
	 * Returns the real path only when it is a readable file inside wp-content or
	 * the uploads folder (never an arbitrary file on the server).
	 */
	private static function safe_path( $path ): string {
		if ( ! is_string( $path ) || '' === $path || false !== strpos( $path, "\0" ) ) {
			return '';
		}
		$real = realpath( $path );
		if ( false === $real || ! is_file( $real ) || ! is_readable( $real ) ) {
			return '';
		}

		$roots  = array();
		$upload = wp_get_upload_dir();
		if ( ! empty( $upload['basedir'] ) ) {
			$roots[] = $upload['basedir'];
		}
		if ( defined( 'WP_CONTENT_DIR' ) ) {
			$roots[] = WP_CONTENT_DIR;
		}
		foreach ( $roots as $root ) {
			$root_real = realpath( $root );
			if ( false !== $root_real && 0 === strpos( $real, rtrim( $root_real, '/\\' ) . DIRECTORY_SEPARATOR ) ) {
				return $real;
			}
		}

		return '';
	}

	/**
	 * Fingerprint of every candidate image, so the cached color is reused until
	 * the logo (or its file) actually changes.
	 */
	private static function signature( array $sources ): string {
		$parts = array( 'v' . self::ALGO_VERSION );
		foreach ( $sources as $source ) {
			$parts[] = $source['label'] . '|' . $source['id'] . '|' . $source['path'] . '|' . (int) @filemtime( $source['path'] ) . '|' . (int) @filesize( $source['path'] ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}

		return md5( implode( "\n", $parts ) );
	}

	// ------------------------------------------------------------------
	// Pure analysis (no WordPress dependency; unit-testable on its own).
	// ------------------------------------------------------------------

	/**
	 * Analyzes an image file on disk.
	 *
	 * @return array|null array( 'hex', 'chromatic', 'share' ) or null.
	 */
	public static function analyze_file( $path ) {
		try {
			if ( ! is_string( $path ) || ! is_file( $path ) || ! is_readable( $path ) ) {
				return null;
			}
			$size = (int) filesize( $path );
			if ( $size <= 0 ) {
				return null;
			}

			if ( 'svg' === strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) ) {
				if ( $size > self::MAX_SVG_BYTES ) {
					return null;
				}
				$data = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local file, size-capped.
				return is_string( $data ) ? self::analyze_svg( $data ) : null;
			}

			if ( $size > self::MAX_RASTER_BYTES ) {
				return null;
			}
			$data = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local file, size-capped.
			return is_string( $data ) ? self::analyze_raster_data( $data ) : null;
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	/**
	 * Analyzes raster image bytes (PNG, JPEG, GIF, WebP, AVIF, BMP).
	 */
	public static function analyze_raster_data( $data ) {
		if ( ! is_string( $data ) || ! function_exists( 'imagecreatefromstring' ) || ! function_exists( 'getimagesizefromstring' ) ) {
			return null;
		}

		$info = @getimagesizefromstring( $data ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		if ( ! $info || empty( $info[0] ) || empty( $info[1] ) ) {
			return null;
		}
		$w = (int) $info[0];
		$h = (int) $info[1];
		if ( $w * $h > self::MAX_RASTER_PIXELS ) {
			return null;
		}

		$img = @imagecreatefromstring( $data ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		if ( ! $img ) {
			return null;
		}
		if ( ! imageistruecolor( $img ) && function_exists( 'imagepalettetotruecolor' ) ) {
			imagepalettetotruecolor( $img );
		}

		// Even grid over the original pixels: unbiased area estimate, no resampling blur.
		$step = max( 1, (int) ceil( max( $w, $h ) / self::SAMPLE_GRID ) );
		$off  = (int) floor( $step / 2 );
		$hist = array();
		for ( $y = $off; $y < $h; $y += $step ) {
			for ( $x = $off; $x < $w; $x += $step ) {
				$c     = imagecolorat( $img, $x, $y );
				$alpha = ( $c >> 24 ) & 0x7F;
				if ( $alpha >= 80 ) {
					continue; // (mostly) transparent.
				}
				$key = $c & 0xFFFFFF;
				$wt  = 1.0 - ( $alpha / 127 );
				if ( isset( $hist[ $key ] ) ) {
					$hist[ $key ] += $wt;
				} else {
					$hist[ $key ] = $wt;
				}
			}
		}
		imagedestroy( $img );

		return self::analyze_histogram( $hist, 6.0 );
	}

	/**
	 * Core decision: from a histogram of colors (packed 0xRRGGBB => weight) to the
	 * brand color.
	 *
	 * @param array[int]float $hist       Weight (area / pixel count) per packed color.
	 * @param float           $min_weight Minimum total colored weight (noise guard for rasters).
	 * @return array|null array( 'hex' => '#rrggbb', 'chromatic' => bool, 'share' => float ).
	 */
	public static function analyze_histogram( array $hist, $min_weight = 0.0 ) {
		$ink   = 0.0;
		$color = 0.0;
		$cells = array();
		$dark  = array( 0.0, 0.0, 0.0, 0.0 );

		foreach ( $hist as $key => $wt ) {
			if ( $wt <= 0 ) {
				continue;
			}
			$r   = ( $key >> 16 ) & 255;
			$g   = ( $key >> 8 ) & 255;
			$b   = $key & 255;
			$max = max( $r, $g, $b );
			$min = min( $r, $g, $b );
			$d   = $max - $min;
			$v   = $max / 255;
			$s   = $max > 0 ? $d / $max : 0.0;

			// Paper: white / very light grey is background, not ink.
			if ( $v > 0.88 && $s < 0.12 ) {
				continue;
			}
			$ink += $wt;

			// Achromatic fallback color favors the darkest (core) ink.
			$aw       = $wt * pow( 1.05 - $v, 2 );
			$dark[0] += $r * $aw;
			$dark[1] += $g * $aw;
			$dark[2] += $b * $aw;
			$dark[3] += $aw;

			if ( $s >= self::MIN_SATURATION && $v >= self::MIN_VALUE && $d >= self::MIN_CHROMA ) {
				if ( $max === $r ) {
					$hue = fmod( ( $g - $b ) / $d, 6.0 );
				} elseif ( $max === $g ) {
					$hue = ( ( $b - $r ) / $d ) + 2.0;
				} else {
					$hue = ( ( $r - $g ) / $d ) + 4.0;
				}
				$hue *= 60.0;
				if ( $hue < 0 ) {
					$hue += 360.0;
				}
				$cells[] = array( $r, $g, $b, $wt, $hue, $s );
				$color  += $wt;
			}
		}

		if ( $ink <= 0 ) {
			return null;
		}

		$share = $color / $ink;
		if ( empty( $cells ) || $share < self::MIN_COLOR_SHARE || $color < $min_weight ) {
			if ( $dark[3] <= 0 ) {
				return null;
			}
			return array(
				'hex'       => self::to_hex( $dark[0] / $dark[3], $dark[1] / $dark[3], $dark[2] / $dark[3] ),
				'chromatic' => false,
				'share'     => round( $share, 4 ),
			);
		}

		// 1) Find the dominant hue family: 72 bins of 5 degrees, +-3 bins window.
		$bins = array_fill( 0, 72, 0.0 );
		foreach ( $cells as $c ) {
			$bins[ (int) floor( $c[4] / 5.0 ) % 72 ] += $c[3] * $c[5];
		}
		$best_i = 0;
		$best_w = -1.0;
		for ( $i = 0; $i < 72; $i++ ) {
			$sum = 0.0;
			for ( $k = -3; $k <= 3; $k++ ) {
				$sum += $bins[ ( $i + $k + 72 ) % 72 ];
			}
			if ( $sum > $best_w + 1e-9 ) {
				$best_w = $sum;
				$best_i = $i;
			}
		}

		// Refine the family center with a circular weighted mean over the window.
		$sx = 0.0;
		$sy = 0.0;
		foreach ( $cells as $c ) {
			$bin = (int) floor( $c[4] / 5.0 ) % 72;
			// Window membership by circular bin distance.
			$circ = min( abs( $bin - $best_i ), 72 - abs( $bin - $best_i ) );
			if ( $circ > 3 ) {
				continue;
			}
			$rad = deg2rad( $c[4] );
			$wgt = $c[3] * $c[5];
			$sx += cos( $rad ) * $wgt;
			$sy += sin( $rad ) * $wgt;
		}
		$center = rad2deg( atan2( $sy, $sx ) );
		if ( $center < 0 ) {
			$center += 360.0;
		}

		// 2) Collect the family and pick its color.
		$family = array();
		$fam_w  = 0.0;
		foreach ( $cells as $c ) {
			$diff = abs( $c[4] - $center );
			$diff = min( $diff, 360.0 - $diff );
			if ( $diff <= self::HUE_RADIUS ) {
				$family[] = $c;
				$fam_w   += $c[3] * $c[5];
			}
		}
		if ( empty( $family ) || $fam_w <= 0 ) {
			return null;
		}

		// Group by 4-bit-per-channel cell; a dominant cell means a flat brand color.
		$cell_w = array();
		foreach ( $family as $idx => $c ) {
			$ck = ( ( $c[0] >> 4 ) << 8 ) | ( ( $c[1] >> 4 ) << 4 ) | ( $c[2] >> 4 );
			if ( ! isset( $cell_w[ $ck ] ) ) {
				$cell_w[ $ck ] = 0.0;
			}
			$cell_w[ $ck ] += $c[3] * $c[5];
		}
		arsort( $cell_w );
		reset( $cell_w );
		$top_key = key( $cell_w );
		$top_w   = current( $cell_w );

		$members = array();
		if ( $top_w / $fam_w >= 0.35 ) {
			foreach ( $family as $c ) {
				$ck = ( ( $c[0] >> 4 ) << 8 ) | ( ( $c[1] >> 4 ) << 4 ) | ( $c[2] >> 4 );
				if ( $ck === $top_key ) {
					$members[] = $c;
				}
			}
		} else {
			$members = $family; // gradient / photographic logo: blend the family.
		}

		// Exact color wins when it clearly dominates its cell (flat logo colors stay exact).
		$exact   = array();
		$mem_sum = 0.0;
		foreach ( $members as $c ) {
			$ek = ( $c[0] << 16 ) | ( $c[1] << 8 ) | $c[2];
			if ( ! isset( $exact[ $ek ] ) ) {
				$exact[ $ek ] = 0.0;
			}
			$exact[ $ek ] += $c[3];
			$mem_sum      += $c[3];
		}
		arsort( $exact );
		reset( $exact );
		$ex_key = key( $exact );
		$ex_w   = current( $exact );
		if ( $mem_sum > 0 && $ex_w / $mem_sum >= 0.6 ) {
			$hex = sprintf( '#%06x', $ex_key );
		} else {
			$mr = 0.0;
			$mg = 0.0;
			$mb = 0.0;
			$mw = 0.0;
			foreach ( $members as $c ) {
				$pw  = $c[3] * pow( $c[5], 3 );
				$mr += $c[0] * $pw;
				$mg += $c[1] * $pw;
				$mb += $c[2] * $pw;
				$mw += $pw;
			}
			$hex = self::to_hex( $mr / $mw, $mg / $mw, $mb / $mw );
		}

		return array(
			'hex'       => $hex,
			'chromatic' => true,
			'share'     => round( $share, 4 ),
		);
	}

	private static function to_hex( $r, $g, $b ): string {
		return sprintf(
			'#%02x%02x%02x',
			max( 0, min( 255, (int) round( $r ) ) ),
			max( 0, min( 255, (int) round( $g ) ) ),
			max( 0, min( 255, (int) round( $b ) ) )
		);
	}

	// ------------------------------------------------------------------
	// SVG
	// ------------------------------------------------------------------

	/**
	 * Analyzes SVG source text. Treated purely as text: nothing is executed,
	 * fetched, or parsed by an XML engine.
	 */
	public static function analyze_svg( $svg ) {
		try {
			return self::analyze_svg_inner( $svg );
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	private static function analyze_svg_inner( $svg ) {
		if ( ! is_string( $svg ) || false === stripos( $svg, '<svg' ) ) {
			return null;
		}

		$svg = preg_replace( '~<!--.*?-->~s', '', $svg );
		$svg = is_string( $svg ) ? preg_replace( '~<script\b.*?</script>~is', '', $svg ) : null;
		$svg = is_string( $svg ) ? preg_replace( '~<!\[CDATA\[(.*?)\]\]>~s', '$1', $svg ) : null;
		if ( ! is_string( $svg ) ) {
			return null;
		}

		// ---- CSS rules and variables ----
		$css  = array();
		$vars = array();
		if ( preg_match_all( '~<style\b[^>]*>(.*?)</style>~is', $svg, $styles ) ) {
			foreach ( $styles[1] as $sheet ) {
				$sheet = preg_replace( '~/\*.*?\*/~s', '', $sheet );
				if ( ! is_string( $sheet ) || ! preg_match_all( '~([^{}@]+)\{([^{}]*)\}~', $sheet, $rules, PREG_SET_ORDER ) ) {
					continue;
				}
				foreach ( $rules as $rule ) {
					$decl = self::parse_declarations( $rule[2] );
					foreach ( $decl as $prop => $val ) {
						if ( 0 === strpos( $prop, '--' ) ) {
							$vars[ $prop ] = $val;
						}
					}
					foreach ( explode( ',', $rule[1] ) as $selector ) {
						$parts = preg_split( '#[\s>+~]+#', trim( $selector ), -1, PREG_SPLIT_NO_EMPTY );
						if ( empty( $parts ) ) {
							continue;
						}
						$last = end( $parts );
						$key  = null;
						if ( preg_match( '~^(?:[a-zA-Z][\w-]*)?\.([\w-]+)$~', $last, $sm ) ) {
							$key = '.' . $sm[1];
						} elseif ( preg_match( '~^#([\w-]+)$~', $last, $sm ) ) {
							$key = '#' . $sm[1];
						} elseif ( preg_match( '~^[a-zA-Z][\w-]*$~', $last ) ) {
							$key = strtolower( $last );
						}
						if ( null === $key ) {
							continue;
						}
						if ( ! isset( $css[ $key ] ) ) {
							$css[ $key ] = array();
						}
						$css[ $key ] = array_merge( $css[ $key ], $decl );
					}
				}
			}
		}

		// ---- Gradients (average of their stops) ----
		$grads = array();
		if ( preg_match_all( '~<(linearGradient|radialGradient)\b((?:[^>"\'/]++|"[^"]*+"|\'[^\']*+\'|/(?!>))*+)(?:/>|>(.*?)</\1\s*>)~is', $svg, $gm, PREG_SET_ORDER ) ) {
			foreach ( $gm as $g ) {
				$attrs = self::parse_attrs( rtrim( $g[2], '/ ' ) );
				if ( empty( $attrs['id'] ) ) {
					continue;
				}
				$stops = array();
				if ( isset( $g[3] ) && preg_match_all( '~<stop\b((?:[^>"\']++|"[^"]*+"|\'[^\']*+\')*+)>~i', $g[3], $stm ) ) {
					foreach ( $stm[1] as $stop_attr ) {
						$sa = self::parse_attrs( rtrim( $stop_attr, '/ ' ) );
						$p  = array();
						if ( isset( $sa['stop-color'] ) ) {
							$p['stop-color'] = $sa['stop-color'];
						}
						if ( isset( $sa['stop-opacity'] ) ) {
							$p['stop-opacity'] = $sa['stop-opacity'];
						}
						if ( ! empty( $sa['class'] ) ) {
							foreach ( preg_split( '~\s+~', trim( $sa['class'] ) ) as $cl ) {
								if ( isset( $css[ '.' . $cl ] ) ) {
									$p = array_merge( $p, $css[ '.' . $cl ] );
								}
							}
						}
						if ( ! empty( $sa['style'] ) ) {
							$p = array_merge( $p, self::parse_declarations( $sa['style'] ) );
						}
						$col = isset( $p['stop-color'] ) ? self::parse_color( self::resolve_vars( $p['stop-color'], $vars ) ) : array( 0, 0, 0, 1.0 );
						$op  = isset( $p['stop-opacity'] ) ? max( 0.0, min( 1.0, (float) $p['stop-opacity'] ) ) : 1.0;
						if ( $col && $col[3] * $op >= 0.1 ) {
							$stops[] = $col;
						}
					}
				}
				$href = '';
				if ( isset( $attrs['xlink:href'] ) ) {
					$href = ltrim( $attrs['xlink:href'], '#' );
				} elseif ( isset( $attrs['href'] ) ) {
					$href = ltrim( $attrs['href'], '#' );
				}
				$grads[ $attrs['id'] ] = array(
					'stops' => $stops,
					'href'  => $href,
				);
			}
		}
		$gradient_color = array();
		foreach ( array_keys( $grads ) as $gid ) {
			$cur = $gid;
			for ( $depth = 0; $depth < 4 && isset( $grads[ $cur ] ); $depth++ ) {
				if ( ! empty( $grads[ $cur ]['stops'] ) ) {
					$n  = count( $grads[ $cur ]['stops'] );
					$sr = 0;
					$sg = 0;
					$sb = 0;
					foreach ( $grads[ $cur ]['stops'] as $st ) {
						$sr += $st[0];
						$sg += $st[1];
						$sb += $st[2];
					}
					$gradient_color[ $gid ] = array( (int) round( $sr / $n ), (int) round( $sg / $n ), (int) round( $sb / $n ), 1.0 );
					break;
				}
				$cur = $grads[ $cur ]['href'];
			}
		}

		// ---- Tags ----
		if ( ! preg_match_all( '~<(/?)([a-zA-Z][\w:.-]*)((?:[^>"\']++|"[^"]*+"|\'[^\']*+\')*+)>~', $svg, $tags, PREG_SET_ORDER ) ) {
			return null;
		}

		// Viewport: viewBox, else width/height, else the drawing's own extent.
		$view = null;
		$vb   = array( 100.0, 100.0 ); // reference size for % lengths.
		foreach ( $tags as $t ) {
			if ( '' === $t[1] && 'svg' === self::local_name( $t[2] ) ) {
				$ra = self::parse_attrs( $t[3] );
				if ( isset( $ra['viewBox'] ) && preg_match_all( '~[-+]?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?~i', $ra['viewBox'], $vbm ) && count( $vbm[0] ) >= 4 && (float) $vbm[0][2] > 0 && (float) $vbm[0][3] > 0 ) {
					$view = array( (float) $vbm[0][0], (float) $vbm[0][1], (float) $vbm[0][2], (float) $vbm[0][3] );
				} elseif ( isset( $ra['width'], $ra['height'] ) ) {
					$rw = self::parse_len( $ra['width'], 100.0 );
					$rh = self::parse_len( $ra['height'], 100.0 );
					if ( null !== $rw && null !== $rh && $rw > 0 && $rh > 0 && false === strpos( $ra['width'] . $ra['height'], '%' ) ) {
						$view = array( 0.0, 0.0, $rw, $rh );
					}
				}
				if ( $view ) {
					$vb = array( $view[2], $view[3] );
				}
				break;
			}
		}

		// Index of shapes by id, so <use> can paint them.
		$by_id = array();
		foreach ( $tags as $t ) {
			if ( '' !== $t[1] ) {
				continue;
			}
			$name = self::local_name( $t[2] );
			if ( ! in_array( $name, array( 'path', 'rect', 'circle', 'ellipse', 'polygon', 'polyline', 'line' ), true ) ) {
				continue;
			}
			$a = self::parse_attrs( $t[3] );
			if ( ! empty( $a['id'] ) ) {
				$by_id[ $a['id'] ] = array( $name, $a );
			}
		}

		$skip_names  = array( 'defs', 'clippath', 'mask', 'symbol', 'pattern', 'marker', 'lineargradient', 'radialgradient', 'filter', 'style', 'title', 'desc', 'metadata', 'foreignobject', 'script' );
		$shape_names = array( 'path', 'rect', 'circle', 'ellipse', 'polygon', 'polyline', 'line' );

		$root = array(
			'fill'      => array( 0, 0, 0, 1.0 ),
			'stroke'    => false,
			'fill_op'   => 1.0,
			'stroke_op' => 1.0,
			'op'        => 1.0,
			'sw'        => 1.0,
			'color'     => array( 0, 0, 0, 1.0 ),
			'm'         => array( 1.0, 0.0, 0.0, 1.0, 0.0, 0.0 ),
			'rule'      => 'nonzero',
			'visible'   => true,
			'skip'      => false,
		);
		$stack  = array( $root );
		$cmds   = array();
		$budget = array(
			'shapes' => 0,
			'points' => 0,
			'abort'  => false,
		);

		foreach ( $tags as $t ) {
			$name = self::local_name( $t[2] );
			if ( '' !== $t[1] ) { // closing tag.
				if ( count( $stack ) > 1 ) {
					array_pop( $stack );
				}
				continue;
			}

			$astr = $t[3];
			$self = '/' === substr( rtrim( $astr ), -1 );
			if ( $self ) {
				$astr = substr( rtrim( $astr ), 0, -1 );
			}
			$attrs  = self::parse_attrs( $astr );
			$parent = $stack[ count( $stack ) - 1 ];
			$ctx    = self::resolve_ctx( $parent, $name, $attrs, $css, $vars, $gradient_color, $vb );
			if ( $parent['skip'] || in_array( $name, $skip_names, true ) ) {
				$ctx['skip'] = true;
			}

			if ( ! $ctx['skip'] ) {
				if ( in_array( $name, $shape_names, true ) ) {
					self::emit( $cmds, $budget, $name, $attrs, $ctx, $vb );
				} elseif ( 'use' === $name ) {
					$ref = '';
					if ( isset( $attrs['xlink:href'] ) ) {
						$ref = ltrim( $attrs['xlink:href'], '#' );
					} elseif ( isset( $attrs['href'] ) ) {
						$ref = ltrim( $attrs['href'], '#' );
					}
					if ( '' !== $ref && isset( $by_id[ $ref ] ) ) {
						$ux = isset( $attrs['x'] ) ? self::parse_len( $attrs['x'], $vb[0] ) : 0.0;
						$uy = isset( $attrs['y'] ) ? self::parse_len( $attrs['y'], $vb[1] ) : 0.0;
						$uc = $ctx;
						$uc['m'] = self::mat_mul( $ctx['m'], array( 1.0, 0.0, 0.0, 1.0, (float) $ux, (float) $uy ) );
						$rctx    = self::resolve_ctx( $uc, $by_id[ $ref ][0], $by_id[ $ref ][1], $css, $vars, $gradient_color, $vb );
						self::emit( $cmds, $budget, $by_id[ $ref ][0], $by_id[ $ref ][1], $rctx, $vb );
					}
				}
			}
			if ( $budget['abort'] ) {
				return null;
			}

			if ( ! $self ) {
				$stack[] = $ctx;
			}
		}

		if ( empty( $cmds ) ) {
			// Some "SVG" logos just wrap an embedded bitmap.
			if ( preg_match( '~data:image/(?:png|jpe?g|webp|gif);base64,([A-Za-z0-9+/=\s]+)~i', $svg, $dm ) && strlen( $dm[1] ) < 4 * self::MAX_RASTER_BYTES / 3 ) {
				$bin = base64_decode( preg_replace( '~\s+~', '', $dm[1] ), true );
				if ( is_string( $bin ) ) {
					return self::analyze_raster_data( $bin );
				}
			}
			return null;
		}

		$hist = self::rasterize( $cmds, $view );

		return $hist ? self::analyze_histogram( $hist, 3.0 ) : null;
	}

	private static function local_name( $tag ): string {
		$tag = strtolower( $tag );
		$pos = strrpos( $tag, ':' );

		return false === $pos ? $tag : substr( $tag, $pos + 1 );
	}

	/**
	 * Computes the inherited paint state for an element.
	 */
	private static function resolve_ctx( array $parent, $name, array $attrs, array $css, array $vars, array $gradients, array $vb ): array {
		$p = array();
		foreach ( self::CSS_PROPS as $n ) {
			if ( isset( $attrs[ $n ] ) ) {
				$p[ $n ] = $attrs[ $n ];
			}
		}
		if ( isset( $css[ $name ] ) ) {
			$p = array_merge( $p, $css[ $name ] );
		}
		if ( ! empty( $attrs['class'] ) ) {
			foreach ( preg_split( '~\s+~', trim( $attrs['class'] ) ) as $cl ) {
				if ( isset( $css[ '.' . $cl ] ) ) {
					$p = array_merge( $p, $css[ '.' . $cl ] );
				}
			}
		}
		if ( ! empty( $attrs['id'] ) && isset( $css[ '#' . $attrs['id'] ] ) ) {
			$p = array_merge( $p, $css[ '#' . $attrs['id'] ] );
		}
		if ( ! empty( $attrs['style'] ) ) {
			$p = array_merge( $p, self::parse_declarations( $attrs['style'] ) );
		}

		$ctx = $parent;

		if ( isset( $p['display'] ) && 'none' === strtolower( trim( $p['display'] ) ) ) {
			$ctx['skip'] = true;
		}
		if ( isset( $p['visibility'] ) ) {
			$vis = strtolower( trim( $p['visibility'] ) );
			if ( 'hidden' === $vis || 'collapse' === $vis ) {
				$ctx['visible'] = false;
			} elseif ( 'visible' === $vis ) {
				$ctx['visible'] = true;
			}
		}
		if ( isset( $p['fill-rule'] ) ) {
			$ctx['rule'] = ( 'evenodd' === strtolower( trim( $p['fill-rule'] ) ) ) ? 'evenodd' : 'nonzero';
		}
		if ( isset( $p['color'] ) ) {
			$c = self::parse_color( self::resolve_vars( $p['color'], $vars ) );
			if ( $c ) {
				$ctx['color'] = $c;
			}
		}
		if ( isset( $p['fill'] ) ) {
			$paint = self::parse_paint( self::resolve_vars( $p['fill'], $vars ), $ctx['color'], $gradients );
			if ( null !== $paint ) {
				$ctx['fill'] = $paint;
			}
		}
		if ( isset( $p['stroke'] ) ) {
			$paint = self::parse_paint( self::resolve_vars( $p['stroke'], $vars ), $ctx['color'], $gradients );
			if ( null !== $paint ) {
				$ctx['stroke'] = $paint;
			}
		}
		if ( isset( $p['fill-opacity'] ) && is_numeric( self::strip_pct( $p['fill-opacity'] ) ) ) {
			$ctx['fill_op'] = max( 0.0, min( 1.0, (float) self::strip_pct( $p['fill-opacity'] ) ) );
		}
		if ( isset( $p['stroke-opacity'] ) && is_numeric( self::strip_pct( $p['stroke-opacity'] ) ) ) {
			$ctx['stroke_op'] = max( 0.0, min( 1.0, (float) self::strip_pct( $p['stroke-opacity'] ) ) );
		}
		if ( isset( $p['opacity'] ) && is_numeric( self::strip_pct( $p['opacity'] ) ) ) {
			$ctx['op'] = $parent['op'] * max( 0.0, min( 1.0, (float) self::strip_pct( $p['opacity'] ) ) );
		}
		if ( isset( $p['stroke-width'] ) ) {
			$len = self::parse_len( $p['stroke-width'], sqrt( ( $vb[0] * $vb[0] + $vb[1] * $vb[1] ) / 2 ) );
			if ( null !== $len && $len >= 0 ) {
				$ctx['sw'] = $len;
			}
		}
		if ( ! empty( $attrs['transform'] ) ) {
			$ctx['m'] = self::mat_mul( $parent['m'], self::parse_transform( $attrs['transform'] ) );
		}

		return $ctx;
	}

	/**
	 * "50%" or "0.5" => 0.5.
	 */
	private static function strip_pct( $v ) {
		$v = trim( (string) $v );
		if ( '' !== $v && '%' === substr( $v, -1 ) && is_numeric( substr( $v, 0, -1 ) ) ) {
			return (float) substr( $v, 0, -1 ) / 100;
		}

		return $v;
	}

	/**
	 * a x b for SVG affine matrices [a b c d e f] (b is applied first).
	 */
	private static function mat_mul( array $a, array $b ): array {
		return array(
			$a[0] * $b[0] + $a[2] * $b[1],
			$a[1] * $b[0] + $a[3] * $b[1],
			$a[0] * $b[2] + $a[2] * $b[3],
			$a[1] * $b[2] + $a[3] * $b[3],
			$a[0] * $b[4] + $a[2] * $b[5] + $a[4],
			$a[1] * $b[4] + $a[3] * $b[5] + $a[5],
		);
	}

	/**
	 * Parses an SVG transform list (translate, scale, rotate, skewX/Y, matrix).
	 */
	private static function parse_transform( $transform ): array {
		$m = array( 1.0, 0.0, 0.0, 1.0, 0.0, 0.0 );
		if ( ! preg_match_all( '~([a-zA-Z]+)\s*\(([^)]*)\)~', (string) $transform, $found, PREG_SET_ORDER ) ) {
			return $m;
		}
		foreach ( $found as $tr ) {
			preg_match_all( '~[-+]?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?~i', $tr[2], $nums );
			$n = array_map( 'floatval', $nums[0] );
			$c = count( $n );
			$t = null;
			switch ( $tr[1] ) {
				case 'translate':
					if ( $c >= 1 ) {
						$t = array( 1.0, 0.0, 0.0, 1.0, $n[0], $c >= 2 ? $n[1] : 0.0 );
					}
					break;
				case 'scale':
					if ( $c >= 1 ) {
						$t = array( $n[0], 0.0, 0.0, $c >= 2 ? $n[1] : $n[0], 0.0, 0.0 );
					}
					break;
				case 'rotate':
					if ( $c >= 1 ) {
						$r  = deg2rad( $n[0] );
						$t  = array( cos( $r ), sin( $r ), -sin( $r ), cos( $r ), 0.0, 0.0 );
						if ( $c >= 3 ) {
							$t = self::mat_mul( array( 1.0, 0.0, 0.0, 1.0, $n[1], $n[2] ), self::mat_mul( $t, array( 1.0, 0.0, 0.0, 1.0, -$n[1], -$n[2] ) ) );
						}
					}
					break;
				case 'skewX':
					if ( $c >= 1 ) {
						$t = array( 1.0, 0.0, tan( deg2rad( $n[0] ) ), 1.0, 0.0, 0.0 );
					}
					break;
				case 'skewY':
					if ( $c >= 1 ) {
						$t = array( 1.0, tan( deg2rad( $n[0] ) ), 0.0, 1.0, 0.0, 0.0 );
					}
					break;
				case 'matrix':
					if ( $c >= 6 ) {
						$t = array( $n[0], $n[1], $n[2], $n[3], $n[4], $n[5] );
					}
					break;
			}
			if ( $t ) {
				$m = self::mat_mul( $m, $t );
			}
		}

		return $m;
	}

	/**
	 * Parses a paint value.
	 *
	 * @return array|false|null array(r,g,b,a) color, false for "none", null when it should be inherited / is unknown.
	 */
	private static function parse_paint( $value, array $current, array $gradients ) {
		$v = trim( (string) $value );
		$l = strtolower( $v );
		if ( '' === $l || 'inherit' === $l ) {
			return null;
		}
		if ( 'none' === $l || 'transparent' === $l ) {
			return false;
		}
		if ( 'currentcolor' === $l ) {
			return $current;
		}
		if ( preg_match( '~^url\(\s*[\'"]?#([^\'")\s]+)[\'"]?\s*\)\s*(.*)$~i', $v, $m ) ) {
			if ( isset( $gradients[ $m[1] ] ) ) {
				return $gradients[ $m[1] ];
			}
			$fallback = self::parse_color( $m[2] );

			return $fallback ? $fallback : false; // pattern fills have no single color.
		}
		$c = self::parse_color( $v );

		return $c ? $c : null;
	}

	/**
	 * Turns a shape into a drawing command (outline in root coordinates + paint).
	 */
	private static function emit( array &$cmds, array &$budget, $name, array $attrs, array $ctx, array $vb ) {
		if ( ! $ctx['visible'] ) {
			return;
		}

		$fill = false;
		if ( $ctx['fill'] && 'line' !== $name ) {
			$fa = $ctx['fill'][3] * $ctx['fill_op'] * $ctx['op'];
			if ( $fa >= 0.02 ) {
				$fill = array( $ctx['fill'][0], $ctx['fill'][1], $ctx['fill'][2], min( 1.0, $fa ) );
			}
		}
		$stroke = false;
		$m      = $ctx['m'];
		$sw     = $ctx['sw'] * sqrt( abs( $m[0] * $m[3] - $m[1] * $m[2] ) );
		if ( $ctx['stroke'] && $sw > 0 ) {
			$sa = $ctx['stroke'][3] * $ctx['stroke_op'] * $ctx['op'];
			if ( $sa >= 0.02 ) {
				$stroke = array( $ctx['stroke'][0], $ctx['stroke'][1], $ctx['stroke'][2], min( 1.0, $sa ) );
			}
		}
		if ( ! $fill && ! $stroke ) {
			return;
		}

		if ( ++$budget['shapes'] > self::MAX_SHAPES ) {
			$budget['abort'] = true;
			return;
		}

		$polys = self::shape_polys( $name, $attrs, $vb, $budget );
		if ( ! $polys ) {
			return;
		}

		$out = array();
		foreach ( $polys as $poly ) {
			$pts = array();
			foreach ( $poly['pts'] as $p ) {
				$x = $m[0] * $p[0] + $m[2] * $p[1] + $m[4];
				$y = $m[1] * $p[0] + $m[3] * $p[1] + $m[5];
				if ( is_nan( $x ) || is_nan( $y ) || is_infinite( $x ) || is_infinite( $y ) ) {
					continue;
				}
				$pts[] = array( $x, $y );
			}
			if ( count( $pts ) >= 2 ) {
				$out[] = array(
					'pts'    => $pts,
					'closed' => $poly['closed'],
				);
			}
		}
		if ( empty( $out ) ) {
			return;
		}

		$cmds[] = array(
			'polys'  => $out,
			'fill'   => $fill,
			'stroke' => $stroke,
			'sw'     => $sw,
			'eo'     => 'evenodd' === $ctx['rule'],
		);
	}

	/**
	 * Outline polylines of a basic shape or path, in the shape's own coordinates.
	 *
	 * @return array[]|null Each: array( 'pts' => array( [x,y], ... ), 'closed' => bool ).
	 */
	private static function shape_polys( $name, array $a, array $vb, array &$budget ) {
		$diag = sqrt( ( $vb[0] * $vb[0] + $vb[1] * $vb[1] ) / 2 );
		$num  = function ( $key, $ref ) use ( $a ) {
			if ( ! isset( $a[ $key ] ) ) {
				return 0.0;
			}
			$v = self::parse_len( $a[ $key ], $ref );

			return null === $v ? 0.0 : $v;
		};

		switch ( $name ) {
			case 'rect':
				$x = $num( 'x', $vb[0] );
				$y = $num( 'y', $vb[1] );
				$w = $num( 'width', $vb[0] );
				$h = $num( 'height', $vb[1] );
				if ( $w <= 0 || $h <= 0 ) {
					return null;
				}
				$budget['points'] += 4;
				return array(
					array(
						'pts'    => array( array( $x, $y ), array( $x + $w, $y ), array( $x + $w, $y + $h ), array( $x, $y + $h ) ),
						'closed' => true,
					),
				);

			case 'circle':
				$r = $num( 'r', $diag );
				if ( $r <= 0 ) {
					return null;
				}
				return self::ellipse_poly( $num( 'cx', $vb[0] ), $num( 'cy', $vb[1] ), $r, $r, $budget );

			case 'ellipse':
				$rx = $num( 'rx', $vb[0] );
				$ry = $num( 'ry', $vb[1] );
				if ( $rx <= 0 || $ry <= 0 ) {
					return null;
				}
				return self::ellipse_poly( $num( 'cx', $vb[0] ), $num( 'cy', $vb[1] ), $rx, $ry, $budget );

			case 'line':
				$budget['points'] += 2;
				return array(
					array(
						'pts'    => array( array( $num( 'x1', $vb[0] ), $num( 'y1', $vb[1] ) ), array( $num( 'x2', $vb[0] ), $num( 'y2', $vb[1] ) ) ),
						'closed' => false,
					),
				);

			case 'polygon':
			case 'polyline':
				if ( empty( $a['points'] ) || ! preg_match_all( '~[-+]?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?~i', $a['points'], $nm ) ) {
					return null;
				}
				$nums = $nm[0];
				$pts  = array();
				for ( $i = 0; $i + 1 < count( $nums ); $i += 2 ) {
					$pts[] = array( (float) $nums[ $i ], (float) $nums[ $i + 1 ] );
				}
				if ( count( $pts ) < 2 ) {
					return null;
				}
				$budget['points'] += count( $pts );
				if ( $budget['points'] > self::MAX_POINTS ) {
					$budget['abort'] = true;
					return null;
				}
				return array(
					array(
						'pts'    => $pts,
						'closed' => 'polygon' === $name,
					),
				);

			case 'path':
				return empty( $a['d'] ) ? null : self::path_polys( $a['d'], $budget );
		}

		return null;
	}

	private static function ellipse_poly( $cx, $cy, $rx, $ry, array &$budget ): array {
		$pts = array();
		for ( $i = 0; $i < 64; $i++ ) {
			$t     = 2 * M_PI * $i / 64;
			$pts[] = array( $cx + $rx * cos( $t ), $cy + $ry * sin( $t ) );
		}
		$budget['points'] += 64;

		return array(
			array(
				'pts'    => $pts,
				'closed' => true,
			),
		);
	}

	/**
	 * Flattens an SVG path (lines, cubic / quadratic curves, arcs) into polylines.
	 *
	 * @return array[]|null
	 */
	private static function path_polys( $d, array &$budget ) {
		$d   = (string) $d;
		$len = strlen( $d );
		if ( $len > 400000 ) {
			$budget['abort'] = true;
			return null;
		}
		$i     = 0;
		$cmd   = '';
		$cx    = 0.0;
		$cy    = 0.0;
		$sx    = 0.0;
		$sy    = 0.0;
		$lcx   = 0.0; // last cubic control point.
		$lcy   = 0.0;
		$lqx   = 0.0; // last quadratic control point.
		$lqy   = 0.0;
		$prev  = '';
		$sub   = array();
		$polys = array();
		$guard = 0;

		while ( $i < $len ) {
			if ( ++$guard > 300000 || $budget['points'] > self::MAX_POINTS ) {
				$budget['abort'] = $budget['points'] > self::MAX_POINTS;
				break;
			}
			$ch = $d[ $i ];
			if ( ' ' === $ch || ',' === $ch || "\t" === $ch || "\n" === $ch || "\r" === $ch ) {
				$i++;
				continue;
			}
			if ( ctype_alpha( $ch ) ) {
				if ( false === strpos( 'MmLlHhVvCcSsQqTtAaZz', $ch ) ) {
					break;
				}
				$cmd = $ch;
				$i++;
				if ( 'Z' === $cmd || 'z' === $cmd ) {
					self::flush_sub( $polys, $sub, true );
					$cx    = $sx;
					$cy    = $sy;
					$prev  = 'Z';
					$sub[] = array( $cx, $cy ); // a following draw command continues from the start point.
				}
				continue;
			}
			if ( '' === $cmd || 'Z' === $cmd || 'z' === $cmd ) {
				break;
			}

			$up  = strtoupper( $cmd );
			$rel = $cmd !== $up;
			$ox  = $rel ? $cx : 0.0;
			$oy  = $rel ? $cy : 0.0;

			switch ( $up ) {
				case 'M':
					$x = self::read_num( $d, $i, $len );
					$y = self::read_num( $d, $i, $len );
					if ( null === $x || null === $y ) {
						break 2;
					}
					self::flush_sub( $polys, $sub, false );
					$cx    = $ox + $x;
					$cy    = $oy + $y;
					$sx    = $cx;
					$sy    = $cy;
					$sub   = array( array( $cx, $cy ) );
					$cmd   = $rel ? 'l' : 'L'; // extra pairs are implicit line-tos.
					$prev  = 'M';
					break;

				case 'L':
				case 'H':
				case 'V':
					if ( 'H' === $up ) {
						$x = self::read_num( $d, $i, $len );
						if ( null === $x ) {
							break 2;
						}
						$nx = $ox + $x;
						$ny = $cy;
					} elseif ( 'V' === $up ) {
						$y = self::read_num( $d, $i, $len );
						if ( null === $y ) {
							break 2;
						}
						$nx = $cx;
						$ny = $oy + $y;
					} else {
						$x = self::read_num( $d, $i, $len );
						$y = self::read_num( $d, $i, $len );
						if ( null === $x || null === $y ) {
							break 2;
						}
						$nx = $ox + $x;
						$ny = $oy + $y;
					}
					$sub[] = array( $nx, $ny );
					$budget['points']++;
					$cx   = $nx;
					$cy   = $ny;
					$prev = 'L';
					break;

				case 'C':
				case 'S':
					if ( 'C' === $up ) {
						$x1 = self::read_num( $d, $i, $len );
						$y1 = self::read_num( $d, $i, $len );
						if ( null === $x1 || null === $y1 ) {
							break 2;
						}
						$x1 += $ox;
						$y1 += $oy;
					} else {
						$x1 = ( 'C' === $prev ) ? 2 * $cx - $lcx : $cx;
						$y1 = ( 'C' === $prev ) ? 2 * $cy - $lcy : $cy;
					}
					$x2 = self::read_num( $d, $i, $len );
					$y2 = self::read_num( $d, $i, $len );
					$x  = self::read_num( $d, $i, $len );
					$y  = self::read_num( $d, $i, $len );
					if ( null === $x2 || null === $y2 || null === $x || null === $y ) {
						break 2;
					}
					$x2 += $ox;
					$y2 += $oy;
					$x  += $ox;
					$y  += $oy;
					for ( $s = 1; $s <= 8; $s++ ) {
						$u  = $s / 8;
						$mt = 1 - $u;
						$sub[] = array(
							$mt * $mt * $mt * $cx + 3 * $mt * $mt * $u * $x1 + 3 * $mt * $u * $u * $x2 + $u * $u * $u * $x,
							$mt * $mt * $mt * $cy + 3 * $mt * $mt * $u * $y1 + 3 * $mt * $u * $u * $y2 + $u * $u * $u * $y,
						);
					}
					$budget['points'] += 8;
					$lcx  = $x2;
					$lcy  = $y2;
					$cx   = $x;
					$cy   = $y;
					$prev = 'C';
					break;

				case 'Q':
				case 'T':
					if ( 'Q' === $up ) {
						$x1 = self::read_num( $d, $i, $len );
						$y1 = self::read_num( $d, $i, $len );
						if ( null === $x1 || null === $y1 ) {
							break 2;
						}
						$x1 += $ox;
						$y1 += $oy;
					} else {
						$x1 = ( 'Q' === $prev ) ? 2 * $cx - $lqx : $cx;
						$y1 = ( 'Q' === $prev ) ? 2 * $cy - $lqy : $cy;
					}
					$x = self::read_num( $d, $i, $len );
					$y = self::read_num( $d, $i, $len );
					if ( null === $x || null === $y ) {
						break 2;
					}
					$x += $ox;
					$y += $oy;
					for ( $s = 1; $s <= 8; $s++ ) {
						$u  = $s / 8;
						$mt = 1 - $u;
						$sub[] = array(
							$mt * $mt * $cx + 2 * $mt * $u * $x1 + $u * $u * $x,
							$mt * $mt * $cy + 2 * $mt * $u * $y1 + $u * $u * $y,
						);
					}
					$budget['points'] += 8;
					$lqx  = $x1;
					$lqy  = $y1;
					$cx   = $x;
					$cy   = $y;
					$prev = 'Q';
					break;

				case 'A':
					$rx  = self::read_num( $d, $i, $len );
					$ry  = self::read_num( $d, $i, $len );
					$rot = self::read_num( $d, $i, $len );
					$fa  = self::read_flag( $d, $i, $len );
					$fs  = self::read_flag( $d, $i, $len );
					$x   = self::read_num( $d, $i, $len );
					$y   = self::read_num( $d, $i, $len );
					if ( null === $rx || null === $ry || null === $rot || null === $fa || null === $fs || null === $x || null === $y ) {
						break 2;
					}
					$x += $ox;
					$y += $oy;
					foreach ( self::arc_points( $cx, $cy, abs( $rx ), abs( $ry ), $rot, $fa, $fs, $x, $y ) as $pt ) {
						$sub[] = $pt;
						$budget['points']++;
					}
					$cx   = $x;
					$cy   = $y;
					$prev = 'A';
					break;

				default:
					break 2;
			}
		}
		self::flush_sub( $polys, $sub, false );

		return $polys;
	}

	private static function flush_sub( array &$polys, array &$sub, $closed ) {
		if ( count( $sub ) >= 2 ) {
			$polys[] = array(
				'pts'    => $sub,
				'closed' => (bool) $closed,
			);
		}
		$sub = array();
	}

	/**
	 * Paints the drawing commands, in document order, onto a coarse canvas and
	 * returns the resulting color histogram (what the logo actually looks like,
	 * with overlaps, white shapes and opacity already resolved).
	 *
	 * @return array|null
	 */
	private static function rasterize( array $cmds, $view ) {
		if ( null === $view ) {
			$minx = INF;
			$miny = INF;
			$maxx = -INF;
			$maxy = -INF;
			foreach ( $cmds as $cmd ) {
				$pad = $cmd['stroke'] ? $cmd['sw'] / 2 : 0.0;
				foreach ( $cmd['polys'] as $poly ) {
					foreach ( $poly['pts'] as $p ) {
						$minx = min( $minx, $p[0] - $pad );
						$maxx = max( $maxx, $p[0] + $pad );
						$miny = min( $miny, $p[1] - $pad );
						$maxy = max( $maxy, $p[1] + $pad );
					}
				}
			}
			if ( ! ( $maxx > $minx ) || ! ( $maxy > $miny ) ) {
				return null;
			}
			$view = array( $minx, $miny, $maxx - $minx, $maxy - $miny );
		}

		$n     = self::GRID;
		$scale = $n / max( $view[2], $view[3] );
		$ox    = ( $n - $view[2] * $scale ) / 2 - $view[0] * $scale;
		$oy    = ( $n - $view[3] * $scale ) / 2 - $view[1] * $scale;
		$zero  = array_fill( 0, $n * $n, 0.0 );
		$cv    = array(
			'r' => $zero,
			'g' => $zero,
			'b' => $zero,
			'a' => $zero,
		);

		$stroke_ops = 0;
		foreach ( $cmds as $cmd ) {
			if ( $cmd['fill'] ) {
				self::composite( $cv, self::fill_cells( $cmd['polys'], $scale, $ox, $oy, $n, $cmd['eo'] ), $cmd['fill'] );
			}
			if ( $cmd['stroke'] && $stroke_ops < 4000000 ) {
				self::composite( $cv, self::stroke_cells( $cmd['polys'], $cmd['sw'], $scale, $ox, $oy, $n, $stroke_ops ), $cmd['stroke'] );
			}
		}

		$hist = array();
		for ( $idx = $n * $n - 1; $idx >= 0; $idx-- ) {
			$a = $cv['a'][ $idx ];
			if ( $a < 0.35 ) {
				continue;
			}
			$key = ( (int) round( $cv['r'][ $idx ] ) << 16 ) | ( (int) round( $cv['g'][ $idx ] ) << 8 ) | (int) round( $cv['b'][ $idx ] );
			if ( isset( $hist[ $key ] ) ) {
				$hist[ $key ] += $a;
			} else {
				$hist[ $key ] = $a;
			}
		}

		return $hist;
	}

	/**
	 * Cells whose centers lie inside the polygons (nonzero or even-odd rule).
	 */
	private static function fill_cells( array $polys, $scale, $ox, $oy, $n, $evenodd ): array {
		$rows = array();
		foreach ( $polys as $poly ) {
			$pts = $poly['pts'];
			$c   = count( $pts );
			if ( $c < 3 ) {
				continue;
			}
			$px = $pts[ $c - 1 ][0] * $scale + $ox;
			$py = $pts[ $c - 1 ][1] * $scale + $oy;
			for ( $i = 0; $i < $c; $i++ ) {
				$qx = $pts[ $i ][0] * $scale + $ox;
				$qy = $pts[ $i ][1] * $scale + $oy;
				if ( $py !== $qy ) {
					if ( $py < $qy ) {
						$y0  = $py;
						$y1  = $qy;
						$dir = 1;
					} else {
						$y0  = $qy;
						$y1  = $py;
						$dir = -1;
					}
					$r0 = (int) max( 0.0, ceil( $y0 - 0.5 ) );
					$r1 = (int) min( $n - 1, ceil( $y1 - 0.5 ) - 1 );
					if ( $r1 >= $r0 ) {
						$k = ( $qx - $px ) / ( $qy - $py );
						for ( $r = $r0; $r <= $r1; $r++ ) {
							$rows[ $r ][] = array( $px + ( $r + 0.5 - $py ) * $k, $dir );
						}
					}
				}
				$px = $qx;
				$py = $qy;
			}
		}

		$cells = array();
		foreach ( $rows as $r => $list ) {
			usort(
				$list,
				function ( $p, $q ) {
					return $p[0] <=> $q[0];
				}
			);
			$w   = 0;
			$cnt = 0;
			$m   = count( $list );
			for ( $i = 0; $i < $m - 1; $i++ ) {
				$w += $list[ $i ][1];
				$cnt++;
				$inside = $evenodd ? ( 1 === ( $cnt & 1 ) ) : ( 0 !== $w );
				if ( $inside ) {
					$a = (int) max( 0.0, ceil( $list[ $i ][0] - 0.5 ) );
					$b = (int) min( $n - 1, ceil( $list[ $i + 1 ][0] - 0.5 ) - 1 );
					for ( $col = $a; $col <= $b; $col++ ) {
						$cells[ $r * $n + $col ] = true;
					}
				}
			}
		}

		return array_keys( $cells );
	}

	/**
	 * Cells within half a stroke width of the outline (round joins and caps).
	 */
	private static function stroke_cells( array $polys, $sw, $scale, $ox, $oy, $n, &$ops ): array {
		$hw    = max( 0.5, $sw * $scale / 2 );
		$hw2   = $hw * $hw;
		$cells = array();

		foreach ( $polys as $poly ) {
			$g = array();
			foreach ( $poly['pts'] as $p ) {
				$g[] = array( $p[0] * $scale + $ox, $p[1] * $scale + $oy );
			}
			$c   = count( $g );
			$seg = $poly['closed'] ? $c : $c - 1;
			for ( $i = 0; $i < $seg; $i++ ) {
				$ax = $g[ $i ][0];
				$ay = $g[ $i ][1];
				$bx = $g[ ( $i + 1 ) % $c ][0];
				$by = $g[ ( $i + 1 ) % $c ][1];

				$x0 = (int) max( 0.0, floor( min( $ax, $bx ) - $hw - 0.5 ) );
				$x1 = (int) min( $n - 1, ceil( max( $ax, $bx ) + $hw - 0.5 ) );
				$y0 = (int) max( 0.0, floor( min( $ay, $by ) - $hw - 0.5 ) );
				$y1 = (int) min( $n - 1, ceil( max( $ay, $by ) + $hw - 0.5 ) );
				$dx = $bx - $ax;
				$dy = $by - $ay;
				$l2 = $dx * $dx + $dy * $dy;

				$ops += ( $x1 - $x0 + 1 ) * ( $y1 - $y0 + 1 );
				if ( $ops > 4000000 ) {
					return array_keys( $cells );
				}
				for ( $y = $y0; $y <= $y1; $y++ ) {
					$py = $y + 0.5;
					for ( $x = $x0; $x <= $x1; $x++ ) {
						$px = $x + 0.5;
						if ( $l2 <= 0 ) {
							$d2 = ( $px - $ax ) * ( $px - $ax ) + ( $py - $ay ) * ( $py - $ay );
						} else {
							$t  = max( 0.0, min( 1.0, ( ( $px - $ax ) * $dx + ( $py - $ay ) * $dy ) / $l2 ) );
							$qx = $ax + $t * $dx - $px;
							$qy = $ay + $t * $dy - $py;
							$d2 = $qx * $qx + $qy * $qy;
						}
						if ( $d2 <= $hw2 ) {
							$cells[ $y * $n + $x ] = true;
						}
					}
				}
			}
		}

		return array_keys( $cells );
	}

	/**
	 * Source-over compositing of one color onto the listed canvas cells.
	 */
	private static function composite( array &$cv, array $cells, array $rgba ) {
		$sa = $rgba[3];
		foreach ( $cells as $idx ) {
			$da = $cv['a'][ $idx ];
			$oa = $sa + $da * ( 1 - $sa );
			if ( $oa <= 0 ) {
				continue;
			}
			$k                = $da * ( 1 - $sa );
			$cv['r'][ $idx ]  = ( $rgba[0] * $sa + $cv['r'][ $idx ] * $k ) / $oa;
			$cv['g'][ $idx ]  = ( $rgba[1] * $sa + $cv['g'][ $idx ] * $k ) / $oa;
			$cv['b'][ $idx ]  = ( $rgba[2] * $sa + $cv['b'][ $idx ] * $k ) / $oa;
			$cv['a'][ $idx ]  = $oa;
		}
	}

	private static function read_num( $s, &$i, $len ) {
		while ( $i < $len && ( ' ' === $s[ $i ] || ',' === $s[ $i ] || "\t" === $s[ $i ] || "\n" === $s[ $i ] || "\r" === $s[ $i ] ) ) {
			$i++;
		}
		if ( $i >= $len ) {
			return null;
		}
		if ( ! preg_match( '~\G[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?~', $s, $m, 0, $i ) ) {
			return null;
		}
		$i += strlen( $m[0] );

		return (float) $m[0];
	}

	/**
	 * Arc flags are single characters and may be glued to the next number.
	 */
	private static function read_flag( $s, &$i, $len ) {
		while ( $i < $len && ( ' ' === $s[ $i ] || ',' === $s[ $i ] || "\t" === $s[ $i ] || "\n" === $s[ $i ] || "\r" === $s[ $i ] ) ) {
			$i++;
		}
		if ( $i >= $len || ( '0' !== $s[ $i ] && '1' !== $s[ $i ] ) ) {
			return null;
		}
		$f = (int) $s[ $i ];
		$i++;

		return $f;
	}

	/**
	 * Samples an SVG elliptical arc (endpoint parameterization, SVG spec F.6.5).
	 *
	 * @return array[] Points after the start point, ending at (x2, y2).
	 */
	private static function arc_points( $x1, $y1, $rx, $ry, $rot, $fa, $fs, $x2, $y2 ): array {
		if ( ( $x1 === $x2 && $y1 === $y2 ) ) {
			return array();
		}
		if ( $rx <= 0 || $ry <= 0 ) {
			return array( array( $x2, $y2 ) );
		}

		$phi = deg2rad( fmod( $rot, 360.0 ) );
		$cp  = cos( $phi );
		$sp  = sin( $phi );
		$dx  = ( $x1 - $x2 ) / 2;
		$dy  = ( $y1 - $y2 ) / 2;
		$x1p = $cp * $dx + $sp * $dy;
		$y1p = -$sp * $dx + $cp * $dy;

		$lam = ( $x1p * $x1p ) / ( $rx * $rx ) + ( $y1p * $y1p ) / ( $ry * $ry );
		if ( $lam > 1 ) {
			$sq  = sqrt( $lam );
			$rx *= $sq;
			$ry *= $sq;
		}

		$num = $rx * $rx * $ry * $ry - $rx * $rx * $y1p * $y1p - $ry * $ry * $x1p * $x1p;
		$den = $rx * $rx * $y1p * $y1p + $ry * $ry * $x1p * $x1p;
		$co  = ( $den > 0 ) ? sqrt( max( 0.0, $num / $den ) ) : 0.0;
		if ( $fa === $fs ) {
			$co = -$co;
		}
		$cxp = $co * $rx * $y1p / $ry;
		$cyp = -$co * $ry * $x1p / $rx;
		$cx  = $cp * $cxp - $sp * $cyp + ( $x1 + $x2 ) / 2;
		$cy  = $sp * $cxp + $cp * $cyp + ( $y1 + $y2 ) / 2;

		$t1 = atan2( ( $y1p - $cyp ) / $ry, ( $x1p - $cxp ) / $rx );
		$t2 = atan2( ( -$y1p - $cyp ) / $ry, ( -$x1p - $cxp ) / $rx );
		$dt = $t2 - $t1;
		if ( 0 === $fs && $dt > 0 ) {
			$dt -= 2 * M_PI;
		} elseif ( 1 === $fs && $dt < 0 ) {
			$dt += 2 * M_PI;
		}

		$n   = max( 6, (int) ceil( abs( $dt ) / ( M_PI / 12 ) ) );
		$out = array();
		for ( $k = 1; $k <= $n; $k++ ) {
			$t     = $t1 + $dt * $k / $n;
			$out[] = array(
				$cx + $rx * cos( $t ) * $cp - $ry * sin( $t ) * $sp,
				$cy + $rx * cos( $t ) * $sp + $ry * sin( $t ) * $cp,
			);
		}
		$out[ count( $out ) - 1 ] = array( $x2, $y2 );

		return $out;
	}

	// ------------------------------------------------------------------
	// Small parsers
	// ------------------------------------------------------------------

	private static function parse_attrs( $s ): array {
		$out = array();
		if ( preg_match_all( '~([\w:.-]+)\s*=\s*(?:"([^"]*)"|\'([^\']*)\')~', (string) $s, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $a ) {
				$out[ $a[1] ] = ( isset( $a[3] ) && '' !== $a[3] ) ? $a[3] : $a[2];
			}
		}

		return $out;
	}

	private static function parse_declarations( $s ): array {
		$out = array();
		if ( preg_match_all( '~([\w-]+)\s*:\s*((?:[^;()]|\([^)]*\))*)~', (string) $s, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $d ) {
				$val = trim( (string) preg_replace( '~\s*!important\s*$~i', '', $d[2] ) );
				$out[ strtolower( $d[1] ) ] = $val;
			}
		}

		return $out;
	}

	private static function resolve_vars( $value, array $vars ): string {
		$value = (string) $value;
		if ( false === stripos( $value, 'var(' ) ) {
			return $value;
		}

		$out = preg_replace_callback(
			'~var\(\s*(--[\w-]+)\s*(?:,\s*([^)]*))?\)~i',
			function ( $m ) use ( $vars ) {
				if ( isset( $vars[ $m[1] ] ) ) {
					return $vars[ $m[1] ];
				}

				return isset( $m[2] ) ? trim( $m[2] ) : '';
			},
			$value
		);

		return is_string( $out ) ? $out : '';
	}

	private static function parse_len( $v, $ref ) {
		if ( ! preg_match( '~^\s*([-+]?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?)\s*(%|[a-z]*)\s*$~i', (string) $v, $m ) ) {
			return null;
		}
		$n = (float) $m[1];

		return '%' === $m[2] ? $n * $ref / 100 : $n;
	}

	/**
	 * Parses a CSS color.
	 *
	 * @return array|null array( r, g, b, alpha 0..1 ).
	 */
	public static function parse_color( $value ) {
		$v = strtolower( trim( (string) $value ) );
		if ( '' === $v ) {
			return null;
		}

		if ( '#' === $v[0] ) {
			$h = substr( $v, 1 );
			if ( '' === $h || ! ctype_xdigit( $h ) ) {
				return null;
			}
			$l = strlen( $h );
			if ( 3 === $l || 4 === $l ) {
				$e = '';
				for ( $i = 0; $i < $l; $i++ ) {
					$e .= $h[ $i ] . $h[ $i ];
				}
				$h = $e;
				$l = strlen( $h );
			}
			if ( 6 !== $l && 8 !== $l ) {
				return null;
			}

			return array(
				hexdec( substr( $h, 0, 2 ) ),
				hexdec( substr( $h, 2, 2 ) ),
				hexdec( substr( $h, 4, 2 ) ),
				8 === $l ? hexdec( substr( $h, 6, 2 ) ) / 255 : 1.0,
			);
		}

		if ( 'transparent' === $v ) {
			return array( 0, 0, 0, 0.0 );
		}

		if ( preg_match( '~^(rgba?|hsla?)\(\s*(.*?)\s*\)$~', $v, $m ) ) {
			$parts = preg_split( '~[\s,/]+~', trim( $m[2] ), -1, PREG_SPLIT_NO_EMPTY );
			if ( ! $parts || count( $parts ) < 3 ) {
				return null;
			}
			$alpha = 1.0;
			if ( isset( $parts[3] ) ) {
				$alpha = ( '%' === substr( $parts[3], -1 ) ) ? (float) $parts[3] / 100 : (float) $parts[3];
				$alpha = max( 0.0, min( 1.0, $alpha ) );
			}

			if ( 0 === strpos( $m[1], 'rgb' ) ) {
				$rgb = array();
				for ( $i = 0; $i < 3; $i++ ) {
					$p     = $parts[ $i ];
					$n     = ( '%' === substr( $p, -1 ) ) ? (float) $p * 2.55 : (float) $p;
					$rgb[] = (int) round( max( 0.0, min( 255.0, $n ) ) );
				}

				return array( $rgb[0], $rgb[1], $rgb[2], $alpha );
			}

			$hh = fmod( (float) $parts[0], 360.0 );
			if ( $hh < 0 ) {
				$hh += 360.0;
			}
			$ss = max( 0.0, min( 1.0, (float) $parts[1] / 100 ) );
			$ll = max( 0.0, min( 1.0, (float) $parts[2] / 100 ) );
			$c  = ( 1 - abs( 2 * $ll - 1 ) ) * $ss;
			$x  = $c * ( 1 - abs( fmod( $hh / 60, 2 ) - 1 ) );
			$mm = $ll - $c / 2;
			if ( $hh < 60 ) {
				$t = array( $c, $x, 0 );
			} elseif ( $hh < 120 ) {
				$t = array( $x, $c, 0 );
			} elseif ( $hh < 180 ) {
				$t = array( 0, $c, $x );
			} elseif ( $hh < 240 ) {
				$t = array( 0, $x, $c );
			} elseif ( $hh < 300 ) {
				$t = array( $x, 0, $c );
			} else {
				$t = array( $c, 0, $x );
			}

			return array( (int) round( ( $t[0] + $mm ) * 255 ), (int) round( ( $t[1] + $mm ) * 255 ), (int) round( ( $t[2] + $mm ) * 255 ), $alpha );
		}

		static $named = null;
		if ( null === $named ) {
			$named = array();
			foreach ( explode( ',', self::NAMED_COLORS ) as $pair ) {
				$bits = explode( ':', $pair );
				if ( 2 === count( $bits ) ) {
					$named[ $bits[0] ] = $bits[1];
				}
			}
		}
		if ( isset( $named[ $v ] ) ) {
			$h = $named[ $v ];

			return array( hexdec( substr( $h, 0, 2 ) ), hexdec( substr( $h, 2, 2 ) ), hexdec( substr( $h, 4, 2 ) ), 1.0 );
		}

		return null;
	}
}
