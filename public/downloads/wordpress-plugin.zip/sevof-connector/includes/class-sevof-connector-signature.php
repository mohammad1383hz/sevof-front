<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generates and verifies HMAC signatures for communication with the Sevof service.
 *
 * The Laravel implementation must use the same payload contract:
 * HMAC_SHA256( client_id . timestamp . strtoupper( method ) . path . raw_body, client_secret ).
 */
class Sevof_Connector_Signature {
	const TIMESTAMP_TOLERANCE = 300;
	const REPLAY_OPTION_PREFIX = 'sevof_connector_replay_';

	/**
	 * Generates an HMAC signature for an outbound request.
	 */
	public static function sign( string $client_id, string $secret, string $timestamp, string $body, string $method = '', string $path = '' ): string {
		$payload = $client_id . $timestamp . strtoupper( $method ) . $path . $body;

		return hash_hmac( 'sha256', $payload, $secret );
	}

	/**
	 * Verifies an inbound request signature and its short timestamp validity window.
	 */
	public static function verify_incoming( string $timestamp, string $signature, string $body, string $method = '', string $path = '' ): bool {
		$client_id = (string) get_option( 'sevof_connector_client_id', '' );
		$secret = (string) get_option( 'sevof_connector_client_secret', '' );

		if ( '' === $client_id || '' === $secret ) {
			sevof_connector_log( 'signature_credentials_missing' );

			return false;
		}

		if ( ! ctype_digit( $timestamp ) || strlen( $timestamp ) > 10 || ! ctype_xdigit( $signature ) || 64 !== strlen( $signature ) ) {
			sevof_connector_log( 'signature_format_invalid' );

			return false;
		}

		if ( abs( time() - (int) $timestamp ) > self::TIMESTAMP_TOLERANCE ) {
			sevof_connector_log( 'signature_timestamp_expired' );

			return false;
		}

		$expected_signature = self::sign( $client_id, $secret, $timestamp, $body, $method, $path );
		if ( ! hash_equals( $expected_signature, $signature ) ) {
			sevof_connector_log( 'signature_mismatch' );

			return false;
		}

		return true;
	}

	/**
	 * Atomically consumes a valid signature once during its timestamp window.
	 *
	 * add_option() provides an atomic insert when the default database-backed object cache is used.
	 * The hourly cleanup hook removes expired, non-autoloaded replay records.
	 */
	public static function consume_replay_token( string $timestamp, string $signature ): bool {
		$option_name = self::replay_option_name( $timestamp, $signature );
		$expires_at = time() + self::TIMESTAMP_TOLERANCE;

		if ( add_option( $option_name, (string) $expires_at, '', 'no' ) ) {
			return true;
		}

		$stored_expiry = (int) get_option( $option_name, 0 );
		if ( $stored_expiry > 0 && $stored_expiry < time() ) {
			delete_option( $option_name );

			return add_option( $option_name, (string) $expires_at, '', 'no' );
		}

		return false;
	}

	/**
	 * Clears expired replay records. This is registered on a low-frequency cron hook.
	 */
	public static function cleanup_replay_tokens() {
		global $wpdb;

		$option_prefix = $wpdb->esc_like( self::REPLAY_OPTION_PREFIX ) . '%';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a prepared, prefix-scoped bulk DELETE is required here; there is no core wp_options API for deleting many rows by a LIKE pattern in one query, and the deleted rows are transient replay records, not cacheable data.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND option_value < %d",
				$option_prefix,
				time()
			)
		);
	}

	/**
	 * Returns signed headers for an outbound request to the Sevof service.
	 */
	public static function build_outbound_headers( string $body = '', string $method = 'POST', string $path = '' ): array {
		$client_id = (string) get_option( 'sevof_connector_client_id', '' );
		$api_key = (string) get_option( 'sevof_connector_api_key', '' );
		$secret = (string) get_option( 'sevof_connector_client_secret', '' );
		$timestamp = (string) time();

		return array(
			'X-Agent-Key' => $api_key,
			'X-Timestamp' => $timestamp,
			'X-Signature' => self::sign( $client_id, $secret, $timestamp, $body, $method, $path ),
		);
	}

	private static function replay_option_name( string $timestamp, string $signature ): string {
		return self::REPLAY_OPTION_PREFIX . substr( hash( 'sha256', $timestamp . '|' . $signature ), 0, 40 );
	}
}
