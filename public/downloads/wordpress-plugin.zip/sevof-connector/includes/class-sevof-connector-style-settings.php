<?php
/**
 * "Settings" submenu: shows the color palette the connector derives from the site
 * logo and lets the site owner change it.
 *
 * Nothing in the existing detection changes. This class only
 *  - reads what the detector produced (through the `sevof_connector_style_palette` filter),
 *  - lets the owner pin the brand color (it uses the already supported
 *    `sevof_connector_accent_color` option, so every derived tone follows automatically),
 *  - lets the owner override single palette tokens (`sevof_connector_style_overrides`).
 *
 * With nothing saved the generated stylesheet is byte-for-byte the same as before.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sevof_Connector_Style_Settings {
	const PAGE_SLUG        = 'sevof-connector-style';
	const CAPABILITY       = 'manage_options';
	const SAVE_ACTION      = 'sevof_connector_style_save';
	const NONCE_FIELD      = 'sevof_connector_style_nonce';
	const OVERRIDES_OPTION = 'sevof_connector_style_overrides';
	const ACCENT_OPTION    = 'sevof_connector_accent_color';

	/**
	 * Palette as the detector built it (before the owner's overrides).
	 *
	 * @var array|null
	 */
	private static $auto = null;

	/**
	 * Palette that is really printed (auto + overrides).
	 *
	 * @var array|null
	 */
	private static $final = null;

	/**
	 * @var string
	 */
	private static $hook_suffix = '';

	/**
	 * Registers the hooks. The palette filter must also run on the front end.
	 */
	public static function init() {
		add_filter( 'sevof_connector_style_palette', array( self::class, 'apply_overrides' ), 10, 2 );
		add_action( 'admin_menu', array( self::class, 'register_menu' ), 20 );
		add_action( 'admin_post_' . self::SAVE_ACTION, array( self::class, 'handle_save' ) );
		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue_assets' ) );
	}

	/**
	 * Adds the "Appearance" page under the Sevof menu.
	 */
	public static function register_menu() {
		$hook = add_submenu_page(
			Sevof_Connector_Dashboard_Page::PAGE_SLUG,
			__( 'Appearance and colors', 'sevof-connector' ),
			__( 'Appearance', 'sevof-connector' ),
			self::CAPABILITY,
			self::PAGE_SLUG,
			array( self::class, 'render_page' )
		);

		self::$hook_suffix = is_string( $hook ) ? $hook : '';
	}

	/**
	 * Loads the page's stylesheet and script (only on this page).
	 *
	 * @param string $hook Current admin page hook.
	 */
	public static function enqueue_assets( $hook ) {
		if ( '' === self::$hook_suffix || $hook !== self::$hook_suffix ) {
			return;
		}

		$main = SEVOF_CONNECTOR_PATH . 'sevof-connector.php';
		$css  = SEVOF_CONNECTOR_PATH . 'assets/css/style-settings.css';
		$js   = SEVOF_CONNECTOR_PATH . 'assets/js/style-settings.js';

		wp_enqueue_style(
			'sevof-connector-style-settings',
			plugins_url( 'assets/css/style-settings.css', $main ),
			array(),
			SEVOF_CONNECTOR_VERSION . '.' . (int) @filemtime( $css ) // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- a missing file only changes the cache-busting suffix.
		);

		wp_enqueue_script(
			'sevof-connector-style-settings',
			plugins_url( 'assets/js/style-settings.js', $main ),
			array(),
			SEVOF_CONNECTOR_VERSION . '.' . (int) @filemtime( $js ), // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- a missing file only changes the cache-busting suffix.
			true
		);

		wp_localize_script(
			'sevof-connector-style-settings',
			'SevofStyleSettings',
			array(
				'i18n' => array(
					'auto'      => __( 'Auto', 'sevof-connector' ),
					'custom'    => __( 'Custom', 'sevof-connector' ),
					'great'     => __( 'Great contrast', 'sevof-connector' ),
					'good'      => __( 'Good contrast', 'sevof-connector' ),
					'weak'      => __( 'Poor contrast', 'sevof-connector' ),
					'dirty'     => __( 'You have unsaved changes.', 'sevof-connector' ),
					'clean'     => __( 'All changes saved.', 'sevof-connector' ),
					'confirm'   => __( 'Reset every color to automatic (based on your logo)?', 'sevof-connector' ),
					'autoLater' => __( 'The automatic color is detected from your logo or theme after saving.', 'sevof-connector' ),
				),
			)
		);
	}

	// ------------------------------------------------------------------
	// Palette filter
	// ------------------------------------------------------------------

	/**
	 * Remembers the detected palette and applies the owner's saved overrides to it.
	 *
	 * @param array  $palette Token => value, as built from the brand color.
	 * @param string $primary The brand color in use.
	 * @return array
	 */
	public static function apply_overrides( $palette, $primary = '' ) {
		if ( ! is_array( $palette ) ) {
			return $palette;
		}

		self::$auto = $palette;

		$merged = $palette;
		foreach ( self::saved_overrides() as $key => $value ) {
			if ( array_key_exists( $key, $palette ) ) {
				$merged[ $key ] = $value;
			}
		}

		self::$final = $merged;

		return $merged;
	}

	/**
	 * Saved overrides, re-validated on every read.
	 *
	 * @return array token => '#rrggbb' | 'rgba(r,g,b,a)'
	 */
	private static function saved_overrides(): array {
		$raw = get_option( self::OVERRIDES_OPTION, array() );
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$schema = self::flat_schema();
		$out    = array();
		foreach ( $raw as $key => $value ) {
			if ( ! is_string( $key ) || ! isset( $schema[ $key ] ) ) {
				continue;
			}
			$clean = self::clean_value( $value, $schema[ $key ]['type'] );
			if ( null !== $clean ) {
				$out[ $key ] = $clean;
			}
		}

		return $out;
	}

	// ------------------------------------------------------------------
	// Schema
	// ------------------------------------------------------------------

	/**
	 * Every editable token, grouped for the page. `type` is "color" (solid) or
	 * "alpha" (rgba: a color plus opacity). `check` asks the page to show a
	 * readability chip ("text": against white, "cta": against the brand color).
	 *
	 * @return array
	 */
	public static function groups(): array {
		return array(
			'brand'   => array(
				'title'  => __( 'Brand color shades', 'sevof-connector' ),
				'desc'   => __( 'Three shades derived from the brand color, used on links, prices and buttons.', 'sevof-connector' ),
				'tokens' => array(
					'primary_text' => array(
						'label' => __( 'Brand color for text', 'sevof-connector' ),
						'hint'  => __( 'Links, prices and list numbers. Darkened for readability on white.', 'sevof-connector' ),
						'type'  => 'color',
						'check' => 'text',
					),
					'primary_deep' => array(
						'label' => __( 'Dark brand color', 'sevof-connector' ),
						'hint'  => __( 'End of the buy button gradient.', 'sevof-connector' ),
						'type'  => 'color',
					),
					'cta_text'     => array(
						'label' => __( 'Button text', 'sevof-connector' ),
						'hint'  => __( 'Buy button text and the open-question icon in FAQs.', 'sevof-connector' ),
						'type'  => 'color',
						'check' => 'cta',
					),
				),
			),
			'text'    => array(
				'title'  => __( 'Text colors', 'sevof-connector' ),
				'desc'   => __( 'Text in articles, FAQs and product cards.', 'sevof-connector' ),
				'tokens' => array(
					'heading_text'    => array(
						'label' => __( 'Headings', 'sevof-connector' ),
						'hint'  => __( 'H2 and smaller headings, bold text and product names.', 'sevof-connector' ),
						'type'  => 'color',
						'check' => 'text',
					),
					'h3_text'         => array(
						'label' => __( 'Subheading (H3)', 'sevof-connector' ),
						'hint'  => __( 'Subheading color.', 'sevof-connector' ),
						'type'  => 'color',
						'check' => 'text',
					),
					'paragraph_text'  => array(
						'label' => __( 'Paragraph text', 'sevof-connector' ),
						'hint'  => __( 'Paragraphs, list items and product specs.', 'sevof-connector' ),
						'type'  => 'color',
						'check' => 'text',
					),
					'muted'           => array(
						'label' => __( 'Muted text', 'sevof-connector' ),
						'hint'  => __( 'Image captions and product spec labels.', 'sevof-connector' ),
						'type'  => 'color',
						'check' => 'text',
					),
					'faq_title_text'  => array(
						'label' => __( 'FAQ title', 'sevof-connector' ),
						'hint'  => __( 'The FAQ title and questions.', 'sevof-connector' ),
						'type'  => 'color',
						'check' => 'text',
					),
					'faq_answer_text' => array(
						'label' => __( 'Answer text', 'sevof-connector' ),
						'hint'  => __( 'Each answer in the FAQ.', 'sevof-connector' ),
						'type'  => 'color',
						'check' => 'text',
					),
				),
			),
			'surface' => array(
				'title'  => __( 'Backgrounds', 'sevof-connector' ),
				'desc'   => __( 'Backgrounds of headings, lists, product cards and the FAQ box.', 'sevof-connector' ),
				'tokens' => array(
					'wash_strong'   => array(
						'label' => __( 'H2 background (start)', 'sevof-connector' ),
						'hint'  => __( 'Start of the gradient behind main headings.', 'sevof-connector' ),
						'type'  => 'alpha',
					),
					'wash_soft'     => array(
						'label' => __( 'H2 background (end)', 'sevof-connector' ),
						'hint'  => __( 'End of the gradient behind main headings.', 'sevof-connector' ),
						'type'  => 'alpha',
					),
					'list_bg'       => array(
						'label' => __( 'List and quote background', 'sevof-connector' ),
						'hint'  => __( 'Lists, quotes and even table rows.', 'sevof-connector' ),
						'type'  => 'color',
					),
					'icon_bg'       => array(
						'label' => __( 'Icon and table header background', 'sevof-connector' ),
						'hint'  => __( 'List number circles, the FAQ + button, category labels and table headers.', 'sevof-connector' ),
						'type'  => 'color',
					),
					'media_bg_a'    => array(
						'label' => __( 'Product image background (start)', 'sevof-connector' ),
						'hint'  => __( 'Start of the gradient behind product images.', 'sevof-connector' ),
						'type'  => 'color',
					),
					'media_bg_b'    => array(
						'label' => __( 'Product image background (end)', 'sevof-connector' ),
						'hint'  => __( 'End of the gradient behind product images.', 'sevof-connector' ),
						'type'  => 'color',
					),
					'faq_bg_top'    => array(
						'label' => __( 'FAQ box background (top)', 'sevof-connector' ),
						'hint'  => __( 'Start of the FAQ box gradient.', 'sevof-connector' ),
						'type'  => 'color',
					),
					'faq_bg_bottom' => array(
						'label' => __( 'FAQ box background (bottom)', 'sevof-connector' ),
						'hint'  => __( 'End of the FAQ box gradient.', 'sevof-connector' ),
						'type'  => 'color',
					),
				),
			),
			'border'  => array(
				'title'  => __( 'Borders and lines', 'sevof-connector' ),
				'desc'   => __( 'Borders and dividers of each part.', 'sevof-connector' ),
				'tokens' => array(
					'list_border'       => array(
						'label' => __( 'List border and dividers', 'sevof-connector' ),
						'hint'  => __( 'List borders, table row lines, horizontal rules and product specs.', 'sevof-connector' ),
						'type'  => 'color',
					),
					'card_border'       => array(
						'label' => __( 'Product card border', 'sevof-connector' ),
						'hint'  => __( 'The border around product cards.', 'sevof-connector' ),
						'type'  => 'color',
					),
					'faq_border'        => array(
						'label' => __( 'FAQ box and table border', 'sevof-connector' ),
						'hint'  => __( 'The outer border of the FAQ box and tables.', 'sevof-connector' ),
						'type'  => 'color',
					),
					'faq_title_border'  => array(
						'label' => __( 'FAQ title underline', 'sevof-connector' ),
						'hint'  => __( 'The line under the FAQ title.', 'sevof-connector' ),
						'type'  => 'color',
					),
					'faq_item_border'   => array(
						'label' => __( 'Question border', 'sevof-connector' ),
						'hint'  => __( 'The border around each question (accordion).', 'sevof-connector' ),
						'type'  => 'color',
					),
					'faq_answer_border' => array(
						'label' => __( 'Answer divider', 'sevof-connector' ),
						'hint'  => __( 'The line between a question and its answer.', 'sevof-connector' ),
						'type'  => 'color',
					),
				),
			),
			'effects' => array(
				'title'  => __( 'Shadows and effects', 'sevof-connector' ),
				'desc'   => __( 'Semi-transparent colors; you can also adjust the opacity.', 'sevof-connector' ),
				'tokens' => array(
					'shadow'         => array(
						'label' => __( 'Main shadow', 'sevof-connector' ),
						'hint'  => __( 'Shadow of product cards and article images.', 'sevof-connector' ),
						'type'  => 'alpha',
					),
					'shadow_soft'    => array(
						'label' => __( 'Soft shadow', 'sevof-connector' ),
						'hint'  => __( 'The thin shadow layer of product cards.', 'sevof-connector' ),
						'type'  => 'alpha',
					),
					'link_underline' => array(
						'label' => __( 'Link underline', 'sevof-connector' ),
						'hint'  => __( 'Underline of links in the text (stronger on hover).', 'sevof-connector' ),
						'type'  => 'alpha',
					),
				),
			),
		);
	}

	/**
	 * token => meta, across all groups.
	 */
	private static function flat_schema(): array {
		$flat = array();
		foreach ( self::groups() as $group ) {
			foreach ( $group['tokens'] as $key => $meta ) {
				$flat[ $key ] = $meta;
			}
		}

		return $flat;
	}

	// ------------------------------------------------------------------
	// Validation helpers (every stored value is a strict hex / rgba string)
	// ------------------------------------------------------------------

	/**
	 * "#abc", "abc", "#AABBCC" => "#aabbcc"; anything else => null.
	 */
	private static function clean_hex( $value ) {
		if ( ! is_string( $value ) ) {
			return null;
		}
		$hex = strtolower( ltrim( trim( $value ), '#' ) );
		if ( 3 === strlen( $hex ) && ctype_xdigit( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( 6 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
			return null;
		}

		return '#' . $hex;
	}

	/**
	 * "rgba(r,g,b,a)" => array( r, g, b, a ); anything else => null.
	 */
	private static function parse_rgba( $value ) {
		if ( ! is_string( $value ) ) {
			return null;
		}
		if ( ! preg_match( '~^rgba\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(0|1|0?\.\d{1,3}|1\.0{1,3})\s*\)$~', trim( $value ), $m ) ) {
			return null;
		}
		$r = (int) $m[1];
		$g = (int) $m[2];
		$b = (int) $m[3];
		if ( $r > 255 || $g > 255 || $b > 255 ) {
			return null;
		}

		return array( $r, $g, $b, (float) $m[4] );
	}

	private static function format_rgba( int $r, int $g, int $b, float $alpha ): string {
		$alpha = max( 0.0, min( 1.0, $alpha ) );

		return sprintf( 'rgba(%d,%d,%d,%s)', $r, $g, $b, rtrim( rtrim( number_format( $alpha, 3, '.', '' ), '0' ), '.' ) );
	}

	private static function hex_parts( string $hex ): array {
		return array( hexdec( substr( $hex, 1, 2 ) ), hexdec( substr( $hex, 3, 2 ) ), hexdec( substr( $hex, 5, 2 ) ) );
	}

	/**
	 * Validates a token value for its type. Returns the canonical string or null.
	 */
	private static function clean_value( $value, string $type ) {
		if ( 'alpha' === $type ) {
			$p = self::parse_rgba( $value );

			return $p ? self::format_rgba( $p[0], $p[1], $p[2], $p[3] ) : null;
		}

		return self::clean_hex( $value );
	}

	/**
	 * Splits a palette value into the pieces the page's inputs need.
	 *
	 * @return array array( 'hex' => '#rrggbb', 'pct' => float|null )
	 */
	private static function value_parts( $value, string $type ): array {
		if ( 'alpha' === $type ) {
			$p = self::parse_rgba( $value );
			if ( $p ) {
				return array(
					'hex' => sprintf( '#%02x%02x%02x', $p[0], $p[1], $p[2] ),
					'pct' => round( $p[3] * 100, 1 ),
				);
			}

			return array(
				'hex' => '#000000',
				'pct' => 100.0,
			);
		}

		$hex = self::clean_hex( $value );

		return array(
			'hex' => $hex ? $hex : '#000000',
			'pct' => null,
		);
	}

	/**
	 * CSS value (hex or rgba) for the pieces returned by value_parts(). Used by the page view.
	 */
	public static function css_value( array $parts, string $type ): string {
		$hex = isset( $parts['hex'] ) ? (string) $parts['hex'] : '#000000';
		if ( 'alpha' !== $type ) {
			return $hex;
		}
		$rgb = self::hex_parts( $hex );
		$pct = isset( $parts['pct'] ) ? (float) $parts['pct'] : 100.0;

		return self::format_rgba( (int) $rgb[0], (int) $rgb[1], (int) $rgb[2], $pct / 100 );
	}

	/**
	 * True when another piece of code pins the brand color through the filter, in
	 * which case the page cannot change it.
	 */
	private static function accent_locked(): bool {
		return null !== self::clean_hex( apply_filters( 'sevof_connector_accent_color', '' ) );
	}

	// ------------------------------------------------------------------
	// Saving
	// ------------------------------------------------------------------

	/**
	 * Handles the "save" and "reset" buttons.
	 */
	public static function handle_save() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to access this page.', 'sevof-connector' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( self::SAVE_ACTION, self::NONCE_FIELD );

		$do = isset( $_POST['yx_do'] ) ? sanitize_key( wp_unslash( $_POST['yx_do'] ) ) : 'save';

		if ( 'reset' === $do ) {
			delete_option( self::OVERRIDES_OPTION );
			if ( ! self::accent_locked() ) {
				delete_option( self::ACCENT_OPTION );
			}
			self::redirect( 'reset' );
		}

		// Brand color: stored in the already supported accent option, so every derived tone follows it.
		if ( ! self::accent_locked() ) {
			$mode = isset( $_POST['yx_primary_mode'] ) ? sanitize_key( wp_unslash( $_POST['yx_primary_mode'] ) ) : 'auto';
			if ( 'manual' === $mode ) {
				$hex = isset( $_POST['yx_primary'] ) ? self::clean_hex( sanitize_text_field( wp_unslash( $_POST['yx_primary'] ) ) ) : null;
				if ( $hex ) {
					update_option( self::ACCENT_OPTION, $hex, false );
				}
			} else {
				delete_option( self::ACCENT_OPTION );
			}
		}

		// Single-token overrides: only the ones the owner explicitly edited.
		$tokens = array();
		$alphas = array();
		$custom = array();
		// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- every element is validated below against a strict hex / number pattern.
		if ( isset( $_POST['yx_tokens'] ) && is_array( $_POST['yx_tokens'] ) ) {
			$tokens = wp_unslash( $_POST['yx_tokens'] );
		}
		if ( isset( $_POST['yx_alpha'] ) && is_array( $_POST['yx_alpha'] ) ) {
			$alphas = wp_unslash( $_POST['yx_alpha'] );
		}
		if ( isset( $_POST['yx_custom'] ) && is_array( $_POST['yx_custom'] ) ) {
			$custom = wp_unslash( $_POST['yx_custom'] );
		}
		// phpcs:enable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		$new = array();
		foreach ( self::flat_schema() as $key => $meta ) {
			if ( ! isset( $custom[ $key ] ) || '1' !== (string) $custom[ $key ] ) {
				continue;
			}
			$hex = isset( $tokens[ $key ] ) ? self::clean_hex( $tokens[ $key ] ) : null;
			if ( ! $hex ) {
				continue;
			}
			if ( 'alpha' === $meta['type'] ) {
				$pct = ( isset( $alphas[ $key ] ) && is_scalar( $alphas[ $key ] ) && is_numeric( $alphas[ $key ] ) ) ? (float) $alphas[ $key ] : 100.0;
				$pct = max( 0.0, min( 100.0, $pct ) );
				$rgb = self::hex_parts( $hex );
				$new[ $key ] = self::format_rgba( (int) $rgb[0], (int) $rgb[1], (int) $rgb[2], $pct / 100 );
			} else {
				$new[ $key ] = $hex;
			}
		}

		if ( empty( $new ) ) {
			delete_option( self::OVERRIDES_OPTION );
		} else {
			update_option( self::OVERRIDES_OPTION, $new, false );
		}

		self::redirect( 'saved' );
	}

	private static function redirect( string $notice ) {
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'      => self::PAGE_SLUG,
					'yx_notice' => $notice,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	// ------------------------------------------------------------------
	// Page
	// ------------------------------------------------------------------

	/**
	 * Renders the settings page.
	 */
	public static function render_page() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}

		$view = SEVOF_CONNECTOR_PATH . 'includes/views/style-settings-page.php';
		if ( ! is_readable( $view ) ) {
			return;
		}

		// Building the stylesheet runs the palette filter, which records the detected palette.
		if ( class_exists( 'Sevof_Connector_Rest_Controller' ) ) {
			Sevof_Connector_Rest_Controller::branded_css();
		}

		$groups    = self::groups();
		$schema    = self::flat_schema();
		$auto      = is_array( self::$auto ) ? self::$auto : array();
		$final     = is_array( self::$final ) ? self::$final : $auto;
		$overrides = self::saved_overrides();

		$accent_locked = self::accent_locked();
		$accent_saved  = self::clean_hex( get_option( self::ACCENT_OPTION, '' ) );
		$primary       = isset( $final['primary'] ) && self::clean_hex( $final['primary'] ) ? self::clean_hex( $final['primary'] ) : '#2f7d78';
		$manual        = ! $accent_locked && null !== $accent_saved;

		// Logo detection (same detector the stylesheet uses; result is cached by it).
		$logo = class_exists( 'Sevof_Connector_Logo_Color' ) ? Sevof_Connector_Logo_Color::detect() : null;
		$logo = is_array( $logo ) && ! empty( $logo['hex'] ) && self::clean_hex( $logo['hex'] ) ? $logo : null;

		// What "automatic" gives: while the owner has not pinned a color it is the color in use;
		// otherwise the logo's color when it has one (a theme-based fallback is only known after saving).
		$auto_primary = null;
		if ( ! $manual ) {
			$auto_primary = $primary;
		} elseif ( $logo && ! empty( $logo['chromatic'] ) ) {
			$auto_primary = self::clean_hex( $logo['hex'] );
		}

		// Per-token state for the inputs.
		$tiles = array();
		foreach ( $schema as $key => $meta ) {
			$auto_value  = isset( $auto[ $key ] ) ? $auto[ $key ] : '';
			$final_value = isset( $final[ $key ] ) ? $final[ $key ] : $auto_value;
			$tiles[ $key ] = array(
				'value'  => self::value_parts( $final_value, $meta['type'] ),
				'auto'   => self::value_parts( $auto_value, $meta['type'] ),
				'custom' => isset( $overrides[ $key ] ),
			);
		}

		$logo_url = '';
		foreach ( array( get_theme_mod( 'custom_logo' ), get_option( 'site_logo' ), get_option( 'site_icon' ) ) as $logo_id ) {
			if ( is_numeric( $logo_id ) && (int) $logo_id > 0 ) {
				$url = wp_get_attachment_image_url( (int) $logo_id, 'medium' );
				if ( is_string( $url ) && '' !== $url ) {
					$logo_url = $url;
					break;
				}
			}
		}

		$logo_source = $logo ? self::source_label( isset( $logo['source'] ) ? (string) $logo['source'] : '' ) : '';

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only notice flag.
		$notice = isset( $_GET['yx_notice'] ) ? sanitize_key( wp_unslash( $_GET['yx_notice'] ) ) : '';

		include $view;
	}

	/**
	 * Human label for where the logo color was read from.
	 */
	private static function source_label( string $source ): string {
		if ( 'custom_logo' === $source ) {
			return __( 'Site logo (Customizer)', 'sevof-connector' );
		}
		if ( 'site_logo' === $source ) {
			return __( 'Site logo (block theme)', 'sevof-connector' );
		}
		if ( 'site_icon' === $source ) {
			return __( 'Site icon (favicon)', 'sevof-connector' );
		}
		if ( 'filter' === $source ) {
			return __( 'Path set in code', 'sevof-connector' );
		}
		if ( '' === $source ) {
			return '';
		}

		return __( 'Theme logo settings', 'sevof-connector' );
	}
}
