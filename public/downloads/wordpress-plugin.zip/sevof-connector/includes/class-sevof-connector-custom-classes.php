<?php
/**
 * "Custom classes & CSS" settings page.
 *
 * Lets the site owner style Sevof articles and product cards with their own theme
 * classes instead of (or on top of) the built-in look:
 *  - extra CSS classes per element (article body, H2/H3, table, FAQ, product card,
 *    title, price, buy button). They are added when the page is rendered, so posts
 *    that were already published pick them up without a re-sync and the stored
 *    markup stays untouched;
 *  - switches to stop printing the built-in stylesheet (whole, or product cards only),
 *    so the theme classes are not overridden by the built-in `!important` rules;
 *  - a custom CSS box, printed after the built-in styles;
 *  - automatic style detection: the site's own latest posts (not written by Sevof) are
 *    scanned and the style classes they consistently use on H2/H3, tables and buttons are
 *    put on the same Sevof elements, and only the built-in rules of those elements are
 *    dropped so the site's own look shows. Nothing detected = the built-in look, as before.
 *    A class typed by the owner always wins over a detected one.
 *
 * With nothing saved and nothing detected, the output is exactly the same as before.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Sevof_Connector_Custom_Classes {
	const PAGE_SLUG   = 'sevof-connector-custom-classes';
	const CAPABILITY  = 'manage_options';
	const OPTION      = 'sevof_connector_custom_classes';
	const SAVE_ACTION = 'sevof_connector_custom_classes_save';
	const NONCE_FIELD = 'sevof_connector_custom_classes_nonce';

	/** Extra classes per element: at most this many, each a valid class name. */
	const MAX_CLASSES = 10;

	/** Upper bound for the custom CSS box. */
	const MAX_CSS_LENGTH = 30000;

	/** Cached detection result (refreshed twice a day, or with the "detect again" button). */
	const DETECT_TRANSIENT = 'sevof_connector_detected_style';
	const DETECT_TTL       = 43200;

	/** How many of the site's latest own posts are scanned. */
	const DETECT_POSTS = 20;

	/** A class counts as the site's style when at least this many posts use it ... */
	const DETECT_MIN_POSTS = 3;

	/** ... and at least this share of the posts that have that element. */
	const DETECT_SHARE = 0.5;

	/** Block markers every block-editor post has; they say nothing about the site's style. */
	const GENERIC_CLASSES = array( 'wp-block-heading', 'wp-block-table', 'wp-block-list', 'wp-block-image', 'wp-block-button', 'wp-block-buttons', 'has-fixed-layout', 'aligncenter', 'alignleft', 'alignright', 'alignwide', 'alignfull', 'alignnone' );

	/**
	 * Every element the owner can add classes to. `token` = a class Sevof already puts
	 * on that element; `tag` = a plain tag inside the article body.
	 *
	 * @return array
	 */
	public static function elements(): array {
		return array(
			'article_body'  => array( 'token' => 'sevof-article-body', 'label' => __( 'Article body', 'sevof-connector' ), 'hint' => __( 'The box around the whole article text.', 'sevof-connector' ) ),
			'heading_h2'    => array( 'tag' => 'h2', 'label' => __( 'Main heading (H2)', 'sevof-connector' ), 'hint' => __( 'Main headings inside the article.', 'sevof-connector' ) ),
			'heading_h3'    => array( 'tag' => 'h3', 'label' => __( 'Subheading (H3)', 'sevof-connector' ), 'hint' => __( 'Subheadings inside the article.', 'sevof-connector' ) ),
			'table'         => array( 'token' => 'sevof-table', 'label' => __( 'Table', 'sevof-connector' ), 'hint' => '' ),
			'table_wrap'    => array( 'token' => 'sevof-table-wrap', 'label' => __( 'Table wrapper', 'sevof-connector' ), 'hint' => __( 'For example is-style-stripes for your theme\'s striped table.', 'sevof-connector' ) ),
			'faq'           => array( 'token' => 'sevof-faq', 'label' => __( 'FAQ section', 'sevof-connector' ), 'hint' => '' ),
			'faq_item'      => array( 'token' => 'sevof-faq-item', 'label' => __( 'Each question', 'sevof-connector' ), 'hint' => '' ),
			'products'      => array( 'token' => 'sevof-products', 'label' => __( 'Product card list', 'sevof-connector' ), 'hint' => __( 'The container that holds the product cards.', 'sevof-connector' ) ),
			'product_card'  => array( 'token' => 'sevof-product-card', 'label' => __( 'Product card', 'sevof-connector' ), 'hint' => '' ),
			'product_title' => array( 'token' => 'sevof-product-title', 'label' => __( 'Product name', 'sevof-connector' ), 'hint' => '' ),
			'product_price' => array( 'token' => 'sevof-product-price', 'label' => __( 'Product price', 'sevof-connector' ), 'hint' => '' ),
			'product_cta'   => array( 'token' => 'sevof-product-cta', 'label' => __( 'Buy button', 'sevof-connector' ), 'hint' => __( 'For example your theme\'s button class: button btn-primary', 'sevof-connector' ) ),
		);
	}

	/**
	 * Registers the hooks (the content/CSS filters must also run on the front end).
	 */
	public static function init() {
		add_filter( 'the_content', array( self::class, 'apply_classes' ), 100 );
		add_filter( 'sevof_connector_branded_css', array( self::class, 'filter_builtin_css' ) );
		add_action( 'wp_head', array( self::class, 'print_custom_css' ), 30 );
		add_action( 'admin_menu', array( self::class, 'register_menu' ), 21 );
		add_action( 'admin_post_' . self::SAVE_ACTION, array( self::class, 'handle_save' ) );
	}

	// ------------------------------------------------------------------
	// Settings
	// ------------------------------------------------------------------

	/**
	 * Saved settings, re-validated on every read.
	 *
	 * @return array{classes: array<string, string[]>, disable_builtin: bool, disable_card_builtin: bool, custom_css: string}
	 */
	public static function settings(): array {
		$raw = get_option( self::OPTION, array() );
		$raw = is_array( $raw ) ? $raw : array();

		$classes = array();
		$saved   = isset( $raw['classes'] ) && is_array( $raw['classes'] ) ? $raw['classes'] : array();
		foreach ( array_keys( self::elements() ) as $key ) {
			$list = self::clean_classes( isset( $saved[ $key ] ) ? $saved[ $key ] : '' );
			if ( ! empty( $list ) ) {
				$classes[ $key ] = $list;
			}
		}

		return array(
			'classes'              => $classes,
			// on unless the owner switched it off
			'auto_detect'          => ! array_key_exists( 'auto_detect', $raw ) || ! empty( $raw['auto_detect'] ),
			'disable_builtin'      => ! empty( $raw['disable_builtin'] ),
			'disable_card_builtin' => ! empty( $raw['disable_card_builtin'] ),
			'custom_css'           => self::clean_css( isset( $raw['custom_css'] ) ? $raw['custom_css'] : '' ),
		);
	}

	/**
	 * "btn  btn-primary .x" => array( 'btn', 'btn-primary', 'x' ). Invalid names are dropped.
	 *
	 * @param mixed $value Space separated class names.
	 * @return string[]
	 */
	public static function clean_classes( $value ): array {
		if ( ! is_string( $value ) ) {
			return array();
		}

		$out = array();
		foreach ( preg_split( '/[\s,]+/', $value ) as $name ) {
			$name = sanitize_html_class( ltrim( $name, '.' ) );
			if ( '' !== $name && ! in_array( $name, $out, true ) ) {
				$out[] = $name;
			}
			if ( count( $out ) >= self::MAX_CLASSES ) {
				break;
			}
		}

		return $out;
	}

	/**
	 * Plain CSS only: tags removed and `</style` sequences broken so the text can never leave the style block.
	 *
	 * @param mixed $value Raw CSS.
	 */
	public static function clean_css( $value ): string {
		if ( ! is_string( $value ) ) {
			return '';
		}

		$css = wp_strip_all_tags( $value );
		$css = str_ireplace( array( '</style', '<style', '<script', '</script' ), '', $css );

		return trim( substr( $css, 0, self::MAX_CSS_LENGTH ) );
	}

	// ------------------------------------------------------------------
	// Front end
	// ------------------------------------------------------------------

	/**
	 * Adds the owner's classes to Sevof elements in the rendered content.
	 *
	 * @param string $content Post content after Sevof wrapped it (priority 99).
	 * @return string
	 */
	public static function apply_classes( $content ) {
		if ( ! is_string( $content ) || false === strpos( $content, 'sevof-' ) ) {
			return $content;
		}

		$classes = self::effective_classes()['classes'];
		if ( empty( $classes ) ) {
			return $content;
		}

		$by_token = array();
		$by_tag   = array();
		foreach ( self::elements() as $key => $element ) {
			if ( empty( $classes[ $key ] ) ) {
				continue;
			}
			if ( isset( $element['token'] ) ) {
				$by_token[ $element['token'] ] = $classes[ $key ];
			} else {
				$by_tag[ $element['tag'] ] = $classes[ $key ];
			}
		}

		if ( ! empty( $by_token ) ) {
			$content = (string) preg_replace_callback(
				'/\bclass\s*=\s*(["\'])(.*?)\1/is',
				function ( $m ) use ( $by_token ) {
					$current = preg_split( '/\s+/', trim( $m[2] ), -1, PREG_SPLIT_NO_EMPTY );
					$add     = array();
					foreach ( $by_token as $token => $extra ) {
						if ( in_array( $token, $current, true ) ) {
							$add = array_merge( $add, $extra );
						}
					}

					if ( empty( $add ) ) {
						return $m[0];
					}

					return 'class=' . $m[1] . esc_attr( implode( ' ', array_unique( array_merge( $current, $add ) ) ) ) . $m[1];
				},
				$content
			);
		}

		// Plain headings exist only inside the article body; product-card titles keep their own setting.
		if ( ! empty( $by_tag ) && false !== strpos( $content, 'sevof-article-body' ) ) {
			$content = (string) preg_replace_callback(
				'/<(h2|h3)(\s[^>]*)?>/i',
				function ( $m ) use ( $by_tag ) {
					$tag   = strtolower( $m[1] );
					$attrs = isset( $m[2] ) ? $m[2] : '';
					if ( empty( $by_tag[ $tag ] ) || false !== strpos( $attrs, 'sevof-' ) ) {
						return $m[0];
					}

					$extra = implode( ' ', $by_tag[ $tag ] );
					if ( preg_match( '/\bclass\s*=\s*(["\'])(.*?)\1/is', $attrs, $c ) ) {
						$merged = implode( ' ', array_unique( array_merge( preg_split( '/\s+/', trim( $c[2] ), -1, PREG_SPLIT_NO_EMPTY ), $by_tag[ $tag ] ) ) );
						$attrs  = str_replace( $c[0], 'class=' . $c[1] . esc_attr( $merged ) . $c[1], $attrs );
					} else {
						$attrs .= ' class="' . esc_attr( $extra ) . '"';
					}

					return '<' . $m[1] . $attrs . '>';
				},
				$content
			);
		}

		return $content;
	}

	/**
	 * Lets the owner turn off the built-in look so theme classes are not overridden.
	 *
	 * @param string $css Built-in stylesheet.
	 * @return string
	 */
	public static function filter_builtin_css( $css ) {
		$settings = self::settings();

		if ( $settings['disable_builtin'] ) {
			return '';
		}

		if ( $settings['disable_card_builtin'] ) {
			$css = (string) preg_replace( '~/\* -+ Product cards -+ \*/.*?(?=/\* -+ Tables -+ \*/)~s', '', (string) $css );
		}

		// The site's own style was detected for these elements: their built-in rules would hide it.
		$patterns = array();
		$rules    = self::detectable();
		foreach ( self::effective_classes()['auto'] as $key ) {
			$patterns[] = $rules[ $key ]['strip'];
		}

		return empty( $patterns ) ? $css : self::strip_rules( (string) $css, $patterns );
	}

	/**
	 * Removes every CSS rule whose selector matches one of the patterns (also inside @media).
	 * Section comments are kept, other code looks for them.
	 *
	 * @param string   $css      Stylesheet.
	 * @param string[] $patterns Regexes tested against each comma-separated selector.
	 */
	public static function strip_rules( string $css, array $patterns ): string {
		return (string) preg_replace_callback(
			'/([^{}]+)\{([^{}]*)\}/',
			function ( $m ) use ( $patterns ) {
				$selector = trim( (string) preg_replace( '~/\*.*?\*/~s', '', $m[1] ) );
				if ( '' === $selector || '@' === $selector[0] ) {
					return $m[0];
				}

				foreach ( explode( ',', $selector ) as $part ) {
					foreach ( $patterns as $pattern ) {
						if ( preg_match( $pattern, trim( $part ) ) ) {
							preg_match_all( '~/\*.*?\*/~s', $m[1], $comments );

							return implode( "\n", $comments[0] );
						}
					}
				}

				return $m[0];
			},
			$css
		);
	}

	// ------------------------------------------------------------------
	// Style detection
	// ------------------------------------------------------------------

	/**
	 * Elements that can be detected: `find` = the tag in the site's posts (group 1 = its
	 * attributes), `strip` = built-in selectors to drop when it is detected, `base` = classes
	 * the site's style needs next to the detected ones.
	 *
	 * @return array
	 */
	public static function detectable(): array {
		return array(
			'heading_h2'  => array( 'find' => '/<h2\b([^>]*)>/i', 'strip' => '/>\s*h2(?![\w-])/', 'base' => array() ),
			'heading_h3'  => array( 'find' => '/<h3\b([^>]*)>/i', 'strip' => '/>\s*h3(?![\w-])/', 'base' => array() ),
			'table'       => array( 'find' => '/<table\b([^>]*)>/i', 'strip' => '/table\.sevof-table(?![\w-])/', 'base' => array() ),
			'table_wrap'  => array( 'find' => '/<figure\b([^>]*\bwp-block-table\b[^>]*)>/i', 'strip' => '/\.sevof-table-wrap$/', 'base' => array( 'wp-block-table' ) ),
			'product_cta' => array( 'find' => '/<a\b([^>]*\bclass\s*=\s*["\'][^"\']*(?:btn|button)[^"\']*["\'][^>]*)>/i', 'strip' => '/(?<!not\()a?\.sevof-product-cta(?![\w-])/', 'base' => array() ),
		);
	}

	/** Classes that describe a look (not ids, alignment or editor bookkeeping). */
	public static function is_style_class( string $name ): bool {
		if ( in_array( $name, self::GENERIC_CLASSES, true ) ) {
			return false;
		}

		if ( preg_match( '/^(has-text-align-|align|wp-image-|size-|is-layout-|wp-container-|is-content-justification|is-nowrap|ez-toc|rank-math|yoast|sevof-)/', $name ) || preg_match( '/\d{3,}/', $name ) ) {
			return false;
		}

		return (bool) preg_match( '/^[A-Za-z_-][\w-]*$/', $name );
	}

	/**
	 * Style classes the site's own posts use consistently, per element.
	 *
	 * @param string[] $contents Post contents (latest first).
	 * @return array{elements: array<string, string[]>, posts: int}
	 */
	public static function detect_from( array $contents ): array {
		$rules = self::detectable();
		$with  = array();
		$count = array();

		foreach ( $contents as $content ) {
			foreach ( $rules as $key => $rule ) {
				if ( ! preg_match_all( $rule['find'], (string) $content, $matches ) ) {
					continue;
				}

				$with[ $key ] = ( isset( $with[ $key ] ) ? $with[ $key ] : 0 ) + 1;
				$found        = array();
				foreach ( $matches[1] as $attrs ) {
					if ( preg_match( '/\bclass\s*=\s*(["\'])(.*?)\1/is', $attrs, $c ) ) {
						foreach ( preg_split( '/\s+/', trim( $c[2] ), -1, PREG_SPLIT_NO_EMPTY ) as $name ) {
							if ( self::is_style_class( $name ) ) {
								$found[ $name ] = true;
							}
						}
					}
				}

				foreach ( array_keys( $found ) as $name ) {
					$count[ $key ][ $name ] = ( isset( $count[ $key ][ $name ] ) ? $count[ $key ][ $name ] : 0 ) + 1;
				}
			}
		}

		$elements = array();
		foreach ( $count as $key => $names ) {
			$needed = max( self::DETECT_MIN_POSTS, (int) ceil( $with[ $key ] * self::DETECT_SHARE ) );
			arsort( $names );
			$picked = array_keys( array_filter( $names, function ( $n ) use ( $needed ) {
				return $n >= $needed;
			} ) );

			if ( ! empty( $picked ) ) {
				$elements[ $key ] = array_values( array_unique( array_merge( $rules[ $key ]['base'], array_slice( $picked, 0, 5 ) ) ) );
			}
		}

		return array( 'elements' => $elements, 'posts' => count( $contents ) );
	}

	/**
	 * Detection result for this site, cached.
	 *
	 * @param bool $fresh Ignore the cache.
	 * @return array{elements: array<string, string[]>, posts: int, at: int}
	 */
	public static function detected( bool $fresh = false ): array {
		$cached = $fresh ? false : get_transient( self::DETECT_TRANSIENT );
		if ( is_array( $cached ) && isset( $cached['elements'] ) ) {
			return $cached;
		}

		$meta  = class_exists( 'Sevof_Connector_Rest_Controller' ) ? Sevof_Connector_Rest_Controller::MANAGED_META_KEY : '_sevof_managed';
		$posts = get_posts(
			array(
				'post_type'        => 'post',
				'post_status'      => 'publish',
				'numberposts'      => self::DETECT_POSTS,
				'orderby'          => 'date',
				'order'            => 'DESC',
				'no_found_rows'    => true,
				'suppress_filters' => true,
				// only the site's own posts, never the ones Sevof wrote
				'meta_query'       => array( array( 'key' => $meta, 'compare' => 'NOT EXISTS' ) ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- 20 posts, cached for 12 hours.
			)
		);

		$contents = array();
		foreach ( $posts as $post ) {
			$contents[] = (string) $post->post_content;
		}

		$result       = self::detect_from( $contents );
		$result['at'] = time();
		set_transient( self::DETECT_TRANSIENT, $result, self::DETECT_TTL );

		return $result;
	}

	/**
	 * Classes really added per element: the owner's own, else (when allowed) the detected ones.
	 *
	 * @return array{classes: array<string, string[]>, auto: string[]}
	 */
	public static function effective_classes(): array {
		$settings = self::settings();
		$classes  = $settings['classes'];
		$auto     = array();

		if ( $settings['auto_detect'] && ! $settings['disable_builtin'] ) {
			foreach ( self::detected()['elements'] as $key => $list ) {
				if ( empty( $classes[ $key ] ) && ! empty( $list ) ) {
					$classes[ $key ] = $list;
					$auto[]          = $key;
				}
			}
		}

		return array( 'classes' => $classes, 'auto' => $auto );
	}

	/**
	 * Prints the owner's CSS after the built-in styles, on single posts and products.
	 */
	public static function print_custom_css() {
		if ( ! is_singular( array( 'post', 'product' ) ) ) {
			return;
		}

		$css = self::settings()['custom_css'];
		if ( '' === $css ) {
			return;
		}

		echo '<style id="sevof-connector-custom-css">' . "\n" . $css . "\n</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- tags stripped in clean_css(); saved only by admins.
	}

	// ------------------------------------------------------------------
	// Admin page
	// ------------------------------------------------------------------

	public static function register_menu() {
		add_submenu_page(
			Sevof_Connector_Dashboard_Page::PAGE_SLUG,
			__( 'Custom classes & CSS', 'sevof-connector' ),
			__( 'Custom classes & CSS', 'sevof-connector' ),
			self::CAPABILITY,
			self::PAGE_SLUG,
			array( self::class, 'render_page' )
		);
	}

	public static function handle_save() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to access this page.', 'sevof-connector' ), 403 );
		}
		check_admin_referer( self::SAVE_ACTION, self::NONCE_FIELD );

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above.
		$posted  = isset( $_POST['yxc_classes'] ) && is_array( $_POST['yxc_classes'] ) ? wp_unslash( $_POST['yxc_classes'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- cleaned per field below.
		$classes = array();
		foreach ( array_keys( self::elements() ) as $key ) {
			$list = self::clean_classes( isset( $posted[ $key ] ) ? $posted[ $key ] : '' );
			if ( ! empty( $list ) ) {
				$classes[ $key ] = implode( ' ', $list );
			}
		}

		$css = isset( $_POST['yxc_custom_css'] ) ? (string) wp_unslash( $_POST['yxc_custom_css'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- cleaned in clean_css().
		// Same rule as WordPress "Additional CSS": only users who may edit CSS can change it.
		if ( ! current_user_can( 'edit_css' ) ) {
			$css = self::settings()['custom_css'];
		}

		$do = isset( $_POST['yxc_do'] ) ? sanitize_key( wp_unslash( $_POST['yxc_do'] ) ) : 'save';

		if ( 'detect' === $do ) {
			self::detected( true );
			wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE_SLUG, 'yxc_notice' => 'detected' ), admin_url( 'admin.php' ) ) );
			exit;
		}

		$reset = 'reset' === $do;

		update_option(
			self::OPTION,
			$reset ? array() : array(
				'classes'              => $classes,
				'auto_detect'          => ! empty( $_POST['yxc_auto_detect'] ),
				'disable_builtin'      => ! empty( $_POST['yxc_disable_builtin'] ),
				'disable_card_builtin' => ! empty( $_POST['yxc_disable_card_builtin'] ),
				'custom_css'           => self::clean_css( $css ),
			),
			false
		);
		// phpcs:enable

		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE_SLUG, 'yxc_notice' => $reset ? 'reset' : 'saved' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public static function render_page() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}

		$settings = self::settings();
		$notice   = isset( $_GET['yxc_notice'] ) ? sanitize_key( wp_unslash( $_GET['yxc_notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display only.
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Custom classes & CSS', 'sevof-connector' ); ?></h1>

			<?php if ( 'saved' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Saved. If your site uses a caching plugin, clear its cache once.', 'sevof-connector' ); ?></p></div>
			<?php elseif ( 'detected' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Your site\'s article styles were checked again.', 'sevof-connector' ); ?></p></div>
			<?php elseif ( 'reset' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Everything is back to the Sevof defaults.', 'sevof-connector' ); ?></p></div>
			<?php endif; ?>

			<p style="max-width:760px;line-height:2">
				<?php esc_html_e( 'Add your theme\'s own classes to each part of Sevof articles and product cards (separate several classes with spaces). They are added when the page is displayed, so already published articles get them without republishing. To show only your theme\'s look, turn off the Sevof default styles.', 'sevof-connector' ); ?>
			</p>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>">
				<?php wp_nonce_field( self::SAVE_ACTION, self::NONCE_FIELD ); ?>

				<?php
				$yxc_detected = self::detected();
				$yxc_labels   = self::elements();
				?>
				<h2><?php esc_html_e( 'Automatic detection from your existing articles', 'sevof-connector' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Automatic detection', 'sevof-connector' ); ?></th>
						<td>
							<label><input type="checkbox" name="yxc_auto_detect" value="1" <?php checked( $settings['auto_detect'] ); ?>> <?php esc_html_e( 'Make Sevof articles look like your own articles (headings, tables and buttons use your theme\'s classes)', 'sevof-connector' ); ?></label>
							<p class="description">
								<?php
								printf(
									/* translators: %d: number of posts */
									esc_html__( 'Based on your %d latest articles (not written by Sevof). Where nothing was detected, the Sevof look is kept. Classes you enter below always take priority over detection.', 'sevof-connector' ),
									(int) $yxc_detected['posts']
								);
								?>
							</p>
							<?php if ( empty( $yxc_detected['elements'] ) ) : ?>
								<p><strong><?php esc_html_e( 'No consistent style was found in your articles, so the Sevof default look is used.', 'sevof-connector' ); ?></strong></p>
							<?php else : ?>
								<ul style="margin:.5rem 0">
									<?php foreach ( $yxc_detected['elements'] as $yxc_key => $yxc_list ) : ?>
										<li><strong><?php echo esc_html( $yxc_labels[ $yxc_key ]['label'] ); ?>:</strong> <code dir="ltr"><?php echo esc_html( implode( ' ', $yxc_list ) ); ?></code></li>
									<?php endforeach; ?>
								</ul>
							<?php endif; ?>
							<button type="submit" name="yxc_do" value="detect" class="button"><?php esc_html_e( 'Detect again', 'sevof-connector' ); ?></button>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'Sevof default styles', 'sevof-connector' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Turn off', 'sevof-connector' ); ?></th>
						<td>
							<label><input type="checkbox" name="yxc_disable_builtin" value="1" <?php checked( $settings['disable_builtin'] ); ?>> <?php esc_html_e( 'Do not print any Sevof styles (articles, product cards, tables and FAQs use only my theme and classes)', 'sevof-connector' ); ?></label><br>
							<label><input type="checkbox" name="yxc_disable_card_builtin" value="1" <?php checked( $settings['disable_card_builtin'] ); ?>> <?php esc_html_e( 'Turn off product card styles only', 'sevof-connector' ); ?></label>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'My classes', 'sevof-connector' ); ?></h2>
				<table class="form-table" role="presentation">
					<?php foreach ( self::elements() as $key => $element ) : ?>
						<tr>
							<th scope="row"><label for="yxc-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $element['label'] ); ?></label></th>
							<td>
								<input type="text" class="regular-text code" dir="ltr" id="yxc-<?php echo esc_attr( $key ); ?>" name="yxc_classes[<?php echo esc_attr( $key ); ?>]"
									value="<?php echo esc_attr( implode( ' ', isset( $settings['classes'][ $key ] ) ? $settings['classes'][ $key ] : array() ) ); ?>" placeholder="my-class another-class">
								<p class="description">
									<?php echo esc_html( isset( $element['token'] ) ? sprintf( /* translators: %s: built-in class */ __( 'Added to the element with the %s class.', 'sevof-connector' ), $element['token'] ) : '' ); ?>
									<?php echo esc_html( $element['hint'] ); ?>
								</p>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>

				<h2><?php esc_html_e( 'Custom CSS', 'sevof-connector' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Printed after the Sevof styles on article and product pages. CSS only, no tags.', 'sevof-connector' ); ?></p>
				<textarea name="yxc_custom_css" rows="12" class="large-text code" dir="ltr" <?php disabled( ! current_user_can( 'edit_css' ) ); ?>
					placeholder=".sevof-product-card { border-radius: 8px; }"><?php echo esc_textarea( $settings['custom_css'] ); ?></textarea>

				<p class="submit">
					<button type="submit" name="yxc_do" value="save" class="button button-primary"><?php esc_html_e( 'Save changes', 'sevof-connector' ); ?></button>
					<button type="submit" name="yxc_do" value="reset" class="button" onclick="return confirm('<?php echo esc_js( __( 'Remove all classes and CSS and go back to the default look?', 'sevof-connector' ) ); ?>');"><?php esc_html_e( 'Reset to defaults', 'sevof-connector' ); ?></button>
				</p>
			</form>
		</div>
		<?php
	}
}
