<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Writes a minimal operational event only when WordPress debug logging is explicitly enabled.
 * Secrets, signatures, request bodies, response bodies, post content, and image payloads are
 * deliberately excluded from logs.
 */
if ( ! function_exists( 'sevof_connector_log' ) ) {
	function sevof_connector_log( string $event, array $context = array() ) {
		if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG || ! defined( 'WP_DEBUG_LOG' ) || ! WP_DEBUG_LOG ) {
			return;
		}

		$allowed_keys = array( 'article_id', 'attachment_id', 'method', 'post_id', 'product_id', 'reason', 'route', 'status_code' );
		$safe_context = array();

		foreach ( $allowed_keys as $key ) {
			if ( ! isset( $context[ $key ] ) || ! is_scalar( $context[ $key ] ) ) {
				continue;
			}

			if ( 'article_id' === $key ) {
				// Regular articles use integer IDs; product articles use string IDs (ULID).
				$safe_context[ $key ] = substr( preg_replace( '/[^A-Za-z0-9_-]/', '', (string) $context[ $key ] ), 0, 64 );
			} elseif ( in_array( $key, array( 'attachment_id', 'post_id', 'product_id', 'status_code' ), true ) ) {
				$safe_context[ $key ] = absint( $context[ $key ] );
			} else {
				$safe_context[ $key ] = sanitize_text_field( (string) $context[ $key ] );
			}
		}

		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- intentional, and only ever runs when the site owner has explicitly enabled WP_DEBUG and WP_DEBUG_LOG.
		error_log( '[Sevof Connector] ' . sanitize_key( $event ) . ' ' . wp_json_encode( $safe_context ) );
	}
}

/**
 * Registers the authenticated REST API used by the Sevof service.
 */
class Sevof_Connector_Rest_Controller {
	const NAMESPACE = 'sevof-connector/v1';
	const MAX_TITLE_LENGTH = 255;
	const MAX_META_LENGTH = 1000;
	const MAX_SECTIONS = 200;
	const MAX_SECTION_CONTENT_BYTES = 100000;
	const MAX_IMAGE_BASE64_BYTES = 8 * 1024 * 1024;
	const MAX_IMAGE_BINARY_BYTES = 5 * 1024 * 1024;
	const MAX_FAQ_SCHEMA_BYTES = 256 * 1024;

	// Gallery images (lead + per-section) and the promotional banner block, added
	// alongside the existing featured-image support.
	const MAX_LEAD_IMAGES = 20;
	const MAX_SECTION_IMAGES = 10;
	// Defensive backstop applied while rendering, independent of the per-field caps
	// above, so a pathological combination of many sections each with images cannot
	// force an unbounded number of Media Library uploads in a single request.
	const MAX_TOTAL_GALLERY_IMAGES = 60;
	const MAX_BANNER_HTML_BYTES = 20 * 1024;
	// Caps how many "already uploaded" image hashes are remembered per post so
	// repeated re-syncs of an article whose images keep changing cannot grow its
	// postmeta without bound.
	const MAX_STORED_IMAGE_HASHES = 150;

	// Category/tags: the Sevof service always resends its full current
	// snapshot (existing tags it picked + any new ones), so a request with
	// 'tags' present always REPLACES the post's tags rather than appending.
	const MAX_TAGS = 20;
	const MAX_TAG_LENGTH = 200;

	const MANAGED_META_KEY = '_sevof_managed';
	const ARTICLE_ID_META_KEY = '_sevof_article_id';
	const GALLERY_IMAGE_MAP_META_KEY = '_sevof_gallery_image_map';
	const BANNER_ID_META_KEY = '_sevof_banner_id';

	// Product articles are standard WordPress posts, but they live in a different
	// Sevof table than regular articles, so their numeric IDs can be identical.
	// The source type keeps the two ID spaces from ever resolving to the same post.
	const SOURCE_TYPE_META_KEY = '_sevof_source_type';
	const SOURCE_TYPE_ARTICLE = 'article';
	const SOURCE_TYPE_PRODUCT_ARTICLE = 'product_article';
	const PRODUCT_SCHEMA_META_KEY = '_sevof_product_schema';
	const MAX_PRODUCT_SCHEMA_BYTES = 262144;

	// Product cards (product articles only). Caps must match the Sevof service
	// (ProductArticlePublishService::MAX_*). 'products' on a section renders the
	// showcase card(s) under that section's heading; top-level 'related_products'
	// renders the "suggested products" block before the FAQ / conclusion.
	const MAX_SECTION_PRODUCTS = 12;
	const MAX_RELATED_PRODUCTS = 24;
	const MAX_PRODUCT_SPECS = 5;

	/**
	 * Registers REST route hooks.
	 */
	public static function init() {
		static $initialized = false;
		if ( $initialized ) {
			return;
		}
		$initialized = true;

		add_action( 'rest_api_init', array( self::class, 'register_routes' ) );
		add_action( 'wp_head', array( self::class, 'print_article_styles' ) );
		add_filter( 'the_content', array( self::class, 'wrap_article_content' ), 99 );
	}

	/**
	 * Wraps the body of connector-managed posts in `.sevof-article-body`.
	 *
	 * The article styles are scoped to this wrapper instead of relying on classes
	 * inside the stored markup. That has two benefits: (1) posts that were already
	 * published (whose markup has no custom classes) are styled immediately, with
	 * no re-sync, and (2) the Gutenberg block markup stays untouched, so the block
	 * editor never reports "unexpected or invalid content".
	 *
	 * @param string $content Post content after the other the_content filters.
	 * @return string
	 */
	public static function wrap_article_content( $content ) {
		if ( ! is_string( $content ) || '' === trim( $content ) ) {
			return $content;
		}

		if ( is_feed() || doing_filter( 'get_the_excerpt' ) || ! is_singular( 'post' ) || ! is_main_query() ) {
			return $content;
		}

		$post_id = (int) get_the_ID();
		if ( $post_id <= 0 || $post_id !== (int) get_queried_object_id() || '1' !== get_post_meta( $post_id, self::MANAGED_META_KEY, true ) ) {
			return $content;
		}

		if ( false !== strpos( $content, 'sevof-article-body' ) ) {
			return $content;
		}

		return '<div class="sevof-article-body">' . $content . '</div>';
	}

	/**
	 * Adds presentation styles only to connector-managed articles.
	 *
	 * The palette is derived from the site's own branding color (block-theme
	 * link color / palette, Elementor global colors, popular theme options or the
	 * Customizer), so articles and product cards blend in with whatever theme the
	 * site uses. Sites with no detectable accent fall back to the original teal.
	 */
	public static function print_article_styles() {
		if ( ! is_singular( 'post' ) || '1' !== get_post_meta( get_queried_object_id(), self::MANAGED_META_KEY, true ) ) {
			return;
		}

		$css = self::branded_css();
		if ( '' === trim( $css ) ) {
			return; // the owner turned the built-in look off ("custom classes & CSS" settings)
		}

		echo '<style id="sevof-connector-article-styles">' . "\n" . $css . "\n</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS built from validated hex/rgba tokens only; tags stripped.
	}

	/**
	 * The full brand-colored stylesheet (article body, FAQ accordion, product cards, tables)
	 * with every palette token resolved from the site's logo / theme accent color.
	 *
	 * Public so the product controller can print the very same look on product pages whose
	 * description has no styling of its own.
	 */
	public static function branded_css(): string {
		$tokens = array();
		foreach ( self::article_style_palette() as $key => $value ) {
			$tokens[ '{{' . $key . '}}' ] = $value;
		}

		$css = wp_strip_all_tags( strtr( self::article_css_template(), $tokens ) );

		/**
		 * Built-in stylesheet. Return '' to print nothing (the owner styles everything with own classes).
		 *
		 * @param string $css Stylesheet with every palette token resolved.
		 */
		return (string) apply_filters( 'sevof_connector_branded_css', $css );
	}

	/**
	 * Stylesheet template. `{{token}}` placeholders are replaced with palette values.
	 */
	private static function article_css_template(): string {
		return <<<'CSS'
/* ---------- Article body ---------- */
.sevof-article-body{text-align:start;color:{{paragraph_text}};font-size:1.05rem;line-height:2.1}
body .sevof-article-body>p{margin:0 0 1.2rem!important;color:{{paragraph_text}}!important;font-size:1.05rem!important;line-height:2.15!important;text-align:justify;text-justify:inter-word}
body .sevof-article-body>h2{position:relative;margin:2.4rem 0 1.1rem!important;padding:.85rem 1.1rem!important;padding-inline-start:1.25rem!important;border:0!important;border-inline-start:5px solid {{primary}}!important;border-radius:0!important;border-start-end-radius:14px!important;border-end-end-radius:14px!important;background:linear-gradient(90deg,{{wash_strong}},{{wash_soft}})!important;color:{{heading_text}}!important;font-size:clamp(1.3rem,2.2vw,1.9rem)!important;font-weight:800!important;line-height:1.7!important;text-align:start!important}
body .sevof-article-body>h3{margin:1.9rem 0 .8rem!important;padding:0!important;padding-inline-start:.95rem!important;border:0!important;border-inline-start:3px solid {{primary}}!important;color:{{h3_text}}!important;font-size:clamp(1.12rem,1.7vw,1.4rem)!important;font-weight:800!important;line-height:1.8!important;text-align:start!important}
body .sevof-article-body>h4,body .sevof-article-body>h5,body .sevof-article-body>h6{margin:1.5rem 0 .6rem!important;color:{{heading_text}}!important;font-size:1.1rem!important;font-weight:800!important;line-height:1.8!important;text-align:start!important}
body .sevof-article-body :is(strong,b){color:{{heading_text}}}
body .sevof-article-body :is(p,li,blockquote) a:not(.sevof-product-cta){color:{{primary_text}}!important;font-weight:700;text-decoration:underline!important;text-decoration-color:{{link_underline}}!important;text-decoration-thickness:2px!important;text-underline-offset:5px!important;transition:text-decoration-color .15s}
body .sevof-article-body :is(p,li,blockquote) a:not(.sevof-product-cta):hover{text-decoration-color:{{primary}}!important}
body .sevof-article-body>ul,body .sevof-article-body>ol{margin:1.2rem 0 1.7rem!important;padding:1rem 1.25rem!important;list-style:none!important;border:1px solid {{list_border}}!important;border-radius:16px!important;background:{{list_bg}}!important;line-height:2!important;counter-reset:yxli}
body .sevof-article-body>ul>li,body .sevof-article-body>ol>li{position:relative;margin:0!important;padding:.15rem 0!important;padding-inline-start:2.1rem!important;color:{{paragraph_text}}!important;list-style:none!important}
body .sevof-article-body>ul>li::before{content:"";position:absolute;inset-inline-start:.45rem;top:1.12rem;width:.55rem;height:.55rem;border-radius:50%;background:{{primary}}}
body .sevof-article-body>ol>li{counter-increment:yxli}
body .sevof-article-body>ol>li::before{content:counter(yxli);position:absolute;inset-inline-start:0;top:.62rem;width:1.55rem;height:1.55rem;border-radius:50%;background:{{icon_bg}};color:{{primary_text}};font-size:.82rem;font-weight:800;line-height:1.55rem;text-align:center}
body .sevof-article-body>blockquote{position:relative;margin:1.7rem 0!important;padding:1.1rem 1.5rem!important;border:0!important;border-inline-start:4px solid {{primary}}!important;border-radius:14px!important;background:{{list_bg}}!important;color:{{heading_text}}!important;font-style:normal!important;line-height:2!important}
body .sevof-article-body>blockquote p{margin:0!important;color:inherit!important;line-height:2!important}
body .sevof-article-body>hr{height:2px;margin:2.6rem 0!important;border:0!important;background:linear-gradient(90deg,transparent,{{list_border}},transparent)!important}
body .sevof-article-body figure.wp-block-image,body .sevof-article-body>figure{margin:2rem auto!important;max-width:100%;text-align:center}
body .sevof-article-body figure.wp-block-image img,body .sevof-article-body>figure img{display:inline-block;height:auto;max-width:100%;border-radius:16px;box-shadow:0 12px 30px {{shadow}}}
body .sevof-article-body figcaption{margin-top:.7rem;color:{{muted}};font-size:.88rem;text-align:center}

/* ---------- FAQ accordion ---------- */
.sevof-faq{margin:2.5rem 0!important;padding:1.25rem!important;border:1px solid {{faq_border}}!important;border-radius:18px!important;background:linear-gradient(180deg,{{faq_bg_top}},{{faq_bg_bottom}})!important}
.sevof-faq-title{margin:0 0 1rem!important;padding:0 0 .75rem!important;border-bottom:2px solid {{faq_title_border}}!important;color:{{faq_title_text}}!important;font-size:1.5rem!important;font-weight:800!important}
.sevof-faq-item,.entry-content details:has(> summary),.wp-block-html details:has(> summary){margin:.7rem 0!important;border:1px solid {{faq_item_border}}!important;border-radius:12px!important;background:#fff!important;overflow:hidden!important}
.sevof-faq-item>summary,.entry-content details:has(> summary)>summary,.wp-block-html details:has(> summary)>summary{position:relative!important;display:block!important;cursor:pointer!important;padding:1rem 1.15rem!important;padding-inline-start:3rem!important;color:{{faq_title_text}}!important;font-weight:700!important;line-height:1.8!important;list-style:none!important;text-align:start!important}
.sevof-faq-item>summary::-webkit-details-marker,.entry-content details>summary::-webkit-details-marker,.wp-block-html details>summary::-webkit-details-marker{display:none!important}
.sevof-faq-item>summary::after,.entry-content details:has(> summary)>summary::after,.wp-block-html details:has(> summary)>summary::after{content:'+';position:absolute!important;inset-inline-start:1rem!important;top:1rem!important;width:1.25rem!important;height:1.25rem!important;border-radius:50%!important;background:{{icon_bg}}!important;color:{{primary_text}}!important;text-align:center!important;line-height:1.25!important;font-size:1.15rem!important}
.sevof-faq-item[open]>summary::after,.entry-content details[open]:has(> summary)>summary::after,.wp-block-html details[open]:has(> summary)>summary::after{content:'−';background:{{primary}}!important;color:{{cta_text}}!important}
.sevof-faq-answer,.entry-content details:has(> summary)>*:not(summary),.wp-block-html details:has(> summary)>*:not(summary){padding:0 1.15rem 1rem!important;color:{{faq_answer_text}}!important;line-height:2!important;border-top:1px solid {{faq_answer_border}}!important}

/* ---------- Product cards ---------- */
.sevof-products{display:grid!important;grid-template-columns:minmax(0,1fr)!important;gap:1.35rem!important;margin:1.6rem 0 2.2rem!important;text-align:start!important}
.sevof-products.is-multi{grid-template-columns:repeat(auto-fit,minmax(min(100%,235px),1fr))!important}
.sevof-product-card{position:relative!important;display:flex!important;flex-direction:row!important;align-items:stretch!important;gap:0!important;margin:0!important;padding:0!important;border:1px solid {{card_border}}!important;border-radius:22px!important;background:#fff!important;box-shadow:0 1px 2px {{shadow_soft}},0 14px 34px -16px {{shadow}}!important;overflow:hidden!important;box-sizing:border-box!important;transition:transform .2s ease,box-shadow .2s ease,border-color .2s ease}
.sevof-product-card:hover{transform:translateY(-3px);border-color:{{primary}}!important;box-shadow:0 2px 4px {{shadow_soft}},0 22px 44px -18px {{shadow}}!important}
.sevof-product-media{position:relative!important;flex:0 0 38%!important;display:flex!important;align-items:center!important;justify-content:center!important;min-width:0!important;padding:1.4rem!important;background:linear-gradient(145deg,{{media_bg_a}},{{media_bg_b}})!important;box-sizing:border-box!important}
.sevof-product-media a{display:block!important;width:100%!important;text-align:center!important;text-decoration:none!important}
.sevof-product-media img{display:block!important;margin:0 auto!important;width:auto!important;max-width:100%!important;height:auto!important;max-height:250px!important;object-fit:contain!important;border-radius:14px!important;box-shadow:none!important;transition:transform .3s ease}
.sevof-product-card:hover .sevof-product-media img{transform:scale(1.04)}
.sevof-product-placeholder{display:flex;align-items:center;justify-content:center;width:100%;min-height:150px;font-size:3.6rem;opacity:.6}
.sevof-product-badge{position:absolute!important;top:.85rem!important;inset-inline-start:.85rem!important;z-index:2;padding:.18rem .75rem!important;border-radius:999px!important;background:#e11d48!important;color:#fff!important;font-size:.78rem!important;font-weight:800!important;line-height:1.9!important;box-shadow:0 6px 14px -6px rgba(225,29,72,.7)}
.sevof-product-body{flex:1 1 auto!important;display:flex!important;flex-direction:column!important;gap:.75rem!important;min-width:0!important;padding:1.35rem 1.5rem!important;box-sizing:border-box!important}
.sevof-product-cat{align-self:flex-start;margin:0!important;padding:.1rem .7rem!important;border-radius:999px;background:{{icon_bg}};color:{{primary_text}}!important;font-size:.78rem!important;font-weight:700!important;line-height:1.9!important}
.sevof-product-title{margin:0!important;color:{{heading_text}}!important;font-size:1.15rem!important;font-weight:800!important;line-height:1.9!important}
.sevof-product-title a{color:inherit!important;text-decoration:none!important}
.sevof-product-title a:hover{color:{{primary_text}}!important}
.sevof-product-pricing{display:flex!important;flex-wrap:wrap!important;align-items:center!important;gap:.35rem .9rem!important}
.sevof-product-price{color:{{primary_text}}!important;font-size:1.4rem!important;font-weight:800!important;line-height:1.6!important}
.sevof-product-old-price{color:#8a8a8a!important;font-size:.88rem!important;text-decoration:line-through!important}
.sevof-product-stock{display:inline-flex;align-items:center;gap:.4rem;padding:.1rem .7rem;border-radius:999px;font-size:.78rem!important;font-weight:700!important;line-height:1.9}
.sevof-product-stock::before{content:"";width:.5rem;height:.5rem;border-radius:50%;background:currentColor}
.sevof-product-stock.is-in{background:#d1fae5;color:#047857!important}
.sevof-product-stock.is-out{background:#fee2e2;color:#b91c1c!important}
.sevof-product-specs{display:grid!important;gap:.45rem!important;margin:0!important;padding:.9rem 0 0!important;border-top:1px dashed {{list_border}}!important}
.sevof-product-spec{display:flex!important;align-items:baseline!important;gap:.5rem!important;margin:0!important;font-size:.92rem!important;line-height:1.8!important}
.sevof-product-spec dt{flex:0 0 auto!important;margin:0!important;color:{{muted}}!important}
.sevof-product-spec .sevof-product-dots{flex:1 1 auto!important;min-width:.75rem!important;border-bottom:1px dotted {{list_border}}!important}
.sevof-product-spec dd{max-width:60%!important;margin:0!important;color:{{paragraph_text}}!important;font-weight:700!important;text-align:end!important}
.sevof-product-excerpt{margin:0!important;color:{{paragraph_text}}!important;font-size:.92rem!important;line-height:2!important}
body a.sevof-product-cta{align-self:flex-start!important;margin-top:auto!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:.5rem!important;padding:.72rem 1.6rem!important;border:0!important;border-radius:13px!important;background:linear-gradient(135deg,{{primary}},{{primary_deep}})!important;color:{{cta_text}}!important;font-size:.95rem!important;font-weight:800!important;line-height:1.6!important;text-decoration:none!important;box-shadow:0 10px 20px -10px {{primary}}!important;transition:transform .15s ease,box-shadow .15s ease,filter .15s ease}
body a.sevof-product-cta:hover{transform:translateY(-1px);filter:brightness(1.07);box-shadow:0 14px 24px -10px {{primary}}!important;color:{{cta_text}}!important}
.sevof-products.is-multi .sevof-product-card{flex-direction:column!important}
.sevof-products.is-multi .sevof-product-media{flex:0 0 auto!important;padding:1.1rem!important}
.sevof-products.is-multi .sevof-product-media img{max-height:200px!important}
.sevof-products.is-multi .sevof-product-body{padding:1.1rem 1.25rem 1.3rem!important}
.sevof-products.is-multi a.sevof-product-cta{align-self:stretch!important;padding:.72rem 1rem!important;font-size:.9rem!important;white-space:nowrap!important}

/* ---------- Tables ---------- */
.sevof-table-wrap{margin:1.5rem 0 2rem!important;overflow-x:auto!important;-webkit-overflow-scrolling:touch;border:1px solid {{faq_border}}!important;border-radius:16px!important;background:#fff!important}
.sevof-table-wrap table.sevof-table{width:100%!important;min-width:520px;margin:0!important;border:0!important;border-collapse:separate!important;border-spacing:0!important;background:transparent!important;font-size:.95rem!important;line-height:1.9!important}
.sevof-table-wrap table.sevof-table th,.sevof-table-wrap table.sevof-table td{border:0!important;border-bottom:1px solid {{list_border}}!important;padding:.8rem 1rem!important;text-align:start!important;vertical-align:top!important;background:transparent!important}
.sevof-table-wrap table.sevof-table thead th{background:{{icon_bg}}!important;border-bottom:2px solid {{primary}}!important;color:{{heading_text}}!important;font-weight:800!important;white-space:nowrap!important}
.sevof-table-wrap table.sevof-table td{color:{{paragraph_text}}!important}
.sevof-table-wrap table.sevof-table tbody tr:nth-child(even) td{background:{{list_bg}}!important}
.sevof-table-wrap table.sevof-table tbody tr:last-child td{border-bottom:0!important}
.sevof-table-wrap table.sevof-table tbody td:first-child{color:{{heading_text}}!important;font-weight:700!important}
.sevof-table-wrap table.sevof-table a{color:{{primary_text}}!important;font-weight:700!important;text-decoration:underline!important;text-underline-offset:3px}

/* ---------- Small screens ---------- */
@media (max-width:640px){
body .sevof-article-body>p{font-size:1rem!important;line-height:2!important;text-align:start}
body .sevof-article-body>h2{margin-top:1.8rem!important}
.sevof-faq{padding:.8rem!important}
.sevof-product-card{flex-direction:column!important}
.sevof-product-media{flex:0 0 auto!important;padding:1.1rem!important}
.sevof-product-body{padding:1.1rem 1.15rem 1.25rem!important}
body a.sevof-product-cta{align-self:stretch!important}
.sevof-products.is-multi{grid-template-columns:minmax(0,1fr)!important}
}
.sevof-product-cta-arrow{display:inline-block}
[dir="rtl"] .sevof-product-cta-arrow{transform:scaleX(-1)}
@media (prefers-reduced-motion:reduce){.sevof-product-card,.sevof-product-card *,body a.sevof-product-cta{transition:none!important}.sevof-product-card:hover{transform:none}}
CSS;
	}

	/**
	 * Builds the full article color palette from the site's own accent color,
	 * computing consistent tonal relationships so the result looks intentional
	 * on any theme rather than swapping in one raw color.
	 */
	private static function article_style_palette(): array {
		static $palette = null;
		if ( null !== $palette ) {
			return $palette;
		}

		$primary = self::detect_theme_accent_color();
		// The accent used for text on a white surface must stay readable even for
		// very light brand colors; fills keep the real brand color.
		$primary_text = self::readable_on_white( $primary );
		$cta_text     = self::contrast_ratio( $primary, '#ffffff' ) >= self::contrast_ratio( $primary, '#111111' ) ? '#ffffff' : '#111111';

		$palette = array(
			'primary'             => $primary,
			'primary_text'        => $primary_text,
			'primary_deep'        => self::mix_hex( $primary, '#000000', 0.22 ),
			'cta_text'            => $cta_text,
			'primary_wash_strong' => self::hex_to_rgba( $primary, 0.06 ),
			'wash_strong'         => self::hex_to_rgba( $primary, 0.08 ),
			'wash_soft'           => self::hex_to_rgba( $primary, 0.015 ),
			'shadow'              => self::hex_to_rgba( self::mix_hex( $primary, '#000000', 0.3 ), 0.22 ),
			'shadow_soft'         => self::hex_to_rgba( self::mix_hex( $primary, '#000000', 0.3 ), 0.06 ),
			'heading_text'        => self::mix_hex( $primary, '#000000', 0.55 ),
			'h3_text'             => self::mix_hex( $primary, '#000000', 0.34 ),
			'paragraph_text'      => self::mix_hex( $primary, '#000000', 0.83 ),
			'muted'               => self::mix_hex( $primary, '#6b7280', 0.7 ),
			'link_underline'      => self::hex_to_rgba( $primary, 0.35 ),
			'list_bg'             => self::mix_hex( $primary, '#ffffff', 0.97 ),
			'list_border'         => self::mix_hex( $primary, '#ffffff', 0.87 ),
			'card_border'         => self::mix_hex( $primary, '#ffffff', 0.84 ),
			'media_bg_a'          => self::mix_hex( $primary, '#ffffff', 0.93 ),
			'media_bg_b'          => self::mix_hex( $primary, '#ffffff', 0.985 ),
			'faq_border'          => self::mix_hex( $primary, '#ffffff', 0.86 ),
			'faq_bg_top'          => self::mix_hex( $primary, '#ffffff', 0.985 ),
			'faq_bg_bottom'       => self::mix_hex( $primary, '#ffffff', 0.96 ),
			'faq_title_border'    => self::mix_hex( $primary, '#ffffff', 0.86 ),
			'faq_title_text'      => self::mix_hex( $primary, '#000000', 0.4 ),
			'faq_item_border'     => self::mix_hex( $primary, '#ffffff', 0.84 ),
			'icon_bg'             => self::mix_hex( $primary, '#ffffff', 0.91 ),
			'faq_answer_text'     => self::mix_hex( $primary, '#000000', 0.67 ),
			'faq_answer_border'   => self::mix_hex( $primary, '#ffffff', 0.94 ),
		);

		// Lets the Settings page (or any code) adjust single tokens. Unchanged when nothing hooks in.
		$filtered = apply_filters( 'sevof_connector_style_palette', $palette, $primary );
		if ( is_array( $filtered ) ) {
			$palette = $filtered;
		}

		return $palette;
	}

	/**
	 * Finds the color that best represents "this site's" branding.
	 *
	 * Sources, strongest first:
	 *  0. The `sevof_connector_accent_color` filter / option (explicit override).
	 *  0b. The site logo (custom logo, block-theme site logo, theme logo
	 *     settings, then the site icon): its dominant brand color, read from the
	 *     image itself (see Sevof_Connector_Logo_Color).
	 *  1. Block themes: the global link color, then well-known palette slugs.
	 *  2. Elementor global colors (primary / accent).
	 *  3. Popular theme options (Astra, GeneratePress, Kadence, OceanWP, Flatsome).
	 *  4. Generic Customizer mods used by many themes.
	 *
	 * Grey/near-black/near-white swatches are skipped when a real brand color is
	 * available; if the logo and theme are genuinely monochrome, the logo's own
	 * (dark/grey) color is used, else the theme's first color.
	 * With nothing detectable the connector's original teal is the fallback.
	 */
	private static function detect_theme_accent_color(): string {
		$fallback = '#2f7d78';

		$forced = self::normalize_hex_color( apply_filters( 'sevof_connector_accent_color', '' ) );
		if ( ! $forced ) {
			$forced = self::normalize_hex_color( get_option( 'sevof_connector_accent_color', '' ) );
		}
		if ( $forced ) {
			return $forced;
		}

		// The logo is the most reliable description of the brand: use its dominant
		// color first. A logo with no real color (black / grey / white only) is kept
		// as a last resort so a colorful theme accent can still win over it.
		$logo = class_exists( 'Sevof_Connector_Logo_Color' ) ? Sevof_Connector_Logo_Color::detect() : null;
		if ( $logo && ! empty( $logo['hex'] ) ) {
			$logo_hex = self::normalize_hex_color( $logo['hex'] );
			if ( $logo_hex && ! empty( $logo['chromatic'] ) ) {
				return $logo_hex;
			}
		} else {
			$logo_hex = null;
		}

		$candidates = array();

		if ( function_exists( 'wp_get_global_settings' ) ) {
			$settings = wp_get_global_settings();
			$palette  = array();
			foreach ( array( 'custom', 'theme' ) as $origin ) {
				if ( ! empty( $settings['color']['palette'][ $origin ] ) && is_array( $settings['color']['palette'][ $origin ] ) ) {
					$palette = array_merge( $palette, $settings['color']['palette'][ $origin ] );
				}
			}
			if ( empty( $palette ) && ! empty( $settings['color']['palette']['default'] ) && is_array( $settings['color']['palette']['default'] ) ) {
				$palette = $settings['color']['palette']['default'];
			}

			$by_slug = array();
			foreach ( $palette as $swatch ) {
				if ( isset( $swatch['slug'], $swatch['color'] ) && is_string( $swatch['slug'] ) ) {
					$by_slug[ $swatch['slug'] ] = $swatch['color'];
				}
			}

			if ( function_exists( 'wp_get_global_styles' ) ) {
				$link = wp_get_global_styles( array( 'elements', 'link', 'color', 'text' ) );
				if ( is_string( $link ) ) {
					if ( preg_match( '~(?:var\(--wp--preset--color--|var:preset\|color\|)([a-z0-9-]+)~i', $link, $m ) && isset( $by_slug[ $m[1] ] ) ) {
						$candidates[] = $by_slug[ $m[1] ];
					} else {
						$candidates[] = $link;
					}
				}
			}

			foreach ( array( 'primary', 'accent', 'accent-1', 'brand', 'theme-primary', 'highlight', 'secondary' ) as $preferred_slug ) {
				if ( isset( $by_slug[ $preferred_slug ] ) ) {
					$candidates[] = $by_slug[ $preferred_slug ];
				}
			}
			foreach ( $by_slug as $slug => $color ) {
				if ( 'contrast' !== $slug && 'base' !== $slug ) {
					$candidates[] = $color;
				}
			}
			if ( isset( $by_slug['contrast'] ) ) {
				$candidates[] = $by_slug['contrast'];
			}
		}

		// Elementor global colors.
		$kit_id = (int) get_option( 'elementor_active_kit' );
		if ( $kit_id > 0 ) {
			$kit = get_post_meta( $kit_id, '_elementor_page_settings', true );
			if ( is_array( $kit ) ) {
				foreach ( array( 'primary', 'accent' ) as $wanted_id ) {
					foreach ( array( 'system_colors', 'custom_colors' ) as $group ) {
						if ( empty( $kit[ $group ] ) || ! is_array( $kit[ $group ] ) ) {
							continue;
						}
						foreach ( $kit[ $group ] as $item ) {
							if ( is_array( $item ) && isset( $item['_id'], $item['color'] ) && $wanted_id === $item['_id'] ) {
								$candidates[] = $item['color'];
							}
						}
					}
				}
			}
		}

		// Popular theme options (best effort; every value is validated as hex).
		$astra = get_option( 'astra-settings' );
		if ( is_array( $astra ) ) {
			foreach ( array( 'theme-color', 'link-color' ) as $key ) {
				if ( isset( $astra[ $key ] ) && is_string( $astra[ $key ] ) ) {
					$candidates[] = $astra[ $key ];
				}
			}
		}
		$gp = get_option( 'generate_settings' );
		if ( is_array( $gp ) && isset( $gp['link_color'] ) && is_string( $gp['link_color'] ) ) {
			$candidates[] = $gp['link_color'];
		}
		$kadence = get_option( 'kadence_global_palette' );
		if ( is_string( $kadence ) ) {
			$kadence = json_decode( $kadence, true );
		}
		if ( is_array( $kadence ) && ! empty( $kadence['palette'] ) && is_array( $kadence['palette'] ) ) {
			foreach ( array_slice( $kadence['palette'], 0, 2 ) as $swatch ) {
				if ( is_array( $swatch ) && isset( $swatch['color'] ) ) {
					$candidates[] = $swatch['color'];
				}
			}
		}

		foreach ( array( 'accent_color', 'link_color', 'primary_color', 'color_primary', 'ocean_primary_color', 'main_color', 'brand_color', 'theme_color', 'primary-color', 'accent' ) as $mod_name ) {
			$candidates[] = get_theme_mod( $mod_name );
		}

		$first_valid = null;
		foreach ( $candidates as $candidate ) {
			$hex = self::normalize_hex_color( $candidate );
			if ( ! $hex ) {
				continue;
			}
			if ( self::is_usable_accent( $hex ) ) {
				return $hex;
			}
			if ( null === $first_valid ) {
				$first_valid = $hex;
			}
		}

		if ( $logo_hex ) {
			return $logo_hex;
		}

		return $first_valid ? $first_valid : $fallback;
	}

	/**
	 * True for colors that read as a brand accent (not grey / near-black / near-white).
	 */
	private static function is_usable_accent( string $hex ): bool {
		list( $s, $l ) = self::rgb_to_sl( self::hex_to_rgb( $hex ) );

		return $s >= 0.2 && $l >= 0.18 && $l <= 0.82;
	}

	/**
	 * @param array $rgb [r,g,b] 0-255.
	 * @return array [saturation, lightness] in 0..1.
	 */
	private static function rgb_to_sl( array $rgb ): array {
		$r   = $rgb[0] / 255;
		$g   = $rgb[1] / 255;
		$b   = $rgb[2] / 255;
		$max = max( $r, $g, $b );
		$min = min( $r, $g, $b );
		$l   = ( $max + $min ) / 2;

		if ( $max === $min ) {
			return array( 0.0, $l );
		}

		$d = $max - $min;
		$s = $l > 0.5 ? $d / ( 2 - $max - $min ) : $d / ( $max + $min );

		return array( $s, $l );
	}

	private static function relative_luminance( string $hex ): float {
		$channels = array();
		foreach ( self::hex_to_rgb( $hex ) as $value ) {
			$v          = $value / 255;
			$channels[] = $v <= 0.03928 ? $v / 12.92 : pow( ( $v + 0.055 ) / 1.055, 2.4 );
		}

		return 0.2126 * $channels[0] + 0.7152 * $channels[1] + 0.0722 * $channels[2];
	}

	private static function contrast_ratio( string $a, string $b ): float {
		$la = self::relative_luminance( $a );
		$lb = self::relative_luminance( $b );

		return ( max( $la, $lb ) + 0.05 ) / ( min( $la, $lb ) + 0.05 );
	}

	/**
	 * Darkens a color step by step until it reaches the target contrast on white.
	 */
	private static function readable_on_white( string $hex, float $min_ratio = 4.5 ): string {
		for ( $i = 0; $i < 14; $i++ ) {
			if ( self::contrast_ratio( $hex, '#ffffff' ) >= $min_ratio ) {
				break;
			}
			$hex = self::mix_hex( $hex, '#000000', 0.12 );
		}

		return $hex;
	}

	/**
	 * Validates a color string as a 3- or 6-digit hex color (with or without a
	 * leading #, as theme.json swatches and classic theme_mods both occur) and
	 * normalizes it to full "#rrggbb" form. Non-hex values (e.g. a theme using
	 * CSS custom properties or an empty mod) are rejected rather than guessed at.
	 */
	private static function normalize_hex_color( $value ): ?string {
		if ( ! is_string( $value ) || '' === $value ) {
			return null;
		}

		$hex = ltrim( trim( $value ), '#' );

		if ( 3 === strlen( $hex ) && ctype_xdigit( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}

		if ( 6 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
			return null;
		}

		return '#' . strtolower( $hex );
	}

	/**
	 * Mixes a hex color toward a target hex color by $weight (0..1), used to
	 * derive lighter/darker tones of the site's accent color.
	 */
	private static function mix_hex( string $hex, string $target, float $weight ): string {
		$c1     = self::hex_to_rgb( $hex );
		$c2     = self::hex_to_rgb( $target );
		$weight = max( 0.0, min( 1.0, $weight ) );

		$r = (int) round( $c1[0] + ( $c2[0] - $c1[0] ) * $weight );
		$g = (int) round( $c1[1] + ( $c2[1] - $c1[1] ) * $weight );
		$b = (int) round( $c1[2] + ( $c2[2] - $c1[2] ) * $weight );

		return sprintf( '#%02x%02x%02x', $r, $g, $b );
	}

	/**
	 * Renders a hex color as an rgba() string at the given opacity, for the
	 * soft gradient/shadow washes the design uses instead of flat fills.
	 */
	private static function hex_to_rgba( string $hex, float $alpha ): string {
		list( $r, $g, $b ) = self::hex_to_rgb( $hex );
		return sprintf( 'rgba(%d,%d,%d,%s)', $r, $g, $b, rtrim( rtrim( number_format( max( 0.0, min( 1.0, $alpha ) ), 3 ), '0' ), '.' ) );
	}

	/**
	 * Parses a 3- or 6-digit hex color into an [r, g, b] triple; falls back to
	 * the connector's default teal for anything malformed so the palette
	 * builder never has to handle invalid color math.
	 */
	private static function hex_to_rgb( string $hex ): array {
		$hex = ltrim( trim( $hex ), '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( 6 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
			$hex = '2f7d78';
		}

		return array( hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ) );
	}

	/**
	 * Registers routes and explicit request argument schemas.
	 */
	public static function register_routes() {
		register_rest_route(
			self::NAMESPACE,
			'/health',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'health' ),
				'permission_callback' => array( self::class, 'verify_signature' ),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/articles',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'publish_article' ),
				'permission_callback' => array( self::class, 'verify_signature' ),
				'args'                => self::article_arguments( true ),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/articles/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( self::class, 'show_article' ),
					'permission_callback' => array( self::class, 'verify_signature' ),
					'args'                => self::post_id_arguments(),
				),
				array(
					'methods'             => 'PUT',
					'callback'            => array( self::class, 'update_article' ),
					'permission_callback' => array( self::class, 'verify_signature' ),
					'args'                => array_merge( self::post_id_arguments(), self::article_arguments( false ) ),
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( self::class, 'delete_article' ),
					'permission_callback' => array( self::class, 'verify_signature' ),
					'args'                => self::post_id_arguments(),
				),
			)
		);
	}

	/**
	 * Verifies the API key, HMAC signature, timestamp, and single-use request fingerprint.
	 */
	public static function verify_signature( WP_REST_Request $request ) {
		$api_key = $request->get_header( 'x-agent-key' );
		$timestamp = $request->get_header( 'x-timestamp' );
		$signature = $request->get_header( 'x-signature' );

		if ( ! is_string( $api_key ) || '' === $api_key || ! is_string( $timestamp ) || '' === $timestamp || ! is_string( $signature ) || '' === $signature ) {
			sevof_connector_log( 'authentication_missing', array( 'method' => $request->get_method(), 'route' => $request->get_route() ) );

			return self::rest_error( 'sevof_unauthorized', __( 'Authentication headers are incomplete.', 'sevof-connector' ), 401 );
		}

		$stored_api_key = (string) get_option( 'sevof_connector_api_key', '' );
		if ( '' === $stored_api_key || ! hash_equals( $stored_api_key, $api_key ) ) {
			sevof_connector_log( 'authentication_api_key_invalid', array( 'method' => $request->get_method(), 'route' => $request->get_route() ) );

			return self::rest_error( 'sevof_unauthorized', __( 'Authentication failed.', 'sevof-connector' ), 401 );
		}

		$method = $request->get_method();
		$path = ltrim( (string) $request->get_route(), '/' );
		$body = (string) $request->get_body();

		if ( ! Sevof_Connector_Signature::verify_incoming( $timestamp, $signature, $body, $method, $path ) ) {
			sevof_connector_log( 'authentication_signature_invalid', array( 'method' => $method, 'route' => $path ) );

			return self::rest_error( 'sevof_unauthorized', __( 'Authentication failed.', 'sevof-connector' ), 401 );
		}

		if ( ! Sevof_Connector_Signature::consume_replay_token( $timestamp, $signature ) ) {
			sevof_connector_log( 'authentication_replay_rejected', array( 'method' => $method, 'route' => $path ) );

			return self::rest_error( 'sevof_replay_detected', __( 'This request has already been processed.', 'sevof-connector' ), 409 );
		}

		return true;
	}

	/**
	 * Returns the site health response to authenticated service requests.
	 */
	public static function health(): WP_REST_Response {
		return new WP_REST_Response(
			array(
				'wp_version'     => get_bloginfo( 'version' ),
				'plugin_version' => SEVOF_CONNECTOR_VERSION,
				'status'         => 'healthy',
				// Lets the service know which features this plugin build supports.
				'features'       => array(
					'articles'            => true,
					'product_seo'         => true,
					// Product content follows the page: own styling is kept, otherwise logo-branded.
					'product_style_modes' => true,
					'product_faq_schema'  => true,
					// Fields accepted by PUT /products/{id}.
					'product_fields'      => array( 'short_description', 'description', 'meta_title', 'meta_description', 'focus_keyword', 'attributes', 'tags', 'faq', 'image_alts' ),
					// GET/PUT /existing-posts: read and update the site's own (non-Sevof) posts.
					'existing_posts'      => true,
				),
				'woocommerce'    => Sevof_Connector_Product_Controller::is_available(),
			),
			200
		);
	}

	/**
	 * Creates a managed WordPress post, or safely refreshes the existing post for the same article ID.
	 */
	public static function publish_article( WP_REST_Request $request ): WP_REST_Response {
		// Image metadata generation can be expensive on large articles. Give the
		// request enough execution time while keeping all existing validation caps.
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 );
		}

		$source_type = self::resolve_source_type( $request );
		$article_id = self::normalize_article_id( $request->get_param( 'article_id' ), $source_type );
		$existing_post_id = self::find_post_by_article_id( $article_id, $source_type );

		if ( $existing_post_id ) {
			try {
				$result = self::update_existing_article( $existing_post_id, $request, true );
			} catch ( Throwable $e ) {
				return self::internal_error_response( 'article_update_exception', $e, $article_id, $existing_post_id );
			}
			if ( is_wp_error( $result ) ) {
				sevof_connector_log( 'article_create_idempotent_update_failed', array( 'article_id' => $article_id, 'post_id' => $existing_post_id ) );

				return new WP_REST_Response( array( 'message' => __( 'The existing article could not be updated.', 'sevof-connector' ) ), 422 );
			}

			sevof_connector_log( 'article_create_idempotent', array( 'article_id' => $article_id, 'post_id' => $existing_post_id ) );

			return self::article_response( $existing_post_id );
		}

		$insert_args = array(
			'post_title'   => sanitize_text_field( (string) $request->get_param( 'title' ) ),
			// Left empty here on purpose: the real body is built by sync_post_content()
			// below, once $post_id exists, so any gallery images in it can be uploaded
			// with the correct attachment parent and embedded by a resolved Media
			// Library URL rather than needing the post to already exist beforehand.
			'post_content' => '',
			'post_excerpt' => sanitize_text_field( (string) $request->get_param( 'meta_description' ) ),
			'post_status'  => self::validated_status( $request->get_param( 'post_status' ) ),
			'post_type'    => 'post',
		);

		if ( $request->has_param( 'slug' ) && '' !== (string) $request->get_param( 'slug' ) ) {
			$insert_args['post_name'] = sanitize_title( (string) $request->get_param( 'slug' ) );
		}

		$post_id = wp_insert_post( $insert_args, true );
		if ( is_wp_error( $post_id ) ) {
			sevof_connector_log( 'article_create_failed', array( 'article_id' => $article_id ) );

			return new WP_REST_Response( array( 'message' => __( 'The article could not be created.', 'sevof-connector' ) ), 422 );
		}

		update_post_meta( $post_id, self::ARTICLE_ID_META_KEY, $article_id );
		update_post_meta( $post_id, self::SOURCE_TYPE_META_KEY, $source_type );
		update_post_meta( $post_id, self::MANAGED_META_KEY, '1' );
		update_post_meta( $post_id, '_sevof_last_action', 'created' );
		update_post_meta( $post_id, '_sevof_connectored_at', current_time( 'mysql' ) );

		try {
			self::attach_featured_image( $post_id, $request->get_param( 'featured_image' ) );
			self::sync_post_content( $post_id, $request );
			self::save_seo_meta( $post_id, $request );
			self::sync_taxonomy( $post_id, $request );
		} catch ( Throwable $e ) {
			return self::internal_error_response( 'article_publish_exception', $e, $article_id, $post_id );
		}
		sevof_connector_log( 'article_created', array( 'article_id' => $article_id, 'post_id' => $post_id ) );

		return self::article_response( $post_id );
	}

	/**
	 * Updates only a managed post. Fields not present in the request remain unchanged.
	 */
	public static function update_article( WP_REST_Request $request ): WP_REST_Response {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 );
		}

		$post_id = absint( $request->get_param( 'id' ) );
		$post = self::get_managed_post( $post_id );

		if ( ! $post ) {
			return self::not_found_response();
		}

		try {
			$result = self::update_existing_article( $post_id, $request, false );
		} catch ( Throwable $e ) {
			return self::internal_error_response( 'article_update_exception', $e, (string) get_post_meta( $post_id, self::ARTICLE_ID_META_KEY, true ), $post_id );
		}
		if ( is_wp_error( $result ) ) {
			sevof_connector_log( 'article_update_failed', array( 'post_id' => $post_id ) );

			return new WP_REST_Response( array( 'message' => __( 'The article could not be updated.', 'sevof-connector' ) ), 422 );
		}

		sevof_connector_log( 'article_updated', array( 'post_id' => $post_id ) );

		return self::article_response( $post_id );
	}

	/**
	 * Returns only a post that was created by this connector.
	 */
	public static function show_article( WP_REST_Request $request ): WP_REST_Response {
		$post_id = absint( $request->get_param( 'id' ) );
		if ( ! self::get_managed_post( $post_id ) ) {
			return self::not_found_response();
		}

		return self::article_response( $post_id );
	}

	/**
	 * Moves only a connector-managed post to the WordPress trash.
	 */
	public static function delete_article( WP_REST_Request $request ): WP_REST_Response {
		$post_id = absint( $request->get_param( 'id' ) );
		if ( ! self::get_managed_post( $post_id ) ) {
			return self::not_found_response();
		}

		$trashed = wp_trash_post( $post_id );
		if ( ! $trashed ) {
			sevof_connector_log( 'article_delete_failed', array( 'post_id' => $post_id ) );

			return new WP_REST_Response( array( 'message' => __( 'The article could not be moved to the trash.', 'sevof-connector' ) ), 500 );
		}

		update_post_meta( $post_id, '_sevof_last_action', 'deleted' );
		update_post_meta( $post_id, '_sevof_connectored_at', current_time( 'mysql' ) );
		sevof_connector_log( 'article_deleted', array( 'post_id' => $post_id ) );

		return new WP_REST_Response(
			array(
				'message'    => __( 'The article was moved to the trash.', 'sevof-connector' ),
				'wp_post_id' => $post_id,
			),
			200
		);
	}

	private static function update_existing_article( int $post_id, WP_REST_Request $request, bool $from_create ) {
		$update_args = array( 'ID' => $post_id );

		if ( $request->has_param( 'title' ) ) {
			$update_args['post_title'] = sanitize_text_field( (string) $request->get_param( 'title' ) );
		}

		// post_content is intentionally not set here - it is rebuilt by
		// sync_post_content() below, after any gallery images/banner for this request
		// have been uploaded and resolved to Media Library URLs.

		if ( $request->has_param( 'meta_description' ) ) {
			$update_args['post_excerpt'] = sanitize_text_field( (string) $request->get_param( 'meta_description' ) );
		}

		if ( $request->has_param( 'post_status' ) ) {
			$update_args['post_status'] = self::validated_status( $request->get_param( 'post_status' ) );
		}

		if ( $request->has_param( 'slug' ) && '' !== (string) $request->get_param( 'slug' ) ) {
			$update_args['post_name'] = sanitize_title( (string) $request->get_param( 'slug' ) );
		}

		if ( count( $update_args ) > 1 ) {
			$result = wp_update_post( $update_args, true );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		update_post_meta( $post_id, self::MANAGED_META_KEY, '1' );
		update_post_meta( $post_id, '_sevof_last_action', $from_create ? 'created' : 'updated' );
		update_post_meta( $post_id, '_sevof_connectored_at', current_time( 'mysql' ) );

		if ( $request->has_param( 'featured_image' ) ) {
			self::attach_featured_image( $post_id, $request->get_param( 'featured_image' ) );
		}

		self::sync_post_content( $post_id, $request );
		self::save_seo_meta( $post_id, $request );
		self::sync_taxonomy( $post_id, $request );

		return true;
	}

	/**
	 * Applies category/tags only for the fields actually present in the request, so a
	 * partial (metadata-only) update that omits them never touches the post's
	 * existing category or tags.
	 *
		 * - 'category_id' sets a single primary category when the term exists locally;
		 *   stale/deleted IDs are ignored without failing the article request.
	 * - 'tags' REPLACES the full tag set (append = false) rather than merging, since
	 *   the Sevof service always resends its complete current tag snapshot
	 *   (existing tags it kept + any new ones) alongside 'content'. wp_set_post_tags()
	 *   is given plain tag names: WordPress itself reuses any tag that already
	 *   exists with that name and creates any that do not, so no separate "create
	 *   tag" step or tag ID bookkeeping is needed on this side.
	 */
		private static function sync_taxonomy( int $post_id, WP_REST_Request $request ) {
			if ( $request->has_param( 'category_id' ) ) {
				$category_id = absint( $request->get_param( 'category_id' ) );

				// Taxonomy synchronization is best-effort. A stale/deleted category ID
				// must never prevent the article itself from being published.
				$category = $category_id > 0 ? get_term( $category_id, 'category' ) : null;
				if ( $category instanceof WP_Term && ! is_wp_error( $category ) ) {
					$result = wp_set_post_categories( $post_id, array( $category_id ) );

				if ( is_wp_error( $result ) ) {
					sevof_connector_log( 'article_category_sync_failed', array( 'post_id' => $post_id ) );
				}
			}
		}

			if ( $request->has_param( 'tags' ) ) {
				$tags = $request->get_param( 'tags' );
				// A malformed optional tags value must not erase existing tags.
				if ( ! is_array( $tags ) ) {
					return;
				}

			$tag_names = array();
				foreach ( $tags as $tag ) {
				if ( ! is_string( $tag ) ) {
					continue;
				}

				$clean = sanitize_text_field( $tag );
				if ( '' !== trim( $clean ) ) {
					$tag_names[] = $clean;
				}
				}
				$tag_names = array_slice( array_values( array_unique( $tag_names ) ), 0, self::MAX_TAGS );

			$result = wp_set_post_tags( $post_id, $tag_names, false );

			if ( is_wp_error( $result ) ) {
				sevof_connector_log( 'article_tags_sync_failed', array( 'post_id' => $post_id ) );
			}
		}
	}

	/**
	 * Rebuilds post_content from the section list - but only when 'content' is present
	 * in the request. lead_images/banner are only meaningful alongside a fresh content
	 * array; a request that omits 'content' entirely (a partial, metadata-only update)
	 * must not touch the previously synced body or its embedded gallery/banner blocks.
	 *
	 * When 'content' IS present, lead_images/banner reflect exactly what was sent
	 * alongside it - including "not sent", which means "no longer present" - since the
	 * Sevof service always resends its full current snapshot together with 'content'.
	 */
	private static function sync_post_content( int $post_id, WP_REST_Request $request ) {
		if ( ! $request->has_param( 'content' ) ) {
			return;
		}

		$sections = $request->get_param( 'content' );
		$sections = is_array( $sections ) ? $sections : array();

		$lead_images = $request->get_param( 'lead_images' );
		$lead_images = is_array( $lead_images ) ? $lead_images : array();

		$banner = $request->get_param( 'banner' );
		$banner = is_array( $banner ) ? $banner : null;

		if ( $banner && isset( $banner['id'] ) && is_numeric( $banner['id'] ) ) {
			update_post_meta( $post_id, self::BANNER_ID_META_KEY, absint( $banner['id'] ) );
		} else {
			delete_post_meta( $post_id, self::BANNER_ID_META_KEY );
		}

		$faq_html = '';
		if ( $request->has_param( 'faq_schema' ) ) {
			$faq_html = self::render_faq_accordion( $request->get_param( 'faq_schema' ) );
		}

		// "Suggested products": product articles only; products that were not shown
		// under any section. Placed by build_content() right before the FAQ /
		// conclusion. Omitted from the request => no block (full snapshot semantics).
		$related_html = '';
		$related      = $request->get_param( 'related_products' );
		if ( is_array( $related ) && ! empty( $related ) ) {
			$related_cards = self::render_product_cards( $related, self::MAX_RELATED_PRODUCTS );
			if ( '' !== $related_cards ) {
				$related_html = self::heading_block( __( 'Suggested products', 'sevof-connector' ) ) . "\n\n" . $related_cards;
			}
		}

		// The styled FAQ accordion is placed by build_content(): once, right before
		// the conclusion section, replacing any plain-text FAQ section the service sent.
		$structured_lists = array( $related );
		foreach ( $sections as $section ) {
			if ( is_array( $section ) && ! empty( $section['products'] ) && is_array( $section['products'] ) ) {
				$structured_lists[] = $section['products'];
			}
		}
		self::reset_link_card_state( $structured_lists );

		$content_html = self::build_content( $post_id, $sections, $lead_images, $banner, $faq_html, $related_html );
		$content_html = self::group_adjacent_auto_cards( $content_html );

		$result = wp_update_post( array( 'ID' => $post_id, 'post_content' => $content_html ), true );
		if ( is_wp_error( $result ) ) {
			sevof_connector_log( 'article_content_sync_failed', array( 'post_id' => $post_id ) );
		}
	}

	/**
	 * Returns the post's current category id and tags (as {id,name} pairs) so
	 * the calling service can persist the *actual* WordPress state back into
	 * its own database - in particular the real term id for any tag that was
	 * just created for the first time by sync_taxonomy() above.
	 */
	private static function article_response( int $post_id ): WP_REST_Response {
		$post = get_post( $post_id );
		$featured_image_url = has_post_thumbnail( $post_id ) ? get_the_post_thumbnail_url( $post_id, 'full' ) : null;

		$category_ids = wp_get_post_categories( $post_id, array( 'fields' => 'ids' ) );
		$category_id  = ( is_array( $category_ids ) && isset( $category_ids[0] ) ) ? (int) $category_ids[0] : null;

		$tag_terms = wp_get_post_tags( $post_id, array( 'fields' => 'all' ) );
		$tags      = array();

		if ( is_array( $tag_terms ) ) {
			foreach ( $tag_terms as $term ) {
				if ( $term instanceof WP_Term ) {
					$tags[] = array(
						'id'   => (int) $term->term_id,
						'name' => $term->name,
					);
				}
			}
		}

		return new WP_REST_Response(
			array(
				'wp_post_id'         => $post_id,
				'permalink'          => get_permalink( $post_id ),
				'status'             => $post ? $post->post_status : '',
				'featured_image_url' => $featured_image_url ? $featured_image_url : null,
				'category_id'        => $category_id,
				'tags'               => $tags,
			),
			200
		);
	}

	/**
	 * Validates an image payload, detects the actual image type, and adds it to the
	 * Media Library. Shares its decode/type-sniffing and upload/attachment logic with
	 * the gallery-image path (see decode_and_validate_image_binary() and
	 * upload_binary_to_media_library()) so both go through the exact same checks.
	 */
	private static function attach_featured_image( int $post_id, $image ) {
		if ( empty( $image ) ) {
			return;
		}

		if ( ! is_array( $image ) || empty( $image['base64'] ) || ! is_string( $image['base64'] ) ) {
			sevof_connector_log( 'image_payload_invalid', array( 'post_id' => $post_id ) );

			return;
		}

		$decoded = self::decode_and_validate_image_binary( $image['base64'] );
		if ( is_wp_error( $decoded ) ) {
			sevof_connector_log( $decoded->get_error_code(), array( 'post_id' => $post_id ) );

			return;
		}

		$hash = hash( 'sha256', $decoded['binary'] );
		$existing_hash = (string) get_post_meta( $post_id, '_sevof_image_hash', true );

		if ( hash_equals( $existing_hash, $hash ) && has_post_thumbnail( $post_id ) ) {
			return;
		}

		$filename_stem = isset( $image['filename'] ) ? (string) $image['filename'] : 'sevof-' . $post_id;
		$attachment_id = self::upload_binary_to_media_library( $post_id, $decoded, $filename_stem );

		if ( is_wp_error( $attachment_id ) ) {
			sevof_connector_log( $attachment_id->get_error_code(), array( 'post_id' => $post_id ) );

			return;
		}

		set_post_thumbnail( $post_id, $attachment_id );

		if ( isset( $image['alt'] ) && is_string( $image['alt'] ) ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $image['alt'] ) );
		}

		update_post_meta( $post_id, '_sevof_image_hash', $hash );
		update_post_meta( $post_id, '_sevof_featured_image_id', $attachment_id );
		sevof_connector_log( 'image_attached', array( 'attachment_id' => $attachment_id, 'post_id' => $post_id ) );
	}

	/**
	 * Decodes and validates a base64 image payload: size limits, base64 decoding, and
	 * detecting the real image type by sniffing its bytes (never trusting a claimed
	 * MIME type). Shared by the featured-image and gallery-image paths.
	 *
	 * @return array{binary:string,mime:string,ext:string}|WP_Error
	 */
	private static function decode_and_validate_image_binary( string $base64 ) {
		$base64 = self::normalize_image_base64( $base64 );

		if ( '' === $base64 ) {
			return new WP_Error( 'image_payload_invalid' );
		}

		if ( strlen( $base64 ) > self::MAX_IMAGE_BASE64_BYTES ) {
			return new WP_Error( 'image_payload_too_large' );
		}

		$binary = base64_decode( $base64, true );
		if ( false === $binary || '' === $binary || strlen( $binary ) > self::MAX_IMAGE_BINARY_BYTES ) {
			return new WP_Error( 'image_decode_rejected' );
		}

		$image_info = getimagesizefromstring( $binary );
		$mime_to_extension = array(
			'image/jpeg' => 'jpg',
			'image/png'  => 'png',
			'image/gif'  => 'gif',
			'image/webp' => 'webp',
		);
		$detected_mime = is_array( $image_info ) && isset( $image_info['mime'] ) ? $image_info['mime'] : '';

		if ( ! isset( $mime_to_extension[ $detected_mime ] ) ) {
			return new WP_Error( 'image_mime_rejected' );
		}

		return array(
			'binary' => $binary,
			'mime'   => $detected_mime,
			'ext'    => $mime_to_extension[ $detected_mime ],
		);
	}

	/**
	 * Turns decoded, type-verified image bytes into a Media Library attachment
	 * belonging to $post_id. Shared by the featured-image and gallery-image paths.
	 *
	 * @param array{binary:string,mime:string,ext:string} $decoded Output of decode_and_validate_image_binary().
	 *
	 * @return int|WP_Error Attachment ID on success.
	 */
	private static function upload_binary_to_media_library( int $post_id, array $decoded, string $filename_stem ) {
		$wordpress_mimes = array(
			'jpg|jpeg|jpe' => 'image/jpeg',
			'png'          => 'image/png',
			'gif'          => 'image/gif',
			'webp'         => 'image/webp',
		);

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		// WordPress image sub-sizes can require substantially more memory than the
		// original file. Ask core for its image-processing budget before generating
		// metadata; this is a no-op on older/core-compatible installations.
		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'image' );
		}

		$filename_stem = pathinfo( sanitize_file_name( $filename_stem ), PATHINFO_FILENAME );
		if ( '' === $filename_stem ) {
			$filename_stem = 'sevof-' . $post_id . '-' . wp_generate_password( 6, false );
		}
		$filename = sanitize_file_name( $filename_stem ) . '.' . $decoded['ext'];

		$upload = wp_upload_bits( $filename, null, $decoded['binary'] );
		if ( ! empty( $upload['error'] ) || empty( $upload['file'] ) ) {
			return new WP_Error( 'image_upload_failed' );
		}

		$filetype = wp_check_filetype_and_ext( $upload['file'], $filename, $wordpress_mimes );
		if ( empty( $filetype['ext'] ) || empty( $filetype['type'] ) || $filetype['type'] !== $decoded['mime'] ) {
			wp_delete_file( $upload['file'] );

			return new WP_Error( 'image_filetype_rejected' );
		}

		// Do not require GD/Imagick here. The original, type-validated file can
		// be stored and displayed even when the host cannot create sub-sizes.
		// Thumbnail generation is attempted below but is explicitly best-effort.

		$attachment = array(
			'post_mime_type' => $decoded['mime'],
			'post_title'     => sanitize_text_field( $filename_stem ),
			'post_content'   => '',
			'post_status'    => 'inherit',
		);
		$attachment_id = wp_insert_attachment( $attachment, $upload['file'], $post_id, true );

		if ( is_wp_error( $attachment_id ) ) {
			wp_delete_file( $upload['file'] );

			return new WP_Error( 'image_attachment_failed' );
		}

		if ( ! class_exists( 'DOMDocument' ) ) {
			// Never call WordPress's metadata generator on a host without DOM/XML;
			// some core versions instantiate DOMDocument internally. The original
			// attachment is already valid and is enough for featured/gallery output.
			sevof_connector_log(
				'image_metadata_skipped_no_dom',
				array( 'attachment_id' => $attachment_id )
			);

			return $attachment_id;
		}

		try {
			$attachment_data = wp_generate_attachment_metadata( $attachment_id, $upload['file'] );
		} catch ( Throwable $e ) {
			// Some hosts lack PHP DOM/XML and WordPress can throw while generating
			// image sub-size metadata. Keep the original attachment and continue:
			// the article can still publish with its full-size image URL.
			sevof_connector_log(
				'image_metadata_skipped',
				array(
					'attachment_id' => $attachment_id,
					'reason'        => $e->getMessage(),
					'file'          => $e->getFile(),
					'line'          => $e->getLine(),
				)
			);

			return $attachment_id;
		}

		if ( is_wp_error( $attachment_data ) ) {
			wp_delete_attachment( $attachment_id, true );

			return new WP_Error( 'image_metadata_failed' );
		}

		try {
			wp_update_attachment_metadata( $attachment_id, $attachment_data );
		} catch ( Throwable $e ) {
			sevof_connector_log(
				'image_metadata_update_skipped',
				array(
					'attachment_id' => $attachment_id,
					'reason'        => $e->getMessage(),
					'file'          => $e->getFile(),
					'line'          => $e->getLine(),
				)
			);
		}

		return $attachment_id;
	}

	/**
	 * Saves only SEO fields that are explicitly present in a request so partial updates cannot erase data.
	 */
	private static function save_seo_meta( int $post_id, WP_REST_Request $request ) {
		$meta_fields = array(
			'_sevof_meta_title'      => 'meta_title',
			'_sevof_meta_description' => 'meta_description',
			'_sevof_og_title'         => 'og_title',
			'_sevof_og_description'   => 'og_description',
			'_sevof_focus_keyword'    => 'focus_keyword',
		);

		$third_party_values = array();

		foreach ( $meta_fields as $meta_key => $request_key ) {
			if ( $request->has_param( $request_key ) ) {
				$value = sanitize_text_field( (string) $request->get_param( $request_key ) );
				update_post_meta( $post_id, $meta_key, $value );
				$third_party_values[ $request_key ] = $value;
			}
		}

		if ( $request->has_param( 'meta_title' ) && ! $request->has_param( 'og_title' ) ) {
			$fallback_og_title = sanitize_text_field( (string) $request->get_param( 'meta_title' ) );
			update_post_meta( $post_id, '_sevof_og_title', $fallback_og_title );
			$third_party_values['og_title'] = $fallback_og_title;
		}

		if ( $request->has_param( 'meta_description' ) && ! $request->has_param( 'og_description' ) ) {
			$fallback_og_description = sanitize_text_field( (string) $request->get_param( 'meta_description' ) );
			update_post_meta( $post_id, '_sevof_og_description', $fallback_og_description );
			$third_party_values['og_description'] = $fallback_og_description;
		}

		if ( ! empty( $third_party_values ) ) {
			Sevof_Connector_Seo::sync_third_party_meta( $post_id, $third_party_values );
		}

		if ( $request->has_param( 'faq_schema' ) ) {
			$faq_schema = $request->get_param( 'faq_schema' );
			if ( is_array( $faq_schema ) ) {
				$faq_schema = wp_json_encode( $faq_schema, JSON_UNESCAPED_UNICODE );
			}

			if ( is_string( $faq_schema ) && '' !== $faq_schema ) {
				// update_post_meta() strips slashes, which would corrupt the JSON escapes (\" and \\) stored here.
				update_post_meta( $post_id, '_sevof_faq_schema', wp_slash( $faq_schema ) );
			} else {
				delete_post_meta( $post_id, '_sevof_faq_schema' );
			}
		}

		if ( $request->has_param( 'product_schema' ) ) {
			$product_schema = $request->get_param( 'product_schema' );
			if ( is_array( $product_schema ) ) {
				$product_schema = wp_json_encode( $product_schema, JSON_UNESCAPED_UNICODE );
			}

			if ( is_string( $product_schema ) && '' !== $product_schema ) {
				update_post_meta( $post_id, self::PRODUCT_SCHEMA_META_KEY, wp_slash( $product_schema ) );
			} else {
				delete_post_meta( $post_id, self::PRODUCT_SCHEMA_META_KEY );
			}
		}
	}

	/**
	 * Reads the content source from the request. Anything other than the explicit
	 * product_article value is a regular article, so existing Laravel payloads
	 * (which send no source_type) keep their current behavior.
	 */
	private static function resolve_source_type( WP_REST_Request $request ): string {
		return self::SOURCE_TYPE_PRODUCT_ARTICLE === $request->get_param( 'source_type' )
			? self::SOURCE_TYPE_PRODUCT_ARTICLE
			: self::SOURCE_TYPE_ARTICLE;
	}

	private static function find_post_by_article_id( $article_id, string $source_type = self::SOURCE_TYPE_ARTICLE ): ?int {
		// Posts synced before 1.5.9 have no source type meta; they are all regular articles.
		if ( self::SOURCE_TYPE_PRODUCT_ARTICLE === $source_type ) {
			$source_clause = array(
				'key'     => self::SOURCE_TYPE_META_KEY,
				'value'   => self::SOURCE_TYPE_PRODUCT_ARTICLE,
				'compare' => '=',
			);
		} else {
			$source_clause = array(
				'relation' => 'OR',
				array(
					'key'     => self::SOURCE_TYPE_META_KEY,
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'     => self::SOURCE_TYPE_META_KEY,
					'value'   => self::SOURCE_TYPE_ARTICLE,
					'compare' => '=',
				),
			);
		}

		// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- there is no core API to look up a post by an external article ID other than a postmeta lookup; only posts previously synced by this plugin carry these meta keys, so the matching set stays small.
		$posts = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => 'any',
				'meta_query'     => array(
					'relation' => 'AND',
					array(
						'key'     => self::ARTICLE_ID_META_KEY,
						'value'   => $article_id,
						'compare' => '=',
					),
					$source_clause,
				),
				'numberposts'    => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);

		return isset( $posts[0] ) ? absint( $posts[0] ) : null;
	}

	private static function get_managed_post( int $post_id ): ?WP_Post {
		$post = get_post( $post_id );
		if ( ! $post || 'post' !== $post->post_type || '1' !== get_post_meta( $post_id, self::MANAGED_META_KEY, true ) ) {
			return null;
		}

		return $post;
	}

		private static function not_found_response(): WP_REST_Response {
			return new WP_REST_Response( array( 'message' => __( 'The requested managed article was not found.', 'sevof-connector' ) ), 404 );
		}

		/**
		 * Converts an unexpected publish/update exception into an authenticated JSON
		 * response instead of a blank web-server 500. The detailed message is useful
		 * to the Laravel caller; it is never written to logs with request credentials.
		 */
		private static function internal_error_response( string $event, Throwable $error, $article_id, int $post_id = 0 ): WP_REST_Response {
			sevof_connector_log(
				$event,
				array(
					'article_id' => $article_id,
					'post_id'    => $post_id,
					'reason'     => $error->getMessage(),
					'file'       => $error->getFile(),
					'line'       => $error->getLine(),
					'trace'      => wp_json_encode( $error->getTrace() ),
				)
			);

			return new WP_REST_Response(
				array(
					'code'       => $event,
					'message'    => __( 'An internal error occurred while publishing the article in WordPress.', 'sevof-connector' ),
					'detail'     => sanitize_text_field( $error->getMessage() ),
					'source'     => sanitize_text_field( $error->getFile() ) . ':' . (int) $error->getLine(),
					'article_id' => $article_id,
					'wp_post_id' => $post_id > 0 ? $post_id : null,
				),
				500
			);
		}

		private static function rest_error( string $code, string $message, int $status ): WP_Error {
		return new WP_Error( $code, $message, array( 'status' => $status ) );
	}

	private static function validated_status( $value ): string {
		return in_array( $value, array( 'draft', 'publish' ), true ) ? $value : 'draft';
	}

	private static function post_id_arguments(): array {
		return array(
			'id' => array(
				'description'       => __( 'The WordPress post ID for a Sevof-managed article.', 'sevof-connector' ),
				'type'              => 'integer',
				'required'          => true,
				'sanitize_callback' => 'absint',
				'validate_callback' => array( self::class, 'validate_positive_integer' ),
			),
		);
	}

	private static function article_arguments( bool $creating ): array {
		return array(
			// Integer for regular articles; a string ID (ULID) for product articles.
			// No fixed 'type' here on purpose: validation depends on source_type.
			'article_id'       => array(
				'description'       => __( 'The Sevof article identifier.', 'sevof-connector' ),
				'required'          => $creating,
				'sanitize_callback' => array( self::class, 'sanitize_article_id' ),
				'validate_callback' => array( self::class, 'validate_article_id' ),
			),
			'title'            => array(
				'type'              => 'string',
				'required'          => $creating,
				'sanitize_callback' => 'sanitize_text_field',
				'validate_callback' => array( self::class, 'validate_title' ),
			),
			'content'          => array(
				'type'              => 'array',
				'required'          => $creating,
				'validate_callback' => array( self::class, 'validate_sections' ),
			),
				'meta_description' => self::text_argument( false ),
			'meta_title'       => self::text_argument( false ),
			'og_title'         => self::text_argument( false ),
			'og_description'   => self::text_argument( false ),
			'focus_keyword'    => self::text_argument( false ),
				'post_status'      => array(
					'type'              => 'string',
					'required'          => false,
					'nullable'          => true,
					'sanitize_callback' => 'sanitize_key',
					'validate_callback' => array( self::class, 'validate_post_status' ),
				),
				'slug'             => array(
					'type'              => 'string',
					'required'          => false,
					'nullable'          => true,
					'sanitize_callback' => 'sanitize_title',
					'validate_callback' => array( self::class, 'validate_slug' ),
				),
				'featured_image'   => array(
					'type'              => 'object',
					'required'          => false,
					'nullable'          => true,
					'validate_callback' => array( self::class, 'validate_featured_image_argument' ),
				),
				'faq_schema'       => array(
					'required'          => false,
					'nullable'          => true,
					'validate_callback' => array( self::class, 'validate_faq_schema' ),
				),
			// The WordPress category id this article should be filed under. Must
			// already exist as a 'category' term - the Laravel side only ever sends
			// an id it read back from this site's own /categories, so a mismatch
			// here signals a stale cache rather than something to silently coerce.
				'category_id'      => array(
					'required'          => false,
					'nullable'          => true,
					'sanitize_callback' => 'absint',
					'validate_callback' => array( self::class, 'validate_category_id' ),
			),
			// Final tag names (existing tags the service kept + any brand-new ones),
			// always the full current set - see sync_taxonomy().
				'tags'             => array(
					'required'          => false,
					'nullable'          => true,
					'validate_callback' => array( self::class, 'validate_tags' ),
			),
			// Images meant to appear above all sections (i.e. "after_section" earlier
			// than the first section, per the Sevof service's own ordering).
			'lead_images'      => array(
					'type'              => 'array',
					'required'          => false,
					'nullable'          => true,
					'validate_callback' => static function ( $value ) {
					return self::validate_gallery_images( $value, self::MAX_LEAD_IMAGES );
				},
			),
			// A single ready-made HTML block (logo/site name already embedded by the
			// Sevof service); only the most recently attached banner is ever sent.
			'banner'           => array(
					'type'              => 'object',
					'required'          => false,
					'nullable'          => true,
					'validate_callback' => array( self::class, 'validate_banner' ),
			),
			// Which Sevof content table article_id belongs to (see SOURCE_TYPE_META_KEY).
			'source_type'      => array(
				'type'              => 'string',
				'required'          => false,
				'nullable'          => true,
				'sanitize_callback' => 'sanitize_key',
				'validate_callback' => array( self::class, 'validate_source_type' ),
			),
			// Product articles: products not shown under any section, rendered as
			// the "suggested products" block (see build_content()).
			'related_products' => array(
				'type'              => 'array',
				'required'          => false,
				'nullable'          => true,
				'validate_callback' => static function ( $value ) {
					return self::validate_product_list( $value, self::MAX_RELATED_PRODUCTS );
				},
			),
			// Product/ItemList JSON-LD for product articles; printed in <head> by Sevof_Connector_Seo.
			'product_schema'   => array(
				'required'          => false,
				'nullable'          => true,
				'validate_callback' => array( self::class, 'validate_product_schema' ),
			),
		);
	}

	private static function text_argument( bool $required ): array {
		return array(
			'type'              => 'string',
			'required'          => $required,
			'nullable'          => ! $required,
			'sanitize_callback' => 'sanitize_text_field',
			'validate_callback' => array( self::class, 'validate_meta_text' ),
		);
	}

	public static function validate_positive_integer( $value ): bool {
		return ( is_int( $value ) || ( is_string( $value ) && ctype_digit( $value ) ) ) && (int) $value > 0;
	}

	/**
	 * Validates article_id. Regular articles keep the strict positive-integer rule.
	 * Product articles (source_type=product_article) may also use a string ID such
	 * as a ULID, because their Sevof table does not use auto-increment integers.
	 */
	public static function validate_article_id( $value, $request = null ): bool {
		if ( self::validate_positive_integer( $value ) ) {
			return true;
		}

		$source_type = $request instanceof WP_REST_Request
			? self::resolve_source_type( $request )
			: self::SOURCE_TYPE_ARTICLE;

		return self::SOURCE_TYPE_PRODUCT_ARTICLE === $source_type
			&& is_string( $value )
			&& 1 === preg_match( '/^[A-Za-z0-9_-]{1,64}$/', $value );
	}

	public static function sanitize_article_id( $value, $request = null ) {
		$source_type = $request instanceof WP_REST_Request
			? self::resolve_source_type( $request )
			: self::SOURCE_TYPE_ARTICLE;

		return self::normalize_article_id( $value, $source_type );
	}

	/**
	 * Regular articles: positive int. Product articles: positive int when numeric,
	 * otherwise a lower-cased string ID (ULIDs are case-insensitive, so lower-casing
	 * guarantees the same article always maps to the same post).
	 *
	 * @return int|string
	 */
	private static function normalize_article_id( $value, string $source_type ) {
		if ( self::SOURCE_TYPE_PRODUCT_ARTICLE === $source_type && is_string( $value ) && ! ctype_digit( $value ) ) {
			return strtolower( preg_replace( '/[^A-Za-z0-9_-]/', '', $value ) );
		}

		return absint( $value );
	}

	public static function validate_title( $value ): bool {
		return is_string( $value ) && '' !== trim( wp_strip_all_tags( $value ) ) && strlen( $value ) <= self::MAX_TITLE_LENGTH;
	}

	public static function validate_sections( $value ): bool {
		if ( ! is_array( $value ) || empty( $value ) || count( $value ) > self::MAX_SECTIONS ) {
			return false;
		}

		foreach ( $value as $section ) {
			if ( ! is_array( $section ) || ! isset( $section['content'] ) || ! is_string( $section['content'] ) || strlen( $section['content'] ) > self::MAX_SECTION_CONTENT_BYTES ) {
				return false;
			}

			if ( isset( $section['heading'] ) && ( ! is_string( $section['heading'] ) || strlen( $section['heading'] ) > self::MAX_TITLE_LENGTH ) ) {
				return false;
			}

			if ( isset( $section['images'] ) && ! self::validate_gallery_images( $section['images'], self::MAX_SECTION_IMAGES ) ) {
				return false;
			}

			if ( isset( $section['products'] ) && ! self::validate_product_list( $section['products'], self::MAX_SECTION_PRODUCTS ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Structure check only (the render step re-sanitizes every field). Kept
	 * lenient on purpose: a product list must never make the WHOLE article
	 * request fail validation, so only the shape and the count cap matter.
	 */
	public static function validate_product_list( $value, int $max_count ): bool {
		if ( null === $value ) {
			return true;
		}

		if ( ! is_array( $value ) || count( $value ) > $max_count ) {
			return false;
		}

		foreach ( $value as $product ) {
			if ( ! is_array( $product ) ) {
				return false;
			}
		}

		return true;
	}

	public static function validate_meta_text( $value ): bool {
		return null === $value || ( is_string( $value ) && strlen( $value ) <= self::MAX_META_LENGTH );
	}

	public static function validate_post_status( $value ): bool {
		return null === $value || in_array( $value, array( 'draft', 'publish' ), true );
	}

	public static function validate_slug( $value ): bool {
		return null === $value || ( is_string( $value ) && strlen( $value ) <= self::MAX_TITLE_LENGTH );
	}

	public static function validate_featured_image_argument( $value ): bool {
		if ( null === $value ) {
			return true;
		}

		if ( ! is_array( $value ) || ! isset( $value['base64'] ) || ! is_string( $value['base64'] ) ) {
			return false;
		}

		return strlen( $value['base64'] ) <= self::MAX_IMAGE_BASE64_BYTES;
	}

	/**
		 * Keeps category validation non-blocking. The actual term lookup happens in
		 * sync_taxonomy(), where a stale/deleted ID is safely ignored.
	 */
		public static function validate_category_id( $value ): bool {
		// A missing/stale category is non-fatal. sync_taxonomy() validates the
		// term again and simply skips it when it does not exist locally.
		return true;
	}

	/**
	 * Validates the 'tags' argument: an array of plain, reasonably short strings.
	 * Existence is irrelevant here - wp_set_post_tags() creates any tag name that
	 * does not already exist, which is the whole point of sending names rather
	 * than ids.
	 */
		public static function validate_tags( $value ): bool {
		// Tags are also best-effort. sync_taxonomy() keeps only usable names,
		// limits their count, and lets WordPress create/reuse the valid terms.
			return true;
	}

	/**
	 * Validates an array of gallery image payloads (used for both 'lead_images' and
	 * each section's 'images'). Only checks structure and size here - actual image
	 * decoding/type-sniffing happens later, at upload time, the same way the existing
	 * featured-image payload is handled.
	 */
	public static function validate_gallery_images( $value, int $max_count ): bool {
		if ( null === $value ) {
			return true;
		}

		if ( ! is_array( $value ) ) {
			return false;
		}

		if ( count( $value ) > $max_count ) {
			return false;
		}

		foreach ( $value as $image ) {
			if ( ! is_array( $image ) || empty( $image['base64'] ) || ! is_string( $image['base64'] ) ) {
				return false;
			}

			if ( strlen( $image['base64'] ) > self::MAX_IMAGE_BASE64_BYTES ) {
				return false;
			}

			if ( isset( $image['alt'] ) && ( ! is_string( $image['alt'] ) || strlen( $image['alt'] ) > self::MAX_TITLE_LENGTH ) ) {
				return false;
			}

			if ( isset( $image['filename'] ) && ( ! is_string( $image['filename'] ) || strlen( $image['filename'] ) > self::MAX_TITLE_LENGTH ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Normalizes raw Base64 and browser data-URI image payloads. Removing
	 * whitespace also makes strict decoding safe for wrapped transport values.
	 */
	private static function normalize_image_base64( string $base64 ): string {
		$base64 = trim( $base64 );
		$base64 = (string) preg_replace( '#^data:image/[^;]+;base64,#i', '', $base64 );

		return (string) preg_replace( '/\s+/', '', $base64 );
	}

	/**
	 * Validates the banner payload: a required HTML block plus a few optional,
	 * informational fields. The HTML itself is sanitized later, at render time, via
	 * wp_kses_post() - this only bounds its size and checks the optional fields.
	 */
	public static function validate_banner( $value ): bool {
		if ( null === $value ) {
			return true;
		}

		if ( ! is_array( $value ) ) {
			return false;
		}

		if ( ! isset( $value['html'] ) || ! is_string( $value['html'] ) || '' === trim( $value['html'] ) ) {
			return false;
		}

		if ( strlen( $value['html'] ) > self::MAX_BANNER_HTML_BYTES ) {
			return false;
		}

		if ( isset( $value['id'] ) && ! is_numeric( $value['id'] ) ) {
			return false;
		}

		if ( isset( $value['logo_url'] ) && '' !== $value['logo_url'] && ( ! is_string( $value['logo_url'] ) || false === wp_http_validate_url( $value['logo_url'] ) ) ) {
			return false;
		}

		if ( isset( $value['site_name'] ) && ( ! is_string( $value['site_name'] ) || strlen( $value['site_name'] ) > self::MAX_META_LENGTH ) ) {
			return false;
		}

		return true;
	}

	public static function validate_source_type( $value ): bool {
		return null === $value || in_array( $value, array( self::SOURCE_TYPE_ARTICLE, self::SOURCE_TYPE_PRODUCT_ARTICLE ), true );
	}

	/**
	 * Same contract as validate_faq_schema(): a JSON-LD array, or a JSON string, within the size cap.
	 */
	public static function validate_product_schema( $value ): bool {
		if ( null === $value ) {
			return true;
		}

		if ( is_array( $value ) ) {
			return strlen( (string) wp_json_encode( $value ) ) <= self::MAX_PRODUCT_SCHEMA_BYTES;
		}

		if ( ! is_string( $value ) || '' === $value || strlen( $value ) > self::MAX_PRODUCT_SCHEMA_BYTES ) {
			return false;
		}

		json_decode( $value, true );

		return JSON_ERROR_NONE === json_last_error();
	}

	public static function validate_faq_schema( $value ): bool {
		if ( null === $value ) {
			return true;
		}

		if ( is_array( $value ) ) {
			return strlen( (string) wp_json_encode( $value ) ) <= self::MAX_FAQ_SCHEMA_BYTES;
		}

		if ( ! is_string( $value ) || strlen( $value ) > self::MAX_FAQ_SCHEMA_BYTES || '' === $value ) {
			return false;
		}

		json_decode( $value, true );

		return JSON_ERROR_NONE === json_last_error();
	}

	/**
	 * Converts FAQPage JSON-LD data into a native browser accordion. The JSON-LD
	 * remains stored in postmeta for SEO, while this visual copy is sanitized and
	 * rendered as a separate Custom HTML block for the front end.
	 *
	 * IMPORTANT: this uses <details>/<summary> rather than the older
	 * checkbox+label technique. WordPress runs post_content through KSES on save
	 * for unauthenticated/REST writes, and <input> is NOT in $allowedposttags -
	 * so the checkbox was being stripped from the stored content, leaving every
	 * answer permanently collapsed. <details> and <summary> are both allowed by
	 * KSES, need no JavaScript, and survive the wp:html block round-trip intact.
	 */
	private static function render_faq_accordion( $value ): string {
		if ( is_string( $value ) ) {
			$value = json_decode( $value, true );
		}

		if ( ! is_array( $value ) ) {
			return '';
		}

		$items  = isset( $value['mainEntity'] ) && is_array( $value['mainEntity'] ) ? $value['mainEntity'] : $value;
		$markup = array();

		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$question = '';
			if ( isset( $item['name'] ) ) {
				$question = wp_strip_all_tags( (string) $item['name'] );
			} elseif ( isset( $item['question'] ) ) {
				$question = wp_strip_all_tags( (string) $item['question'] );
			}

			$answer = '';
			if ( isset( $item['acceptedAnswer']['text'] ) ) {
				$answer = (string) $item['acceptedAnswer']['text'];
			} elseif ( isset( $item['answer'] ) ) {
				$answer = is_array( $item['answer'] ) && isset( $item['answer']['text'] ) ? (string) $item['answer']['text'] : (string) $item['answer'];
			}

			$answer = wp_kses_post( $answer );
			if ( '' === trim( $question ) || '' === trim( $answer ) ) {
				continue;
			}

			$markup[] = '<details class="sevof-faq-item"><summary class="sevof-faq-question">'
				. esc_html( $question )
				. '</summary><div class="sevof-faq-answer">' . $answer . '</div></details>';
		}

		if ( empty( $markup ) ) {
			return '';
		}

		$faq_title = __( 'Frequently asked questions', 'sevof-connector' );
		$html      = '<section class="sevof-faq" aria-label="' . esc_attr( $faq_title ) . '"><h2 class="sevof-faq-title">' . esc_html( $faq_title ) . '</h2>' . implode( '', $markup ) . '</section>';
		$safe = self::sanitize_for_block_comment( $html );

		return "<!-- wp:html -->\n" . $safe . "\n<!-- /wp:html -->";
	}

	/**
	 * Normalizes a section heading (HTML, ZWNJ, diacritics)
	 * for keyword matching.
	 */
	private static function normalize_heading_for_match( string $heading ): string {
		$text = html_entity_decode( wp_strip_all_tags( $heading ), ENT_QUOTES, 'UTF-8' );
		$text = str_replace( array( "\u{200C}", "\u{200D}", "\u{200F}", "\u{200E}", "\u{064B}", "\u{064C}", "\u{064D}", "\u{064E}", "\u{064F}", "\u{0650}", "\u{0651}", "\u{0652}" ), '', $text );
		$text = preg_replace( '/[\s\x{00A0}_\-:؟?!.،,]+/u', ' ', $text );

		return trim( (string) $text );
	}

	/**
	 * True when a section heading is a plain-text FAQ section, in any language Sevof writes.
	 */
	public static function is_faq_heading( string $heading ): bool {
		$text = self::normalize_heading_for_match( $heading );
		if ( '' === $text ) {
			return false;
		}

		$patterns = array(
			'/\bfaqs?\b|frequently asked|common questions/iu',
			'/h[äa]ufig gestellte fragen|questions fr[ée]quentes|foire aux questions|preguntas frecuentes|perguntas frequentes|domande frequenti|s[ıi]k[çc]a sorulan sorular/iu',
			'/(الأسئلة|الاسئلة|اسئلة|أسئلة)\s*(الشائعة|المتكررة|شائعة|متكررة)/u',
		);

		foreach ( $patterns as $pattern ) {
			if ( preg_match( $pattern, $text ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * True when a section heading is the closing section, in any language Sevof writes.
	 */
	private static function is_conclusion_heading( string $heading ): bool {
		$text = self::normalize_heading_for_match( $heading );
		if ( '' === $text ) {
			return false;
		}

		$patterns = array(
			'/\b(conclusion|summary|final thoughts|wrapping up|bottom line)\b/iu',
			'/\b(fazit|zusammenfassung|schlussfolgerung|conclusi[óo]n|conclus[ãa]o|conclusione|sonu[çc]|[öo]zet)\b/iu',
			'/(الخاتمة|خاتمة|الخلاصة|خلاصة|الملخص)/u',
		);

		foreach ( $patterns as $pattern ) {
			if ( preg_match( $pattern, $text ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Converts validated article sections, optional lead gallery images, and an
	 * optional banner block into safe post HTML.
	 *
	 * Placement:
	 *  - lead images (the Sevof service's "after_section" earlier than the first
	 *    section) are rendered first, above all sections.
	 *  - each section's own images are placed immediately after that section's text.
	 *  - the banner is a single ready-made HTML block; it is inserted once, right
	 *    after the first section, so it is not the very first thing a reader sees but
	 *    still appears early in the article. If there somehow is no first section to
	 *    anchor to, it falls back to the end of the content so it is never silently
	 *    dropped.
	 *
	 * Gallery images are uploaded into the Media Library and embedded by their
	 * resolved URL (never as inline base64) - see render_gallery_images() - so
	 * $post_id must already exist before this runs.
	 */
	private static function build_content( int $post_id, array $sections, array $lead_images, ?array $banner, string $faq_html = '', string $related_html = '' ): string {
		// A single budget shared across the lead images and every section's images in
		// this request, decremented as images are rendered; a defensive backstop
		// independent of the smaller per-field caps enforced at validation time.
		$image_budget = self::MAX_TOTAL_GALLERY_IMAGES;

		$blocks = array();

		if ( ! empty( $lead_images ) ) {
			$blocks[] = self::render_gallery_images( $post_id, $lead_images, $image_budget );
		}

		$banner_html     = $banner ? self::render_banner( $banner ) : '';
		$banner_inserted = ( '' === $banner_html );

		// FAQ placement. The service may send the FAQ as an ordinary (unstyled)
		// section AND as faq_schema. When we have the styled accordion we show ONLY
		// that one: the plain FAQ section is dropped (its images are kept), and the
		// accordion goes right before the conclusion section. If there is no
		// conclusion it takes the plain FAQ section's place; if neither exists it
		// goes at the end.
		$faq_pending     = ( '' !== trim( $faq_html ) );
		$has_styled_faq  = $faq_pending;
		$faq_index       = null;
		$conclusion_index = null;

		// The suggested-products block goes right before the conclusion; failing
		// that, before the (plain) FAQ section; failing that, at the end.
		$related_pending = ( '' !== trim( $related_html ) );
		$related_anchor  = null;

		if ( $faq_pending || $related_pending ) {
			foreach ( $sections as $index => $section ) {
				if ( ! is_array( $section ) ) {
					continue;
				}
				$heading_text = isset( $section['heading'] ) ? (string) $section['heading'] : '';

				if ( self::is_faq_heading( $heading_text ) ) {
					if ( null === $faq_index ) {
						$faq_index = $index;
					}
				} elseif ( self::is_conclusion_heading( $heading_text ) ) {
					// Last matching section wins (the real closing section).
					$conclusion_index = $index;
				}
			}
		}

		if ( $related_pending ) {
			$related_anchor = ( null !== $conclusion_index ) ? $conclusion_index : $faq_index;
		}

		foreach ( $sections as $index => $section ) {
			if ( ! is_array( $section ) ) {
				continue;
			}

			$heading = isset( $section['heading'] ) ? trim( (string) $section['heading'] ) : '';
			$content = isset( $section['content'] ) ? trim( (string) $section['content'] ) : '';

			$is_plain_faq_section = $has_styled_faq && self::is_faq_heading( $heading );

			if ( $related_pending && null !== $related_anchor && $index === $related_anchor ) {
				$blocks[]        = $related_html;
				$related_pending = false;
			}

			if ( $faq_pending && null !== $conclusion_index && $index === $conclusion_index ) {
				$blocks[]    = $faq_html;
				$faq_pending = false;
			} elseif ( $faq_pending && null === $conclusion_index && $is_plain_faq_section ) {
				$blocks[]    = $faq_html;
				$faq_pending = false;
			}

			if ( $is_plain_faq_section ) {
				// Drop the unstyled duplicate heading/content; keep only its images.
				$heading = '';
				$content = '';
			}

			if ( '' !== $heading ) {
				$blocks[] = self::heading_block( $heading );
			}

			// Product showcase(s) for this section: right under the heading, above
			// the text (same order as the Sevof panel).
			if ( ! $is_plain_faq_section && ! empty( $section['products'] ) && is_array( $section['products'] ) ) {
				$blocks[] = self::render_product_cards( $section['products'], self::MAX_SECTION_PRODUCTS );
			}

			if ( '' !== $content ) {
				$blocks[] = self::explode_top_level_html_blocks( $content );
			}

			if ( ! empty( $section['images'] ) && is_array( $section['images'] ) ) {
				$blocks[] = self::render_gallery_images( $post_id, $section['images'], $image_budget );
			}

			if ( ! $banner_inserted && 0 === $index ) {
				$blocks[]        = $banner_html;
				$banner_inserted = true;
			}
		}

		if ( ! $banner_inserted ) {
			$blocks[] = $banner_html;
		}

		// No conclusion / FAQ section to anchor to: suggested products go at the end,
		// before the accordion (same order as the panel).
		if ( $related_pending ) {
			$blocks[] = $related_html;
		}

		// No conclusion and no plain FAQ section found: keep the old behaviour
		// (accordion at the end of the article).
		if ( $faq_pending ) {
			$blocks[] = $faq_html;
		}

		$blocks = array_filter(
			$blocks,
			static function ( $block ) {
				return '' !== trim( (string) $block );
			}
		);

		return implode( "\n\n", $blocks );
	}

	/**
	 * Dependency-free converter from section HTML to Gutenberg blocks.
	 *
	 * Paragraphs and headings become real blocks; tables get the styled wrapper;
	 * lists, quotes and unknown structures stay as Custom HTML blocks.
	 *
	 * Tags are matched by balanced scanning (nesting depth), NOT by a lazy regex.
	 * The old lazy regex closed a <div>, <ul> or <blockquote> at the FIRST closing
	 * tag, so any nested element left a stray "</div>" / "</li></ul>" (and an
	 * unclosed opening tag) in the post. Browsers then closed or swallowed the
	 * theme's own wrappers, which scrambled headings and broke the page layout.
	 */
	private static function explode_html_blocks_without_dom( string $html ): string {
		$safe_html = trim( wp_kses_post( $html ) );
		if ( '' === $safe_html ) {
			return '';
		}

		$blocks       = array();
		$offset       = 0; // Start of the text not yet emitted as a block.
		$search       = 0; // Where to look for the next opening tag.
		$length       = strlen( $safe_html );
		$open_pattern = '~<(p|h[1-6]|div|ul|ol|blockquote|table)\b[^>]*>~i';

		while ( $search < $length && 1 === preg_match( $open_pattern, $safe_html, $open, PREG_OFFSET_CAPTURE, $search ) ) {
			$open_pos = (int) $open[0][1];
			$open_len = strlen( (string) $open[0][0] );
			$tag      = strtolower( (string) $open[1][0] );
			$inner_at = $open_pos + $open_len;

			$close = self::find_matching_close_tag( $safe_html, $tag, $inner_at );
			if ( null === $close ) {
				// Unclosed tag: leave it in the surrounding loose HTML (it is
				// balanced below) and keep scanning after it.
				$search = $inner_at;
				continue;
			}

			$between = trim( substr( $safe_html, $offset, $open_pos - $offset ) );
			if ( '' !== $between ) {
				$blocks[] = self::html_block( force_balance_tags( $between ) );
			}

			$full  = substr( $safe_html, $open_pos, $close[1] - $open_pos );
			$inner = trim( substr( $safe_html, $inner_at, $close[0] - $inner_at ) );

			if ( '' !== $inner ) {
				switch ( $tag ) {
					case 'p':
						// A paragraph that is only a product link becomes a showcase card.
						$link_card = self::standalone_link_card( $inner );
						$blocks[]  = null !== $link_card ? self::auto_cards_block( array( $link_card ) ) : self::paragraph_block( $inner );
						break;

					case 'ul':
					case 'ol':
						// A list made only of product links becomes a grid of cards.
						$link_cards = self::list_link_cards( $inner );
						$blocks[]   = '' !== $link_cards ? $link_cards : self::html_block( $full );
						break;

					case 'h1':
					case 'h2':
					case 'h3':
					case 'h4':
					case 'h5':
					case 'h6':
						// The post title is the page's only <h1>; body "h1" becomes h2.
						$blocks[] = self::heading_block_leveled( $inner, max( 2, (int) substr( $tag, 1 ) ) );
						break;

					case 'table':
						$blocks[] = self::table_block( $full );
						break;

					case 'div':
						$nested   = self::explode_html_blocks_without_dom( $inner );
						$blocks[] = '' !== trim( $nested ) ? $nested : self::html_block( $full );
						break;

					default:
						$blocks[] = self::html_block( $full );
						break;
				}
			}

			$offset = $close[1];
			$search = $close[1];
		}

		$tail = trim( substr( $safe_html, $offset ) );
		if ( '' !== $tail ) {
			$blocks[] = self::html_block( force_balance_tags( $tail ) );
		}

		return implode(
			"\n\n",
			array_filter(
				$blocks,
				static function ( $block ): bool {
					return '' !== trim( (string) $block );
				}
			)
		);
	}

	/**
	 * Finds the closing tag that matches an already-opened <$tag>, counting
	 * nested tags of the same name.
	 *
	 * @param string $html Full HTML.
	 * @param string $tag  Lower-case tag name.
	 * @param int    $from Offset just after the opening tag.
	 * @return array|null  array( closing_tag_start, closing_tag_end ) or null if unbalanced.
	 */
	private static function find_matching_close_tag( string $html, string $tag, int $from ) {
		$pattern = '~<(/?)' . preg_quote( $tag, '~' ) . '\b[^>]*>~i';
		$depth   = 1;
		$pos     = $from;

		while ( 1 === preg_match( $pattern, $html, $m, PREG_OFFSET_CAPTURE, $pos ) ) {
			$tag_pos = (int) $m[0][1];
			$tag_len = strlen( (string) $m[0][0] );

			if ( '/' === $m[1][0] ) {
				--$depth;
				if ( 0 === $depth ) {
					return array( $tag_pos, $tag_pos + $tag_len );
				}
			} elseif ( '/>' !== substr( (string) $m[0][0], -2 ) ) {
				++$depth;
			}

			$pos = $tag_pos + $tag_len;
		}

		return null;
	}

	/**
	 * Prefixes every selector inside banner <style> blocks with ".sevof-banner"
	 * so a banner's CSS (e.g. bare "h2", "p", "ul", "body" rules) can never leak
	 * out and restyle the rest of the page.
	 */
	private static function scope_banner_styles( string $html ): string {
		if ( false === stripos( $html, '<style' ) ) {
			return $html;
		}

		return (string) preg_replace_callback(
			'~(<style\b[^>]*>)(.*?)(</style\s*>)~is',
			static function ( array $m ): string {
				// wp_kses turns the ">" combinator into "&gt;"; restore it (only ">").
				$css = str_replace( '&gt;', '>', $m[2] );

				return $m[1] . self::scope_css( $css, '.sevof-banner' ) . $m[3];
			},
			$html
		);
	}

	/**
	 * Minimal CSS scoper: handles plain rules, @media/@supports nesting, and
	 * leaves @keyframes/@font-face untouched. Other at-rules (e.g. @import) are dropped.
	 */
	private static function scope_css( string $css, string $scope ): string {
		$css = (string) preg_replace( '~/\*.*?\*/~s', '', $css );
		$css = (string) preg_replace( '~@import[^;]*;~i', '', $css );
		$out = '';
		$len = strlen( $css );
		$i   = 0;

		while ( $i < $len ) {
			$brace = strpos( $css, '{', $i );
			if ( false === $brace ) {
				break;
			}

			$prelude = trim( substr( $css, $i, $brace - $i ) );
			$depth   = 1;
			$j       = $brace + 1;
			while ( $j < $len && $depth > 0 ) {
				if ( '{' === $css[ $j ] ) {
					++$depth;
				} elseif ( '}' === $css[ $j ] ) {
					--$depth;
				}
				++$j;
			}
			if ( $depth > 0 ) {
				break; // Unterminated rule: drop it.
			}

			$body = substr( $css, $brace + 1, $j - $brace - 2 );
			$i    = $j;

			if ( '' === $prelude ) {
				continue;
			}

			if ( 0 === strpos( $prelude, '@' ) ) {
				if ( 1 === preg_match( '~^@(media|supports)\b~i', $prelude ) ) {
					$out .= $prelude . '{' . self::scope_css( $body, $scope ) . '}';
				} elseif ( 1 === preg_match( '~^@(-webkit-)?(keyframes|font-face)\b~i', $prelude ) ) {
					$out .= $prelude . '{' . $body . '}';
				}
				continue;
			}

			$selectors = array();
			foreach ( explode( ',', $prelude ) as $selector ) {
				$selector = trim( $selector );
				if ( '' === $selector ) {
					continue;
				}
				if ( 0 === strpos( $selector, $scope ) ) {
					$selectors[] = $selector;
					continue;
				}
				$selector    = trim( (string) preg_replace( '~^(?:html|body|:root)\b~i', '', $selector ) );
				$selectors[] = '' === $selector ? $scope : $scope . ' ' . $selector;
			}

			if ( ! empty( $selectors ) ) {
				$out .= implode( ',', $selectors ) . '{' . $body . '}';
			}
		}

		return $out;
	}

	/**
	 * Wraps a single, already-sanitized heading string as a real Gutenberg
	 * "Heading" block (wp:heading), keeping the RTL styling the rest of the
	 * article uses. Section headings are always rendered as <h2>.
	 */
	/**
	 * Normalizes incoming heading markup so a heading is never nested inside
	 * another heading or wrapped in a presentational span. Direction is applied
	 * to the real heading element below, not to an inner span.
	 */
	private static function normalize_heading_html( string $html ): string {
		$safe = wp_kses_post( $html );
		$safe = preg_replace( '/<\/?(?:h[1-6]|span)\b[^>]*>/i', '', $safe );

		return trim( (string) $safe );
	}

	private static function heading_block( string $heading ): string {
		$safe = self::normalize_heading_html( $heading );
		if ( '' === trim( $safe ) ) {
			return '';
		}

		$attrs = wp_json_encode( array( 'level' => 2 ) );

		return '<!-- wp:heading ' . $attrs . ' -->'
				. "\n" . '<h2 class="wp-block-heading">' . $safe . '</h2>'
				. "\n" . '<!-- /wp:heading -->';
	}

	/**
	 * Splits a section's HTML content into its top-level tags and maps each one
	 * to the matching Gutenberg block, instead of dumping the whole thing into
	 * one opaque wp:html block.
	 */
	private static function explode_top_level_html_blocks( string $html ): string {
		$html = trim( $html );
		if ( '' === $html ) {
			return '';
		}

		// Always use the dependency-free parser. This keeps article publication
		// independent from the optional PHP DOM/XML extension on shared hosts.
		// The parser still emits real paragraph and heading Gutenberg blocks.
		return self::explode_html_blocks_without_dom( $html );

		// DOM/XML is optional on many shared WordPress hosts. If it is missing,
		// preserve the sanitized HTML as one Custom HTML block instead of throwing
		// "Class DOMDocument not found" and returning HTTP 500.
		if ( ! extension_loaded( 'dom' ) || ! class_exists( 'DOMDocument' ) || ! function_exists( 'libxml_use_internal_errors' ) ) {
			return self::explode_html_blocks_without_dom( $html );
		}

		try {
			$previous_setting = libxml_use_internal_errors( true );
			$dom              = new \DOMDocument();
		} catch ( Throwable $e ) {
			return self::explode_html_blocks_without_dom( $html );
		}

		// Wrap in a minimal UTF-8 container so DOMDocument doesn't mis-detect
		// encoding and mangle non-Latin text; LIBXML_HTML_NOIMPLIED and
		// LIBXML_HTML_NODEFDTD keep it from injecting <html><body> wrappers we'd
		// then have to strip back out.
		$wrapped = '<?xml encoding="utf-8"?><div id="sevof-root">' . $html . '</div>';
		$loaded  = $dom->loadHTML( $wrapped, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );

		libxml_clear_errors();
		libxml_use_internal_errors( $previous_setting );

		if ( ! $loaded ) {
			return self::html_block( $html );
		}

		$root = $dom->getElementById( 'sevof-root' );
		if ( ! $root ) {
			return self::html_block( $html );
		}

		$blocks       = array();
		$tag_to_block = array(
			'p'          => 'paragraph',
			'ul'         => 'list',
			'ol'         => 'list',
			'blockquote' => 'quote',
			'table'      => 'table',
			// Laravel wraps section content in a directional div. Unwrap it so
			// its children become independent Gutenberg blocks.
			'div'        => 'container',
			'h1'         => 'heading',
			'h2'         => 'heading',
			'h3'         => 'heading',
			'h4'         => 'heading',
			'h5'         => 'heading',
			'h6'         => 'heading',
		);

		foreach ( $root->childNodes as $node ) {
			if ( XML_TEXT_NODE === $node->nodeType ) {
				// Stray top-level text (no wrapping tag) - keep it, wrapped as its
				// own paragraph, rather than dropping it.
				$text = trim( $node->textContent );
				if ( '' !== $text ) {
					$blocks[] = self::paragraph_block( esc_html( $text ) );
				}
				continue;
			}

			if ( XML_ELEMENT_NODE !== $node->nodeType ) {
				continue;
			}

			$tag        = strtolower( $node->nodeName );
			$inner_html = self::inner_html( $dom, $node );
			$outer_html = self::outer_html( $dom, $node );

			if ( '' === trim( $inner_html ) ) {
				continue;
			}

			switch ( $tag_to_block[ $tag ] ?? null ) {
				case 'paragraph':
					$blocks[] = self::paragraph_block( $inner_html );
					break;

				case 'heading':
					$level    = (int) substr( $tag, 1 );
					$blocks[] = self::heading_block_leveled( $inner_html, $level );
					break;

				case 'list':
					$blocks[] = self::list_block( $node, 'ol' === $tag );
					break;

				case 'quote':
					$blocks[] = self::quote_block( $inner_html );
					break;

				case 'table':
					// Table markup is structurally sensitive (thead/tbody/tr/td); safest
					// to keep it as a faithful HTML block rather than hand-building
					// wp:table's specific JSON attrs from arbitrary incoming markup.
					$blocks[] = self::table_block( $outer_html );
					break;

				case 'container':
					$nested_blocks = self::explode_top_level_html_blocks( $inner_html );
					if ( '' !== trim( $nested_blocks ) ) {
						$blocks[] = $nested_blocks;
					}
					break;

				default:
					// Unrecognized top-level tag: preserve faithfully, still safe
					// because it already passed through wp_kses_post() upstream.
					$blocks[] = self::html_block( $outer_html );
					break;
			}
		}

		$blocks = array_filter(
			$blocks,
			static function ( $block ): bool {
				return '' !== trim( (string) $block );
			}
		);

		return implode( "\n\n", $blocks );
	}

	private static function paragraph_block( string $inner_html ): string {
		return '<!-- wp:paragraph -->'
				. "\n" . '<p>' . $inner_html . '</p>'
				. "\n" . '<!-- /wp:paragraph -->';
	}

	private static function heading_block_leveled( string $inner_html, int $level ): string {
		$level      = max( 1, min( 6, $level ) );
		$inner_html = self::normalize_heading_html( $inner_html );
		if ( '' === $inner_html ) {
			return '';
		}

		$attrs = wp_json_encode( array( 'level' => $level ) );

		return '<!-- wp:heading ' . $attrs . ' -->'
				. "\n" . '<h' . $level . ' class="wp-block-heading">' . $inner_html . '</h' . $level . '>'
				. "\n" . '<!-- /wp:heading -->';
	}

	private static function quote_block( string $inner_html ): string {
		$quote_content = preg_match( '/^\s*<p(?:\s[^>]*)?>.*<\/p>\s*$/is', $inner_html )
			? $inner_html
			: '<p>' . $inner_html . '</p>';

		return '<!-- wp:quote -->'
			. "\n" . '<blockquote class="wp-block-quote">' . $quote_content . '</blockquote>'
			. "\n" . '<!-- /wp:quote -->';
	}

	/**
	 * Rebuilds a <ul>/<ol> as a wp:list block, preserving each <li>'s inner
	 * HTML so inline formatting (bold/italic/links from the Markdown source)
	 * survives.
	 */
		private static function list_block( $list_node, bool $ordered ): string {
		$items = array();

		foreach ( $list_node->childNodes as $child ) {
			if ( XML_ELEMENT_NODE !== $child->nodeType || 'li' !== strtolower( $child->nodeName ) ) {
				continue;
			}

			$inner = self::inner_html( $list_node->ownerDocument, $child );
			if ( '' === trim( $inner ) ) {
				continue;
			}

			$items[] = '<li>' . $inner . '</li>';
		}

		if ( empty( $items ) ) {
			return '';
		}

		$tag       = $ordered ? 'ol' : 'ul';
		$attrs     = $ordered ? array( 'ordered' => true ) : array();
		$attrs_str = empty( $attrs ) ? '' : ' ' . wp_json_encode( $attrs );

		return '<!-- wp:list' . $attrs_str . ' -->'
				. "\n" . '<' . $tag . ' class="wp-block-list">' . implode( '', $items ) . '</' . $tag . '>'
				. "\n" . '<!-- /wp:list -->';
	}

	/**
	 * A content table as a Custom HTML block, wrapped in a scrollable container
	 * and tagged with `sevof-table` so print_article_styles() can style it.
	 * Without this the table reached the post as bare <table> markup, and most
	 * themes render that with no borders/padding at all.
	 */
	private static function table_block( string $table_html ): string {
		$table_html = trim( $table_html );
		if ( '' === $table_html ) {
			return '';
		}

		$tagged = preg_replace_callback(
			'~^<table\b([^>]*)>~i',
			static function ( array $m ): string {
				$attrs = $m[1];

				if ( preg_match( '~\sclass\s*=\s*(["\'])(.*?)\1~is', $attrs ) ) {
					if ( ! preg_match( '~\bsevof-table\b~', $attrs ) ) {
						$attrs = preg_replace( '~(\sclass\s*=\s*)(["\'])(.*?)\2~is', '$1$2$3 sevof-table$2', $attrs, 1 );
					}
				} else {
					$attrs .= ' class="sevof-table"';
				}

				return '<table' . $attrs . '>';
			},
			$table_html,
			1
		);

		if ( ! is_string( $tagged ) || '' === $tagged ) {
			$tagged = $table_html;
		}

		return self::html_block( '<div class="sevof-table-wrap">' . $tagged . '</div>' );
	}

	/**
	 * Wraps raw, already-sanitized HTML as a Gutenberg "Custom HTML" block -
	 * used only as the fallback for structures this builder does not map to a
	 * native block (tables, and any unrecognized top-level tag), so content is
	 * never lost even if it isn't visually block-editable for that fragment.
	 */
	private static function html_block( string $raw_html ): string {
		$raw_html = trim( $raw_html );
		if ( '' === $raw_html ) {
			return '';
		}

		// Neutralize any stray/unmatched "<!--"/"-->" inside this fragment so it
		// cannot prematurely close the literal "<!-- wp:html -->" wrapper below and
		// corrupt the block boundary for the block editor's parser.
		$safe = str_replace( array( '<!--', '-->' ), array( '&lt;!--', '--&gt;' ), $raw_html );

		return "<!-- wp:html -->\n" . $safe . "\n<!-- /wp:html -->";
	}

		private static function inner_html( $dom, $node ): string {
		$html = '';
		foreach ( $node->childNodes as $child ) {
			$html .= $dom->saveHTML( $child );
		}

		return trim( (string) $html );
	}

		private static function outer_html( $dom, $node ): string {
		return trim( (string) $dom->saveHTML( $node ) );
	}

	/**
	 * Neutralizes any "<!--" / "-->" sequences left inside content that is about
	 * to be wrapped in a literal Gutenberg block comment - used by the FAQ and
	 * banner paths, whose output is emitted as a single wp:html block.
	 */
	private static function sanitize_for_block_comment( string $html ): string {
		return str_replace( array( '<!--', '-->' ), array( '&lt;!--', '--&gt;' ), $html );
	}

	/**
	 * Uploads (or reuses, via content-hash dedup) a set of gallery images and
	 * renders them as real Gutenberg "Image" blocks (wp:image) pointing at the
	 * resolved Media Library URL/attachment.
	 *
	 * @param int   $post_id Post the images belong to.
	 * @param array $images  Raw image payloads (already schema-validated).
	 * @param int   $budget  Remaining render budget, shared across all calls for
	 *                       a single build_content() run; passed by reference and
	 *                       decremented as images are actually rendered.
	 */
	private static function render_gallery_images( int $post_id, array $images, int &$budget ): string {
		if ( $budget <= 0 ) {
			return '';
		}

		$blocks = array();

		foreach ( $images as $image ) {
			if ( $budget <= 0 ) {
				break;
			}

			$attachment_id = self::get_or_upload_gallery_image( $post_id, $image );
			if ( ! $attachment_id ) {
				continue;
			}

		$url = wp_get_attachment_image_url( $attachment_id, 'large' );
		if ( ! $url ) {
			// If image metadata/sub-sizes were unavailable, use the original
			// Media Library URL so the gallery image is still visible.
			$url = wp_get_attachment_url( $attachment_id );
		}
			if ( ! $url ) {
				continue;
			}

			$alt = isset( $image['alt'] ) && is_string( $image['alt'] ) ? sanitize_text_field( $image['alt'] ) : '';

				$attrs = wp_json_encode(
					array(
						'id'              => $attachment_id,
						'sizeSlug'        => 'large',
						'linkDestination' => 'none',
						'alt'             => $alt,
					)
				);

				$blocks[] = '<!-- wp:image ' . $attrs . ' -->'
					. "\n" . '<figure class="wp-block-image size-large">'
				. '<img src="' . esc_url( $url ) . '" alt="' . esc_attr( $alt ) . '" class="wp-image-' . (int) $attachment_id . '" />'
				. '</figure>'
				. "\n" . '<!-- /wp:image -->';

			--$budget;
		}

		return implode( "\n\n", $blocks );
	}

	/**
	 * Sanitizes and wraps the banner's ready-made HTML block as a wp:html block.
	 */
	/**
	 * Renders a list of products as showcase cards inside ONE Custom HTML block.
	 * Every value is re-sanitized and escaped here (the payload is not trusted),
	 * and only plain tags + classes are used so the markup survives wp_kses_post
	 * when the REST user lacks unfiltered_html. Styling lives in
	 * print_article_styles().
	 */
	private static function render_product_cards( array $products, int $max ): string {
		$cards = array();

		foreach ( $products as $raw ) {
			if ( count( $cards ) >= $max ) {
				break;
			}

			$product = self::normalize_product( $raw );
			if ( null === $product ) {
				continue;
			}

			$cards[] = self::render_product_card( $product );
		}

		if ( empty( $cards ) ) {
			return '';
		}

		$html = '<div class="sevof-products' . ( count( $cards ) > 1 ? ' is-multi' : '' ) . '">' . implode( '', $cards ) . '</div>';

		return "<!-- wp:html -->\n" . self::sanitize_for_block_comment( $html ) . "\n<!-- /wp:html -->";
	}

	private static function render_product_card( array $p ): string {
		$name    = '' !== $p['name'] ? $p['name'] : __( 'Product', 'sevof-connector' );
		$current = self::price_to_number( $p['price'] );
		$regular = self::price_to_number( $p['regular_price'] );
		$percent = ( $regular > $current && $current > 0 ) ? (int) round( ( 1 - $current / $regular ) * 100 ) : 0;

		$image_tag = '' !== $p['image']
			? '<img src="' . esc_url( $p['image'] ) . '" alt="' . esc_attr( $name ) . '" loading="lazy" />'
			: '<span class="sevof-product-placeholder" aria-hidden="true">🛍️</span>';

		if ( '' !== $p['url'] ) {
			$link_open = '<a href="' . esc_url( $p['url'] ) . '" target="_blank" rel="noopener">';
			$media     = $link_open . $image_tag . '</a>';
			$title     = $link_open . esc_html( $name ) . '</a>';
		} else {
			$media = $image_tag;
			$title = esc_html( $name );
		}

		$html  = '<div class="sevof-product-card">';
		$html .= '<div class="sevof-product-media">';
		if ( $percent > 0 ) {
			/* translators: %s: discount percentage. */
			$html .= '<span class="sevof-product-badge">' . esc_html( sprintf( __( '%s%% off', 'sevof-connector' ), number_format_i18n( $percent ) ) ) . '</span>';
		}
		$html .= $media . '</div>';

		$html .= '<div class="sevof-product-body">';
		if ( '' !== $p['category'] ) {
			$html .= '<p class="sevof-product-cat">' . esc_html( $p['category'] ) . '</p>';
		}
		$html .= '<div class="sevof-product-title">' . $title . '</div>';

		$currency   = isset( $p['currency'] ) ? (string) $p['currency'] : '';
		$price_text = ! empty( $p['price_label'] ) ? (string) $p['price_label'] : self::format_price( $p['price'], $currency );
		if ( '' !== $price_text || null !== $p['in_stock'] ) {
			$html .= '<div class="sevof-product-pricing">';
			if ( '' !== $price_text ) {
				$html .= '<span class="sevof-product-price">' . esc_html( $price_text ) . '</span>';
				if ( $percent > 0 ) {
					$old_text = ! empty( $p['regular_label'] ) ? (string) $p['regular_label'] : self::format_price( $p['regular_price'], $currency );
					$html    .= '<span class="sevof-product-old-price">' . esc_html( $old_text ) . '</span>';
				}
			}
			if ( null !== $p['in_stock'] ) {
				$html .= '<span class="sevof-product-stock ' . ( $p['in_stock'] ? 'is-in' : 'is-out' ) . '">'
					. esc_html( $p['in_stock'] ? __( 'In stock', 'sevof-connector' ) : __( 'Out of stock', 'sevof-connector' ) ) . '</span>';
			}
			$html .= '</div>';
		}

		if ( ! empty( $p['specs'] ) ) {
			$html .= '<dl class="sevof-product-specs">';
			foreach ( $p['specs'] as $spec ) {
				$html .= '<div class="sevof-product-spec"><dt>' . esc_html( $spec['label'] ) . '</dt>'
					. '<span class="sevof-product-dots"></span>'
					. '<dd>' . esc_html( $spec['value'] ) . '</dd></div>';
			}
			$html .= '</dl>';
		} elseif ( '' !== $p['excerpt'] ) {
			$html .= '<p class="sevof-product-excerpt">' . esc_html( $p['excerpt'] ) . '</p>';
		}

		if ( '' !== $p['url'] ) {
			$html .= '<a class="sevof-product-cta" href="' . esc_url( $p['url'] ) . '" target="_blank" rel="noopener">' . esc_html( ! empty( $p['cta'] ) ? (string) $p['cta'] : __( 'View product', 'sevof-connector' ) ) . ' <span class="sevof-product-cta-arrow" aria-hidden="true">&rarr;</span></a>';
		}

		return $html . '</div></div>';
	}

	/**
	 * Re-validates one product from the payload. Returns null when it has
	 * neither a name nor a link (nothing worth showing).
	 */
	private static function normalize_product( $raw ): ?array {
		if ( ! is_array( $raw ) ) {
			return null;
		}

		$text = static function ( $value, int $max ): string {
			if ( ! is_scalar( $value ) ) {
				return '';
			}

			return mb_substr( sanitize_text_field( (string) $value ), 0, $max );
		};

		$url = static function ( $value ): string {
			if ( ! is_string( $value ) || '' === trim( $value ) ) {
				return '';
			}

			return (string) esc_url_raw( trim( $value ), array( 'http', 'https' ) );
		};

		$in_stock = null;
		if ( array_key_exists( 'in_stock', $raw ) && null !== $raw['in_stock'] && '' !== $raw['in_stock'] ) {
			$in_stock = filter_var( $raw['in_stock'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE );
		}

		$specs = array();
		if ( isset( $raw['specs'] ) && is_array( $raw['specs'] ) ) {
			foreach ( $raw['specs'] as $spec ) {
				if ( ! is_array( $spec ) ) {
					continue;
				}

				$label = $text( isset( $spec['label'] ) ? $spec['label'] : '', 120 );
				$value = $text( isset( $spec['value'] ) ? $spec['value'] : '', 200 );

				if ( '' === $label || '' === $value ) {
					continue;
				}

				$specs[] = array( 'label' => $label, 'value' => $value );

				if ( count( $specs ) >= self::MAX_PRODUCT_SPECS ) {
					break;
				}
			}
		}

		$product = array(
			'name'          => $text( isset( $raw['name'] ) ? $raw['name'] : '', 255 ),
			'url'           => $url( isset( $raw['url'] ) ? $raw['url'] : '' ),
			'image'         => $url( isset( $raw['image'] ) ? $raw['image'] : '' ),
			'price'         => $text( isset( $raw['price'] ) ? $raw['price'] : '', 60 ),
			'regular_price' => $text( isset( $raw['regular_price'] ) ? $raw['regular_price'] : '', 60 ),
			'currency'      => strtoupper( substr( (string) preg_replace( '/[^A-Za-z]/', '', isset( $raw['currency'] ) && is_string( $raw['currency'] ) ? $raw['currency'] : '' ), 0, 3 ) ),
			'category'      => $text( isset( $raw['category'] ) ? $raw['category'] : '', 120 ),
			'excerpt'       => $text( isset( $raw['excerpt'] ) ? $raw['excerpt'] : '', 600 ),
			'in_stock'      => $in_stock,
			'specs'         => $specs,
		);

		if ( '' === $product['name'] && '' === $product['url'] ) {
			return null;
		}

		return $product;
	}

	// ---------------------------------------------------------------------
	// Standalone product link => showcase card.
	//
	// When the Sevof service sends a product only as a plain link (a paragraph
	// or list item that contains nothing but one link, or a bare URL) instead of
	// a structured `products` list, the link is turned into the same card:
	//  - links to this site's own WooCommerce products / posts use local data;
	//  - other links are read once (title, image, price from Open Graph /
	//    JSON-LD) with wp_safe_remote_get() and cached in a transient;
	//  - if nothing can be read, a clean minimal card is still produced.
	// Disable with: add_filter( 'sevof_connector_auto_link_cards', '__return_false' );
	// ---------------------------------------------------------------------

	const MAX_AUTO_LINK_CARDS     = 12;
	const MAX_REMOTE_CARD_LOOKUPS = 6;

	private static $auto_card_count     = 0;
	private static $remote_lookup_count = 0;
	private static $structured_urls     = array();

	/**
	 * Resets the per-request counters and remembers which URLs already have a
	 * structured card so the same product is not rendered twice.
	 */
	private static function reset_link_card_state( array $structured_lists ) {
		self::$auto_card_count     = 0;
		self::$remote_lookup_count = 0;
		self::$structured_urls     = array();

		foreach ( $structured_lists as $list ) {
			if ( ! is_array( $list ) ) {
				continue;
			}
			foreach ( $list as $product ) {
				if ( is_array( $product ) && isset( $product['url'] ) && is_string( $product['url'] ) && '' !== $product['url'] ) {
					self::$structured_urls[] = self::url_key( $product['url'] );
				}
			}
		}
	}

	private static function url_key( string $url ): string {
		$url = strtolower( trim( html_entity_decode( $url, ENT_QUOTES, 'UTF-8' ) ) );
		$url = (string) preg_replace( '~^https?://(?:www\.)?~', '', $url );

		return untrailingslashit( $url );
	}

	/**
	 * Returns array( 'url' => ..., 'label' => ... ) when the HTML is exactly one
	 * link (optionally wrapped in <strong>/<em>) or one bare URL; otherwise null.
	 */
	private static function extract_standalone_link( string $inner_html ): ?array {
		$inner = trim( $inner_html );
		if ( '' === $inner ) {
			return null;
		}

		$plain = trim( html_entity_decode( wp_strip_all_tags( $inner ), ENT_QUOTES, 'UTF-8' ) );
		if ( $plain === $inner && preg_match( '~^https?://[^\s<>"\']+$~i', $plain ) ) {
			return array( 'url' => $plain, 'label' => '' );
		}

		if ( 1 !== substr_count( strtolower( $inner ), '<a ' ) ) {
			return null;
		}

		if ( ! preg_match( '~^(?:<(?:strong|b|em|i|span)\b[^>]*>\s*)*<a\b([^>]*)>(.*?)</a>\s*(?:</(?:strong|b|em|i|span)>\s*)*$~is', $inner, $m ) ) {
			return null;
		}

		if ( ! preg_match( '~\bhref\s*=\s*(["\'])(.*?)\1~is', $m[1], $href ) ) {
			return null;
		}

		$url = trim( html_entity_decode( $href[2], ENT_QUOTES, 'UTF-8' ) );
		if ( ! preg_match( '~^https?://~i', $url ) ) {
			return null;
		}

		return array(
			'url'   => $url,
			'label' => trim( html_entity_decode( wp_strip_all_tags( $m[2] ), ENT_QUOTES, 'UTF-8' ) ),
		);
	}

	/**
	 * Renders one card for a standalone link, or null when the HTML is not a
	 * standalone link / the per-article cap is reached / auto cards are disabled.
	 */
	private static function standalone_link_card( string $inner_html ): ?string {
		if ( self::$auto_card_count >= self::MAX_AUTO_LINK_CARDS || ! apply_filters( 'sevof_connector_auto_link_cards', true ) ) {
			return null;
		}

		$link = self::extract_standalone_link( $inner_html );
		if ( null === $link ) {
			return null;
		}

		$url = (string) esc_url_raw( $link['url'], array( 'http', 'https' ) );
		if ( '' === $url || in_array( self::url_key( $url ), self::$structured_urls, true ) ) {
			return null;
		}

		try {
			$html = self::render_product_card( self::resolve_link_card_data( $url, $link['label'] ) );
		} catch ( Throwable $e ) {
			return null;
		}

		++self::$auto_card_count;

		return $html;
	}

	private static function auto_cards_block( array $card_htmls ): string {
		$html = '<div class="sevof-products sevof-auto">' . implode( '', $card_htmls ) . '</div>';

		return "<!-- wp:html -->\n" . self::sanitize_for_block_comment( $html ) . "\n<!-- /wp:html -->";
	}

	/**
	 * A <ul>/<ol> whose every item is a standalone link becomes a grid of cards.
	 * Any other list is left alone (returns '').
	 */
	private static function list_link_cards( string $list_inner ): string {
		if ( false !== stripos( $list_inner, '<ul' ) || false !== stripos( $list_inner, '<ol' ) ) {
			return '';
		}

		if ( ! preg_match_all( '~<li\b[^>]*>(.*?)</li>~is', $list_inner, $items ) || empty( $items[1] ) ) {
			return '';
		}

		if ( count( $items[1] ) > self::MAX_AUTO_LINK_CARDS - self::$auto_card_count ) {
			return '';
		}

		foreach ( $items[1] as $item ) {
			$link = self::extract_standalone_link( $item );
			if ( null === $link || in_array( self::url_key( $link['url'] ), self::$structured_urls, true ) ) {
				return '';
			}
		}

		$blocks = array();
		foreach ( $items[1] as $item ) {
			$card = self::standalone_link_card( $item );
			if ( null !== $card ) {
				$blocks[] = self::auto_cards_block( array( $card ) );
			}
		}

		return implode( "\n\n", $blocks );
	}

	/**
	 * Merges neighbouring auto-card blocks into one grid and marks grids that
	 * hold more than one card, so consecutive product links sit side by side.
	 */
	private static function group_adjacent_auto_cards( string $content ): string {
		$glue    = "</div>\n<!-- /wp:html -->\n\n<!-- wp:html -->\n<div class=\"sevof-products sevof-auto\">";
		$content = str_replace( $glue, '', $content );

		$grouped = preg_replace_callback(
			'~<div class="sevof-products sevof-auto">(.*?)</div>\n<!-- /wp:html -->~s',
			static function ( array $m ): string {
				$count = substr_count( $m[1], 'class="sevof-product-card"' );

				return '<div class="sevof-products sevof-auto' . ( $count > 1 ? ' is-multi' : '' ) . '">' . $m[1] . "</div>\n<!-- /wp:html -->";
			},
			$content
		);

		return is_string( $grouped ) ? $grouped : $content;
	}

	/**
	 * Builds the card data for a link: local WooCommerce / post data first, then
	 * page metadata, then a minimal fallback built from the link text and host.
	 */
	private static function resolve_link_card_data( string $url, string $label ): array {
		$host = (string) wp_parse_url( $url, PHP_URL_HOST );
		$host = (string) preg_replace( '~^www\.~i', '', strtolower( $host ) );

		$data = array(
			'name'          => mb_substr( sanitize_text_field( $label ), 0, 255 ),
			'url'           => $url,
			'image'         => '',
			'price'         => '',
			'regular_price' => '',
			'price_label'   => '',
			'regular_label' => '',
			'currency'      => '',
			'category'      => $host,
			'excerpt'       => '',
			'in_stock'      => null,
			'specs'         => array(),
			'cta'           => __( 'Learn more', 'sevof-connector' ),
		);

		$found = self::local_link_card_data( $url, $host );
		if ( empty( $found ) ) {
			$found = self::remote_link_card_data( $url );
		}

		foreach ( $found as $key => $value ) {
			if ( null !== $value && '' !== $value && array() !== $value ) {
				$data[ $key ] = $value;
			}
		}

		if ( '' === $data['name'] ) {
			$data['name'] = '' !== $host ? $host : $url;
		}

		if ( $data['name'] === $data['category'] ) {
			$data['category'] = '';
		}

		return $data;
	}

	/**
	 * Data for a link that points to this very site (WooCommerce product or post).
	 */
	private static function local_link_card_data( string $url, string $host ): array {
		$home_host = (string) preg_replace( '~^www\.~i', '', strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) );
		if ( '' === $host || $host !== $home_host ) {
			return array();
		}

		$post_id = (int) url_to_postid( $url );
		$post    = $post_id > 0 ? get_post( $post_id ) : null;
		if ( ! $post instanceof WP_Post || 'publish' !== $post->post_status ) {
			return array();
		}

		$excerpt = has_excerpt( $post ) ? $post->post_excerpt : $post->post_content;
		$data    = array(
			'name'    => sanitize_text_field( get_the_title( $post ) ),
			'url'     => (string) get_permalink( $post ),
			'excerpt' => mb_substr( wp_trim_words( wp_strip_all_tags( strip_shortcodes( (string) $excerpt ) ), 28, '…' ), 0, 600 ),
			'cta'     => __( 'Read more', 'sevof-connector' ),
		);

		$thumb = get_the_post_thumbnail_url( $post, 'large' );
		if ( $thumb ) {
			$data['image'] = (string) $thumb;
		}

		if ( 'post' === $post->post_type ) {
			$cats = get_the_category( $post->ID );
			if ( ! empty( $cats ) && $cats[0] instanceof WP_Term ) {
				$data['category'] = $cats[0]->name;
			}
		}

		if ( 'product' === $post->post_type && function_exists( 'wc_get_product' ) ) {
			try {
				$product = wc_get_product( $post->ID );
				if ( $product ) {
					$data['cta']     = __( 'View product', 'sevof-connector' );
					$data['excerpt'] = mb_substr( wp_trim_words( wp_strip_all_tags( (string) $product->get_short_description() ), 28, '…' ), 0, 600 );

					$image_id = (int) $product->get_image_id();
					$image    = $image_id > 0 ? wp_get_attachment_image_url( $image_id, 'large' ) : '';
					if ( $image ) {
						$data['image'] = (string) $image;
					}

					$terms = get_the_terms( $post->ID, 'product_cat' );
					if ( is_array( $terms ) && ! empty( $terms ) && $terms[0] instanceof WP_Term ) {
						$data['category'] = $terms[0]->name;
					}

					$data['in_stock'] = (bool) $product->is_in_stock();

					$price   = (string) $product->get_price();
					$regular = (string) $product->get_regular_price();

					if ( '' !== $price ) {
						$data['price']       = $price;
						$data['price_label'] = self::wc_price_text( $price );
						if ( '' !== $regular && (float) $regular > (float) $price ) {
							$data['regular_price'] = $regular;
							$data['regular_label'] = self::wc_price_text( $regular );
						}
					}
				}
			} catch ( Throwable $e ) {
				sevof_connector_log( 'link_card_local_product_failed', array( 'post_id' => $post->ID ) );
			}
		}

		return $data;
	}

	/**
	 * Puts an amount + ISO currency code onto a card array.
	 */
	private static function apply_card_price( array &$data, string $amount, string $currency ) {
		$number = self::price_to_number( $amount );
		if ( $number <= 0 ) {
			return;
		}

		$data['price']    = (string) $number;
		$data['currency'] = strtoupper( substr( (string) preg_replace( '/[^A-Za-z]/', '', $currency ), 0, 3 ) );
	}

	/**
	 * A WooCommerce price as plain text, in the store's own currency format.
	 */
	private static function wc_price_text( string $amount ): string {
		if ( ! function_exists( 'wc_price' ) ) {
			return self::format_price( $amount, function_exists( 'get_woocommerce_currency' ) ? (string) get_woocommerce_currency() : '' );
		}

		return html_entity_decode( wp_strip_all_tags( wc_price( (float) $amount ) ), ENT_QUOTES, 'UTF-8' );
	}

	/**
	 * Reads title / image / price of an external page. Cached; capped per request;
	 * uses wp_safe_remote_get() so private/loopback addresses are refused.
	 */
	private static function remote_link_card_data( string $url ): array {
		$cache_key = 'sevof_lc_' . md5( $url );
		$cached    = get_transient( $cache_key );
		if ( is_array( $cached ) ) {
			return self::meta_to_card_data( $cached );
		}

		if ( self::$remote_lookup_count >= self::MAX_REMOTE_CARD_LOOKUPS ) {
			return array();
		}
		++self::$remote_lookup_count;

		$response = wp_safe_remote_get(
			$url,
			array(
				'timeout'             => 4,
				'redirection'         => 3,
				'limit_response_size' => 262144,
				'user-agent'          => 'Mozilla/5.0 (compatible; SevofSyncConnector/' . SEVOF_CONNECTOR_VERSION . '; +' . home_url( '/' ) . ')',
				'headers'             => array(
					'Accept'          => 'text/html,application/xhtml+xml',
					'Accept-Language' => 'fa,en;q=0.8',
				),
			)
		);

		$meta = array();
		if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
			$type = (string) wp_remote_retrieve_header( $response, 'content-type' );
			if ( '' === $type || false !== stripos( $type, 'html' ) ) {
				$meta = self::parse_page_metadata( (string) wp_remote_retrieve_body( $response ), $url );
			}
		}

		set_transient( $cache_key, $meta, empty( $meta ) ? HOUR_IN_SECONDS : 12 * HOUR_IN_SECONDS );

		return self::meta_to_card_data( $meta );
	}

	/**
	 * Extracts name / image / description / price / stock from page HTML.
	 */
	private static function parse_page_metadata( string $html, string $page_url ): array {
		$head_end = stripos( $html, '</head>' );
		$head     = false !== $head_end ? substr( $html, 0, $head_end ) : $html;

		$meta = array();
		if ( preg_match_all( '~<meta\b[^>]*>~i', $head, $tags ) ) {
			foreach ( $tags[0] as $tag ) {
				if ( ! preg_match( '~\b(?:property|name|itemprop)\s*=\s*(["\'])(.*?)\1~is', $tag, $k ) || ! preg_match( '~\bcontent\s*=\s*(["\'])(.*?)\1~is', $tag, $v ) ) {
					continue;
				}
				$key = strtolower( trim( $k[2] ) );
				if ( ! isset( $meta[ $key ] ) ) {
					$meta[ $key ] = trim( html_entity_decode( $v[2], ENT_QUOTES, 'UTF-8' ) );
				}
			}
		}

		$title = isset( $meta['og:title'] ) ? $meta['og:title'] : ( isset( $meta['twitter:title'] ) ? $meta['twitter:title'] : '' );
		if ( '' === $title && preg_match( '~<title[^>]*>(.*?)</title>~is', $head, $t ) ) {
			$title = html_entity_decode( $t[1], ENT_QUOTES, 'UTF-8' );
		}

		$image = '';
		foreach ( array( 'og:image:secure_url', 'og:image', 'twitter:image', 'twitter:image:src' ) as $key ) {
			if ( ! empty( $meta[ $key ] ) ) {
				$image = $meta[ $key ];
				break;
			}
		}

		$desc = '';
		foreach ( array( 'og:description', 'description', 'twitter:description' ) as $key ) {
			if ( ! empty( $meta[ $key ] ) ) {
				$desc = $meta[ $key ];
				break;
			}
		}

		$amount   = '';
		$currency = '';
		foreach ( array( 'product:price:amount', 'og:price:amount', 'product:sale_price:amount' ) as $key ) {
			if ( ! empty( $meta[ $key ] ) ) {
				$amount = $meta[ $key ];
				break;
			}
		}
		foreach ( array( 'product:price:currency', 'og:price:currency', 'product:sale_price:currency' ) as $key ) {
			if ( ! empty( $meta[ $key ] ) ) {
				$currency = $meta[ $key ];
				break;
			}
		}

		$in_stock = null;
		if ( ! empty( $meta['product:availability'] ) ) {
			$availability = strtolower( $meta['product:availability'] );
			$in_stock     = false !== strpos( $availability, 'out' ) || false !== strpos( $availability, 'sold' ) ? false : ( false !== strpos( $availability, 'in' ) ? true : null );
		}

		// JSON-LD Product is usually the cleanest source for name/price/stock.
		if ( preg_match_all( '~<script\b[^>]*type\s*=\s*(["\'])application/ld\+json\1[^>]*>(.*?)</script>~is', $html, $blocks ) ) {
			foreach ( $blocks[2] as $json ) {
				$decoded = json_decode( trim( html_entity_decode( $json, ENT_QUOTES, 'UTF-8' ) ), true );
				$product = is_array( $decoded ) ? self::find_product_ld( $decoded ) : null;
				if ( ! $product ) {
					continue;
				}

				if ( ! empty( $product['name'] ) && is_string( $product['name'] ) ) {
					$title = $product['name'];
				}
				if ( '' === $image && ! empty( $product['image'] ) ) {
					$ld_image = $product['image'];
					if ( is_array( $ld_image ) ) {
						$ld_image = isset( $ld_image['url'] ) ? $ld_image['url'] : reset( $ld_image );
						$ld_image = is_array( $ld_image ) && isset( $ld_image['url'] ) ? $ld_image['url'] : $ld_image;
					}
					$image = is_string( $ld_image ) ? $ld_image : '';
				}
				if ( '' === $desc && ! empty( $product['description'] ) && is_string( $product['description'] ) ) {
					$desc = $product['description'];
				}

				$offer = isset( $product['offers'] ) && is_array( $product['offers'] ) ? $product['offers'] : array();
				if ( isset( $offer[0] ) && is_array( $offer[0] ) ) {
					$offer = $offer[0];
				}
				if ( '' === $amount ) {
					foreach ( array( 'price', 'lowPrice' ) as $key ) {
						if ( isset( $offer[ $key ] ) && is_scalar( $offer[ $key ] ) && '' !== (string) $offer[ $key ] ) {
							$amount = (string) $offer[ $key ];
							break;
						}
					}
				}
				if ( '' === $currency && isset( $offer['priceCurrency'] ) && is_string( $offer['priceCurrency'] ) ) {
					$currency = $offer['priceCurrency'];
				}
				if ( null === $in_stock && isset( $offer['availability'] ) && is_string( $offer['availability'] ) ) {
					if ( false !== stripos( $offer['availability'], 'OutOfStock' ) || false !== stripos( $offer['availability'], 'SoldOut' ) ) {
						$in_stock = false;
					} elseif ( false !== stripos( $offer['availability'], 'InStock' ) ) {
						$in_stock = true;
					}
				}
				break;
			}
		}

		if ( '' !== $image && class_exists( 'WP_Http' ) ) {
			$image = (string) WP_Http::make_absolute_url( $image, $page_url );
		}

		return array(
			'name'     => self::clean_page_title( $title ),
			'image'    => (string) esc_url_raw( $image, array( 'http', 'https' ) ),
			'excerpt'  => mb_substr( wp_trim_words( sanitize_text_field( $desc ), 28, '…' ), 0, 600 ),
			'amount'   => mb_substr( sanitize_text_field( $amount ), 0, 40 ),
			'currency' => mb_substr( sanitize_text_field( $currency ), 0, 8 ),
			'in_stock' => $in_stock,
		);
	}

	private static function find_product_ld( $node, int $depth = 0 ): ?array {
		if ( $depth > 6 || ! is_array( $node ) ) {
			return null;
		}

		$type = isset( $node['@type'] ) ? $node['@type'] : '';
		$type = is_array( $type ) ? $type : array( $type );
		if ( in_array( 'Product', $type, true ) ) {
			return $node;
		}

		foreach ( $node as $child ) {
			if ( is_array( $child ) ) {
				$found = self::find_product_ld( $child, $depth + 1 );
				if ( $found ) {
					return $found;
				}
			}
		}

		return null;
	}

	/**
	 * "Galaxy A55 | Some Store" => "Galaxy A55": drops a short trailing site name.
	 */
	private static function clean_page_title( string $title ): string {
		$title = sanitize_text_field( $title );
		$parts = preg_split( '~\s+[|–—-]\s+~u', $title );

		if ( is_array( $parts ) && count( $parts ) > 1 && mb_strlen( (string) end( $parts ) ) <= 30 ) {
			array_pop( $parts );
			$title = implode( ' - ', $parts );
		}

		return mb_substr( trim( $title ), 0, 255 );
	}

	/**
	 * Converts cached page metadata into card fields.
	 */
	private static function meta_to_card_data( array $meta ): array {
		if ( empty( $meta ) ) {
			return array();
		}

		$data = array(
			'name'     => isset( $meta['name'] ) ? $meta['name'] : '',
			'image'    => isset( $meta['image'] ) ? $meta['image'] : '',
			'excerpt'  => isset( $meta['excerpt'] ) ? $meta['excerpt'] : '',
			'in_stock' => isset( $meta['in_stock'] ) ? $meta['in_stock'] : null,
		);

		if ( ! empty( $meta['amount'] ) ) {
			self::apply_card_price( $data, (string) $meta['amount'], isset( $meta['currency'] ) ? (string) $meta['currency'] : '' );
			if ( ! empty( $data['price'] ) ) {
				$data['cta'] = __( 'View product', 'sevof-connector' );
			}
		}

		return $data;
	}

	private static function price_to_number( string $price ): float {
		$clean = preg_replace( '/[^\d.]/', '', self::to_latin_digits( $price ) );

		return ( '' !== $clean && is_numeric( $clean ) ) ? (float) $clean : 0.0;
	}

	/**
	 * "1250.5" + "USD" => "$1,250.50". A price that is not a plain number is
	 * shown exactly as the service sent it.
	 */
	private static function format_price( string $price, string $currency = '' ): string {
		if ( '' === trim( $price ) ) {
			return '';
		}

		$number = self::price_to_number( $price );
		if ( $number <= 0 ) {
			return $price;
		}

		$amount  = number_format_i18n( $number, floor( $number ) === $number ? 0 : 2 );
		$code    = strtoupper( $currency );
		$symbols = array(
			'USD' => '$',
			'EUR' => "\u{20AC}",
			'GBP' => "\u{00A3}",
		);

		if ( isset( $symbols[ $code ] ) ) {
			return $symbols[ $code ] . $amount;
		}

		return '' === $code ? $amount : $amount . ' ' . $code;
	}

	/**
	 * Converts Arabic-Indic digits and thousands separators so prices parse as numbers.
	 */
	private static function to_latin_digits( string $value ): string {
		return strtr(
			$value,
			array(
				'۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
				'٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
				'٬' => '', '،' => '', ',' => '',
			)
		);
	}

	private static function render_banner( array $banner ): string {
		if ( empty( $banner['html'] ) || ! is_string( $banner['html'] ) ) {
			return '';
		}

		// Banners are generated HTML and rely on inline CSS (and sometimes a
		// scoped <style> block). wp_kses_post() removes parts of that design,
		// which made an otherwise valid banner arrive blank or unstyled. Keep a
		// narrow, presentation-only allowlist: no script, iframe, form, event
		// handlers, or arbitrary executable attributes are accepted.
		$html = self::normalize_banner_html( $banner['html'] );
		$html = wp_kses( $html, self::banner_allowed_html() );
		$html = self::scope_banner_styles( $html );
		if ( '' === trim( $html ) ) {
			return '';
		}

		$wrapped = '<div class="sevof-banner" style="margin: 2em 0;">' . $html . '</div>';
		$safe    = self::sanitize_for_block_comment( $wrapped );

		return "<!-- wp:html -->\n" . $safe . "\n<!-- /wp:html -->";
	}

	/**
	 * Some older banner generators emitted CSS as a raw text node inside the
	 * wrapper instead of wrapping it in <style>. Without normalization browsers
	 * display that CSS as visible text above the banner. Convert
	 * only a clearly CSS-shaped block that is followed by the generated banner
	 * markup; ordinary text remains untouched.
	 */
	private static function normalize_banner_html( string $html ): string {
		if ( false !== stripos( $html, '<style' ) ) {
			return $html;
		}

		$css_match = array();
		if ( 1 !== preg_match( '/(?:^|\r?\n)\s*(?:\/\*|[.#@][A-Za-z0-9_-]+)/', $html, $css_match, PREG_OFFSET_CAPTURE ) ) {
			return $html;
		}

		$css_start = (int) $css_match[0][1];
		$markup_start = strpos( $html, '<div class="yx', $css_start );
		if ( false === $markup_start ) {
			return $html;
		}

		$css_until_markup = substr( $html, $css_start, $markup_start - $css_start );
		$css_end_relative = strrpos( $css_until_markup, '}' );
		if ( false === $css_end_relative ) {
			return $html;
		}

		$css_end = $css_start + $css_end_relative + 1;
		$css = trim( substr( $html, $css_start, $css_end - $css_start ) );
		if ( '' === $css || false === strpos( $css, '{' ) ) {
			return $html;
		}

		return substr( $html, 0, $css_start ) . '<style>' . $css . '</style>' . substr( $html, $css_end );
	}

	/**
	 * Allowed banner markup. The source is authenticated by the connector, but
	 * the allowlist remains restrictive because the resulting HTML is public.
	 */
	private static function banner_allowed_html(): array {
		$global = array(
			'class'       => true,
			'id'          => true,
			'style'       => true,
			'dir'         => true,
			'lang'        => true,
			'role'        => true,
			'aria-label'  => true,
			'aria-hidden' => true,
		);

		$allowed = array();
		foreach ( array( 'div', 'section', 'article', 'header', 'footer', 'main', 'aside', 'span', 'p', 'strong', 'b', 'em', 'small', 'h2', 'h3', 'ul', 'ol', 'li' ) as $tag ) {
			$allowed[ $tag ] = $global;
		}

		$allowed['a'] = array_merge(
			$global,
			array(
				'href'   => true,
				'target' => true,
				'rel'    => true,
			)
		);
		$allowed['img'] = array_merge(
			$global,
			array(
				'src'    => true,
				'alt'    => true,
				'width'  => true,
				'height' => true,
				'loading' => true,
			)
		);
		$allowed['style'] = array();

		return $allowed;
	}

	/**
	 * Returns the Media Library attachment ID for one gallery image, uploading it only
	 * if an identical image (by content hash) was not already uploaded for this post
	 * in a previous sync.
	 */
	private static function get_or_upload_gallery_image( int $post_id, $image ) {
		if ( ! is_array( $image ) || empty( $image['base64'] ) || ! is_string( $image['base64'] ) ) {
			return null;
		}

		$decoded = self::decode_and_validate_image_binary( $image['base64'] );
		if ( is_wp_error( $decoded ) ) {
			sevof_connector_log( 'gallery_image_rejected', array( 'post_id' => $post_id, 'reason' => $decoded->get_error_code() ) );

			return null;
		}

		$hash = hash( 'sha256', $decoded['binary'] );
		$map = self::get_gallery_image_map( $post_id );

		if ( isset( $map[ $hash ] ) ) {
			$cached_id = (int) $map[ $hash ];
			if ( $cached_id > 0 && 'attachment' === get_post_type( $cached_id ) ) {
				return $cached_id;
			}
		}

		$filename_stem = isset( $image['filename'] ) ? (string) $image['filename'] : ( 'sevof-gallery-' . $post_id );
		$attachment_id = self::upload_binary_to_media_library( $post_id, $decoded, $filename_stem );

		if ( is_wp_error( $attachment_id ) ) {
			sevof_connector_log( 'gallery_image_upload_failed', array( 'post_id' => $post_id, 'reason' => $attachment_id->get_error_code() ) );

			return null;
		}

		if ( isset( $image['alt'] ) && is_string( $image['alt'] ) ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $image['alt'] ) );
		}

		$map[ $hash ] = $attachment_id;
		self::save_gallery_image_map( $post_id, $map );

		return $attachment_id;
	}

	private static function get_gallery_image_map( int $post_id ): array {
		$raw = get_post_meta( $post_id, self::GALLERY_IMAGE_MAP_META_KEY, true );
		if ( ! is_string( $raw ) || '' === $raw ) {
			return array();
		}

		$decoded = json_decode( $raw, true );

		return is_array( $decoded ) ? $decoded : array();
	}

	private static function save_gallery_image_map( int $post_id, array $map ) {
		// Keeps the map from growing without bound across many re-syncs of an article
		// whose images keep changing; array insertion order is preserved by PHP, so
		// this keeps the most recently added entries.
		if ( count( $map ) > self::MAX_STORED_IMAGE_HASHES ) {
			$map = array_slice( $map, -self::MAX_STORED_IMAGE_HASHES, null, true );
		}

		update_post_meta( $post_id, self::GALLERY_IMAGE_MAP_META_KEY, wp_json_encode( $map ) );
	}
}

// Bootstrap the controller when this file is loaded as a standalone plugin file.
Sevof_Connector_Rest_Controller::init();
