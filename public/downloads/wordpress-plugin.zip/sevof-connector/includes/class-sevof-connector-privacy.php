<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds a clear, administrator-editable disclosure for the WordPress privacy policy page.
 */
class Sevof_Connector_Privacy {
	/**
	 * Registers the privacy-policy content hook.
	 */
	public static function init() {
		add_action( 'admin_init', array( self::class, 'add_privacy_policy_content' ) );
	}

	/**
	 * Adds suggested policy text only; site owners remain responsible for reviewing it.
	 */
	public static function add_privacy_policy_content() {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}

		$content = '<p class="privacy-policy-tutorial">' . esc_html__( 'Suggested text: Review and adapt this text to reflect your Sevof account, retention settings, and legal obligations before publishing your site privacy policy.', 'sevof-connector' ) . '</p>';
		$content .= '<p>' . esc_html__( 'This site uses Sevof Connector to connect to the Sevof service at api.sevof.com. When a site administrator saves connection credentials and connects the plugin, the plugin sends the site URL, WordPress version, and plugin version to the service to verify the connection. The connection uses authenticated HTTPS requests.', 'sevof-connector' ) . '</p>';
		$content .= '<p>' . esc_html__( 'The Sevof service can send article titles, article content, SEO metadata, optional featured images, optional in-article gallery images, and an optional promotional banner block to this site for publication. These materials are stored in the WordPress database and Media Library according to this site’s normal retention settings. The plugin does not send visitor analytics, comments, or user account data to the Sevof service.', 'sevof-connector' ) . '</p>';
		$content .= '<p>' . esc_html__( 'Connection credentials are stored in this WordPress installation and are used only to authenticate requests to the Sevof service. Site administrators should consult the Sevof service’s current privacy notice and terms before activating the connection.', 'sevof-connector' ) . '</p>';

		wp_add_privacy_policy_content( 'Sevof Connector', wp_kses_post( wpautop( $content ) ) );
	}
}
