<?php
/**
 * Plugin Name:       Sevof Connector
 * Plugin URI:        https://sevof.com
 * Description:       Connects your WordPress site to Sevof to publish SEO articles and product articles and to apply approved SEO updates to WooCommerce products.
 * Version:           1.0.0
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            Sevof
 * Author URI:        https://sevof.com
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       sevof-connector
 * Domain Path:       /languages
 *
 * @package SevofConnector
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Another copy of this plugin is already loaded (e.g. a second folder): stop instead of redeclaring classes.
if ( defined( 'SEVOF_CONNECTOR_VERSION' ) ) {
	return;
}

define( 'SEVOF_CONNECTOR_VERSION', '1.0.0' );
define( 'SEVOF_CONNECTOR_FILE', __FILE__ );
define( 'SEVOF_CONNECTOR_PATH', plugin_dir_path( __FILE__ ) );
define( 'SEVOF_CONNECTOR_URL', plugin_dir_url( __FILE__ ) );

require_once SEVOF_CONNECTOR_PATH . 'includes/class-sevof-connector-signature.php';
require_once SEVOF_CONNECTOR_PATH . 'includes/class-sevof-connector-api-client.php';
require_once SEVOF_CONNECTOR_PATH . 'includes/class-sevof-connector-dashboard-page.php';
require_once SEVOF_CONNECTOR_PATH . 'includes/class-sevof-connector-seo.php';
require_once SEVOF_CONNECTOR_PATH . 'includes/class-sevof-connector-rest-controller.php';
require_once SEVOF_CONNECTOR_PATH . 'includes/class-sevof-connector-product-controller.php';
require_once SEVOF_CONNECTOR_PATH . 'includes/class-sevof-connector-existing-posts.php';
require_once SEVOF_CONNECTOR_PATH . 'includes/class-sevof-connector-cron.php';
require_once SEVOF_CONNECTOR_PATH . 'includes/class-sevof-connector-posts-list.php';
require_once SEVOF_CONNECTOR_PATH . 'includes/class-sevof-connector-privacy.php';
require_once SEVOF_CONNECTOR_PATH . 'includes/class-sevof-connector-logo-color.php';
require_once SEVOF_CONNECTOR_PATH . 'includes/class-sevof-connector-style-settings.php';
require_once SEVOF_CONNECTOR_PATH . 'includes/class-sevof-connector-custom-classes.php';

/**
 * Hooks every component.
 */
function sevof_connector_init() {
	Sevof_Connector_Dashboard_Page::init();
	Sevof_Connector_Seo::init();
	Sevof_Connector_Rest_Controller::init();
	Sevof_Connector_Product_Controller::init();
	Sevof_Connector_Existing_Posts::init();
	Sevof_Connector_Cron::init();
	Sevof_Connector_Posts_List::init();
	Sevof_Connector_Privacy::init();
	Sevof_Connector_Style_Settings::init();
	Sevof_Connector_Custom_Classes::init();
}
add_action( 'plugins_loaded', 'sevof_connector_init' );

/**
 * Adds a "Settings" link on the Plugins screen.
 *
 * @param string[] $links Existing action links.
 * @return string[]
 */
function sevof_connector_action_links( $links ) {
	$url = admin_url( 'admin.php?page=' . Sevof_Connector_Dashboard_Page::PAGE_SLUG );
	array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'sevof-connector' ) . '</a>' );

	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'sevof_connector_action_links' );

register_activation_hook( __FILE__, array( 'Sevof_Connector_Cron', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Sevof_Connector_Cron', 'deactivate' ) );
